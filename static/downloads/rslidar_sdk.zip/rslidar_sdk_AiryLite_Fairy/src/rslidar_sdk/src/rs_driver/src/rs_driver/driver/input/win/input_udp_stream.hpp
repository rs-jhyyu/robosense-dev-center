      
/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/


#pragma once

#include <rs_driver/driver/input/input_sock.hpp>
#include <rs_driver/common/rs_common.hpp>

namespace robosense
{
namespace lidar
{
class InputUdpStream : public InputSock
{
public:
  InputUdpStream(const RSInputParam& input_param)
    : InputSock(input_param), pkt_buf_len_(ETH_LEN),
      sock_offset_(0), sock_tail_(0)
  {
    sock_offset_ += input_param.user_layer_bytes;
    sock_tail_   += input_param.tail_layer_bytes;
    
    scroll_buffer_size_ = 0;
    tail_buffer_size_ = 0;
    memset(readBuffer, 0, sizeof(readBuffer));
    memset(scrollBuffer, 0, sizeof(scrollBuffer));

    
    cur_data_type_ = RS0352HeaderType::INVALID;
    has_unknown_data_type_ = -1;

    cont_search_ = false;
    valid_header_idx_ = -1;
    has_get_one_header_ = false;

    header_cnt_ = 0;
    push_cnt_ = 0;
    drop_cnt_ = 0;
  }

  virtual bool init();
  virtual int recvPacket() override;
  virtual ~InputUdpStream();
  inline void procRecvData(uint8_t* recv_buffer, int dataLen);
  inline RS0352HeaderType getHeaderType(int nowCnt);
  inline RS0352HeaderType getRawDataHeaderType(uint8_t* raw_data, int nowCnt);
  inline void ejectForcely(int validCnt);

private:
  inline int createSocket(uint16_t port, const std::string& hostIp, const std::string& grpIp);
  inline int setUpSwitchSocket();
  inline int sendSwitchCmd();

protected:
  size_t pkt_buf_len_;
  int fds_[2];
  int send_fd_;
  bool switch_to10m_succ_;
  bool start_trying_flag_;
  bool re_connect_flag_;
  int myCnt_;
  size_t sock_offset_;
  size_t sock_tail_;

  int scroll_buffer_size_;
  int tail_buffer_size_;
  uint8_t readBuffer[5000];
  uint8_t scrollBuffer[4096];
  std::vector<uint8_t> tail_tmp_buffer_;

  RS0352HeaderType cur_data_type_;
  int has_unknown_data_type_;

  bool cont_search_;
  int valid_header_idx_;
  bool has_get_one_header_;

  long header_cnt_;
  long push_cnt_;
  long drop_cnt_;

  int last_cnt_;
};

inline bool InputUdpStream::init()
{
  int ret = setUpSwitchSocket();
  if (ret < 0)
    return false;

  switch_to10m_succ_ = false;
  start_trying_flag_ = false;
  re_connect_flag_ = false;
  myCnt_ = 0;
  send_fd_ = ret;

  last_cnt_ = -1;
  
  return true;
}

inline InputUdpStream::~InputUdpStream()
{
  if (fds_[0] >= 0)
    closesocket(fds_[0]);

  if (fds_[1] >= 0)
    closesocket(fds_[1]);

  fds_[0] = fds_[1] = -1;
}

inline int InputUdpStream::setUpSwitchSocket()
{
  WORD version = MAKEWORD(2, 2);
  WSADATA wsaData;
  int reuse = 1;
  int ret = WSAStartup(version, &wsaData);
  if(ret < 0)
    return false;

  int fd = socket(PF_INET, SOCK_DGRAM, 0);
  if (fd < 0)
  {
    perror("socket: ");
    return -1;
  }

  ret = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));
  if (ret < 0)
  {
    perror("setsockopt: ");
    closesocket(fd);
    return -1;
  }

  struct sockaddr_in local_addr;
  local_addr.sin_family = AF_INET;
  local_addr.sin_port = htons(7788);
  local_addr.sin_addr.s_addr = INADDR_ANY;
  if (bind(fd, (sockaddr*)&local_addr, sizeof(local_addr)) == -1) {
      std::cerr << "Bind failed" << std::endl;
      closesocket(fd);
      return -1;
  }

  return fd;
}

inline int InputUdpStream::sendSwitchCmd()
{
  struct sockaddr_in lidar_addr;
  memset(&lidar_addr, 0, sizeof(lidar_addr));
  lidar_addr.sin_family = AF_INET;
  lidar_addr.sin_port = htons(7788);
  lidar_addr.sin_addr.s_addr = INADDR_ANY;
  std::string lidarIp = "192.168.1.200";
  inet_pton(AF_INET, lidarIp.c_str(), &(lidar_addr.sin_addr));

  std::vector<unsigned char> switchCmd = {
    0x5A, 0xFF, 0x00, 0x00, 0x00, 0x04,
    0x00, 0x08,
    0x31, 0x01, 0xF0, 0x02, 0x00, 0x98, 0x96, 0x80,
    0xb4, 0xf1
  };

  int bytesSent = sendto(
      send_fd_,
      reinterpret_cast<const char*>(switchCmd.data()),
      static_cast<int>(switchCmd.size()),
      0,
      reinterpret_cast<const sockaddr*>(&lidar_addr),
      sizeof(lidar_addr)
  );

  if (bytesSent <= 0) {
    std::cout << "Switch Cmd Failed." << std::endl;
  }
  else
  {
    std::cout << "Sent " << bytesSent << " bytes to " << lidarIp << ":" << 7788 << std::endl;
  }
  

  return bytesSent;
}

inline int InputUdpStream::createSocket(uint16_t port, const std::string& hostIp, const std::string& grpIp)
{
  int fd;
  int ret;
  int reuse = 1;

  fd = socket(PF_INET, SOCK_DGRAM, 0);
  if (fd < 0)
  {
    perror("socket: ");
    goto failSocket;
  }

  ret = setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));
  if (ret < 0)
  {
    perror("setsockopt: ");
    goto failOption;
  }

  struct sockaddr_in host_addr;
  memset(&host_addr, 0, sizeof(host_addr));
  host_addr.sin_family = AF_INET;
  host_addr.sin_port = htons(port);
  host_addr.sin_addr.s_addr = INADDR_ANY;
  if (hostIp != "0.0.0.0" && grpIp == "0.0.0.0")
  {
    inet_pton(AF_INET, hostIp.c_str(), &(host_addr.sin_addr));
  }

  ret = bind(fd, (struct sockaddr*)&host_addr, sizeof(host_addr));
  if (ret < 0)
  {
    perror("bind: ");
    goto failBind;
  }

  if (grpIp != "0.0.0.0")
  {
#if 0
    struct ip_mreqn ipm;
    memset(&ipm, 0, sizeof(ipm));
    inet_pton(AF_INET, grpIp.c_str(), &(ipm.imr_multiaddr));
    inet_pton(AF_INET, hostIp.c_str(), &(ipm.imr_address));
#else
    struct ip_mreq ipm;
    inet_pton(AF_INET, grpIp.c_str(), &(ipm.imr_multiaddr));
    inet_pton(AF_INET, hostIp.c_str(), &(ipm.imr_interface));
#endif
    ret = setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, (const char*)&ipm, sizeof(ipm));
    if (ret < 0)
    {
      perror("setsockopt: ");
      goto failGroup;
    }
  }

#ifdef ENABLE_DOUBLE_RCVBUF
  {
    int opt_val = 1342 * 1260 * 20; // M2_MSOP * 2
    int opt_len = sizeof(uint32_t);
    opt_val = (opt_val + 1024) / 1024 * 1024;
    int opt_val_before = 0, opt_val_after = 0;
    getsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char*)&opt_val_before, &opt_len);
    
    std::cout << "SO_RCVBUF before: " << opt_val_before << std::endl;
    setsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char*)&opt_val, opt_len);

    getsockopt(fd, SOL_SOCKET, SO_RCVBUF, (char*)&opt_val_after, &opt_len);
    std::cout << "SO_RCVBUF after: " << opt_val_after << std::endl;
  }
#endif


  {
    u_long mode = 1;
    ret = ioctlsocket(fd, FIONBIO, &mode);
    if (ret < 0)
    {
      perror("ioctlsocket: ");
      goto failNonBlock;
    }
  }

  return fd;

failNonBlock:
failGroup:
failBind:
failOption:
  closesocket(fd);
failSocket:
  return -1;
}


inline RS0352HeaderType InputUdpStream::getRawDataHeaderType(uint8_t* raw_data, int nowCnt)
{
  int hexIdx_1 = nowCnt;
  int hexIdx_type = hexIdx_1 + 5;
  uint8_t hex1 = (uint8_t)(raw_data[hexIdx_1]);
  uint8_t hex2 = (uint8_t)(raw_data[hexIdx_1 + 1]);
  uint8_t hex3 = (uint8_t)(raw_data[hexIdx_1 + 2]);
  uint8_t hex4 = (uint8_t)(raw_data[hexIdx_1 + 3]);
  uint8_t data_type = (uint8_t)(raw_data[hexIdx_type]);
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    )
  {
    if (data_type == 0x1)
    {
      return RS0352HeaderType::MSOP;
    }
    if (data_type == 0x2)
    {
      return RS0352HeaderType::IMU;
    }
    if (data_type == 0x3)
    {
      return RS0352HeaderType::DIFOP;
    }

    return RS0352HeaderType::Other;
  }
  return RS0352HeaderType::INVALID;
}

inline RS0352HeaderType InputUdpStream::getHeaderType(int nowCnt)
{
  int hexIdx_1 = nowCnt;
  int hexIdx_type = hexIdx_1 + 5;
  uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]);
  uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]);
  uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]);
  uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]);
  uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]);
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    )
  {
    if (data_type == 0x1)
    {
      //printf("%04d %02X %02X %02X %02X type:%02d\n", nowCnt, hex1, hex2, hex3, hex4, (int)(RS0352HeaderType::MSOP));
      return RS0352HeaderType::MSOP;
    }
    if (data_type == 0x2)
    {
      //printf("%04d %02X %02X %02X %02X type:%02d\n", nowCnt, hex1, hex2, hex3, hex4, (int)(RS0352HeaderType::IMU));
      return RS0352HeaderType::IMU;
    }
    if (data_type == 0x3)
    {
      //printf("%04d %02X %02X %02X %02X type:%02d\n", nowCnt, hex1, hex2, hex3, hex4, (int)(RS0352HeaderType::DIFOP));
      return RS0352HeaderType::DIFOP;
    }
    //printf("%04d %02X %02X %02X %02X type:%02d\n", nowCnt, hex1, hex2, hex3, hex4, (int)(RS0352HeaderType::Other));
    return RS0352HeaderType::Other;
  }
  //printf("%04d %02X %02X %02X %02X type:%02d\n", nowCnt, hex1, hex2, hex3, hex4, (int)(RS0352HeaderType::INVALID));
  return RS0352HeaderType::INVALID;
}

inline int InputUdpStream::recvPacket()
{
  if ((!switch_to10m_succ_) && (!start_trying_flag_))
  {
    sendSwitchCmd();
    int msop_fd = createSocket(input_param_.msop_port, input_param_.host_address, input_param_.group_address);
    if (msop_fd < 0)
    {
      return 0;
    }
    fds_[0] = msop_fd;
    start_trying_flag_ = true;
    std::cout << "create msop fd." << std::endl;
    return 0;
  }
  if ((!switch_to10m_succ_) && (start_trying_flag_))
  {
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(fds_[0], &rfds);
    
    struct timeval tv;
    tv.tv_sec = 1;
    tv.tv_usec = 0;
    int retval = select(fds_[0] + 1, &rfds, NULL, NULL, &tv);
    if (retval == 0)
    {
      cb_excep_(obj_, Error(ERRCODE_MSOPTIMEOUT));
      return 0;
    }
    else if (retval < 0)
    {
      if (WSAGetLastError() == WSAEINTR)
        return 0;

      perror("select: ");
      return -1;
    }
    int ret;
    if ((fds_[0] >= 0) && FD_ISSET(fds_[0], &rfds))
    {
      uint8_t* raw_eth_data = new uint8_t[ETH_LEN];
      ret = recvfrom(fds_[0], (char*)raw_eth_data, ETH_LEN, 0, NULL, NULL);
      if (ret < 0)
      {
        perror("recvfrom: ");
        return 0;
      }
      myCnt_++;
      int dataLen = ret - sock_offset_ - sock_tail_;
      //std::cout << " > dataLen: " << dataLen << std::endl;
      int idx = 0;
      while (idx < dataLen)
      {
        if (idx > dataLen - WINDOW_SIZE_0352_OFFSET)
        {
          break;
        }
        RS0352HeaderType res = getRawDataHeaderType(raw_eth_data, idx); // THis lIne TODODOO
        if ((res != RS0352HeaderType::INVALID) && (res != RS0352HeaderType::Other))
        {
          switch_to10m_succ_ = true;
          closesocket(send_fd_);
          std::cout << "Switch to 10M mode - Succ." << std::endl;

          closesocket(fds_[0]);
          std::cout << "close msop fd." << std::endl;
          myCnt_ = 0;
          start_trying_flag_ = false;
          break;
        }
        idx++;
      }
      delete raw_eth_data;
      if (switch_to10m_succ_)
      {
        return 1;
      }
    }
    if (myCnt_ > 200)
    {
      closesocket(fds_[0]);
      std::cout << "close msop fd." << std::endl;
      myCnt_ = 0;
      start_trying_flag_ = false;
      return 0;
    }
  }
  if ((switch_to10m_succ_) && (!re_connect_flag_))
  {
    int msop_fd = createSocket(input_param_.msop_port, input_param_.host_address, input_param_.group_address);
    if (msop_fd < 0)
    {
      return 0;
    }
    fds_[0] = msop_fd;
    std::cout << "RE - create msop fd." << std::endl;
    re_connect_flag_ = true;
    return 0;
  }
  if ((switch_to10m_succ_) && (re_connect_flag_))
  {
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(fds_[0], &rfds);
    
    struct timeval tv;
    tv.tv_sec = 1;
    tv.tv_usec = 0;
    int retval = select(fds_[0] + 1, &rfds, NULL, NULL, &tv);
    if (retval == 0)
    {
      cb_excep_(obj_, Error(ERRCODE_MSOPTIMEOUT));
      return 0;
    }
    else if (retval < 0)
    {
      if (errno == EINTR)
        return 0;

      perror("select: ");
      return -1;
    }
  
    if ((fds_[0] >= 0) && FD_ISSET(fds_[0], &rfds))
    {
      uint8_t* recv_buffer = new uint8_t[ETH_LEN];
      int ret = recvfrom(fds_[0], (char*)recv_buffer, ETH_LEN, 0, NULL, NULL);
      if (ret < 0)
      {
        perror("recvfrom: ");
        return -1;
      }
      else if (ret > 0)
      {
        int dataLen = ret - sock_offset_ - sock_tail_;
        procRecvData(recv_buffer, dataLen);
      }
      delete recv_buffer;
    }
  }
  return 0;
}

}
}

