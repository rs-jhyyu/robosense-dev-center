#pragma once

#ifdef _WIN32

#include <rs_driver/driver/input/win/input_udp_stream.hpp>

#else  //__linux__

#include <rs_driver/driver/input/unix/input_udp_stream.hpp>

#endif

namespace robosense
{
namespace lidar
{


inline void InputUdpStream::procRecvData(uint8_t* recv_buffer, int dataLen)
{
  //std::cout << "dataLen : " << dataLen << std::endl;
    int bytes_recv = dataLen;
    memset(readBuffer, 0, sizeof(readBuffer));
    //RS_WARNING << " recv : " << bytes_recv << RS_REND;
    std::vector<PktInfo0352> infos;
    // Merge Data
    if (tail_tmp_buffer_.size() > 0)
    {
      for (int i = 0; i < tail_tmp_buffer_.size(); i++)
      {
        readBuffer[i] = tail_tmp_buffer_.at(i);
      }
    }
    memcpy(readBuffer + tail_tmp_buffer_.size(), recv_buffer, bytes_recv);
    int mergedLen = bytes_recv + tail_tmp_buffer_.size();

    tail_tmp_buffer_.clear();
    tail_tmp_buffer_.resize(0);
    
    int idx = 0;
    while (idx < mergedLen)
    {
      if (idx > mergedLen - WINDOW_SIZE_0352_OFFSET){ 
        break; 
      }
      int hexIdx_1 = idx;
      int hexIdx_type = hexIdx_1 + 5;
      uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]); //-|
      uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]); //-|
      uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]); //-|
      uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]); //-|
      uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]); //-|
      if ((hex1 == RS0352_HEADER_ID1)
        && (hex2 == RS0352_HEADER_ID2)
        && (hex3 == RS0352_HEADER_ID3)
        && (hex4 == RS0352_HEADER_ID4)
        )
      {
        PktInfo0352 pi;
        if (data_type == 0x1) { pi.type = "MSOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x2) { pi.type = "IMU"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x3) { pi.type = "DIFOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
      }
      idx++;
    } // end of WHILE LOOP
    //std::cout << std::endl;
    if (infos.size() <= 1)
    {
      for (int i = 0; i < mergedLen; i++)
      {
        tail_tmp_buffer_.emplace_back(readBuffer[i]);
      }
    }
    if (infos.size() >= 2)
    {
      bool notGood = false;

      for (int k = 1; k < infos.size(); k++)
      {
          //std::cout << " @" << infos[k - 1].type << " : " <<  infos[k - 1].dataIdx
          //          << " next:> " << infos[k].dataIdx << std::endl;

        int offset = infos[k].dataIdx - infos[k - 1].dataIdx;
        int expectLen = 0;
        if (infos[k - 1].type == "MSOP") { expectLen = RS0352_PKT_LEN; }
        if (infos[k - 1].type == "IMU") { expectLen = RS0352_IMUPKT_LEN; }
        if (infos[k - 1].type == "DIFOP") { expectLen = RS0352_DIFOPPKT_LEN; }


        if (offset >= expectLen)
        {
          if (offset > expectLen)
          {
            notGood = true;
            std::cout << " @" << infos[k - 1].type << " : " <<  infos[k - 1].dataIdx
                      << " next:> " << infos[k].dataIdx << " offset: " << offset << std::endl;
          }
          std::shared_ptr<Buffer> pkt = cb_get_pkt_(ETH_LEN);
          memcpy(pkt->data(), readBuffer + infos[k - 1].dataIdx, expectLen); //-|
          pkt->setData(0, expectLen);
          pushPacket(pkt);
        }
        else
        {
          if (offset == expectLen - 1)
          {
            //std::cout << " >> lost CRC @" << infos[k - 1].type << " : " <<  infos[k - 1].dataIdx
            //        << " next:> " << infos[k].dataIdx << " offset: " << offset << std::endl;
            std::shared_ptr<Buffer> pkt = cb_get_pkt_(ETH_LEN);
            memcpy(pkt->data(), readBuffer + infos[k - 1].dataIdx, offset); //-|
            pkt->setData(0, expectLen);
            pushPacket(pkt);
          }
          else
          {
            std::cout << " @" << infos[k - 1].type << " : " <<  infos[k - 1].dataIdx
                    << " next:> " << infos[k].dataIdx << " offset: " << offset << std::endl;
          }
        }

      }
      int copy_start_idx = infos[infos.size() - 1].dataIdx;
      for (int i = copy_start_idx; i < mergedLen; i++)
      {
        tail_tmp_buffer_.emplace_back(readBuffer[i]);
      }
      //if (notGood)
      //  std::cout << " || pktno: " << read_pkt_cnt_ << "\n" << std::endl;
    }
    memset(readBuffer, 0, sizeof(readBuffer));

  return;

}

}  // namespace lidar
}  // namespace robosense
