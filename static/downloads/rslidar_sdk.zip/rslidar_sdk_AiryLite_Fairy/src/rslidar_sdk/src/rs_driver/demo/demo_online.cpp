/*********************************************************************************************************************
Copyright (c) 2020 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#include <rs_driver/api/lidar_driver.hpp>

#ifdef ENABLE_PCL_POINTCLOUD
#include <rs_driver/msg/pcl_point_cloud_msg.hpp>
#else
#include <rs_driver/msg/point_cloud_msg.hpp>
#endif

#define ENABLE_IMU_PARSE
//#define ORDERLY_EXIT

typedef PointXYZIRTF PointT;
typedef PointCloudT<PointT> PointCloudMsg;

using namespace robosense::lidar;

SyncQueue<std::shared_ptr<PointCloudMsg>> free_cloud_queue;
SyncQueue<std::shared_ptr<PointCloudMsg>> stuffed_cloud_queue;

SyncQueue<std::shared_ptr<ImuData>> free_imu_data_queue;
SyncQueue<std::shared_ptr<ImuData>> stuffed_imu_data_queue;
LidarDriver<PointCloudMsg> driver;               ///< Declare the driver object
//
// @brief point cloud callback function. The caller should register it to the lidar driver.
//        Via this fucntion, the driver gets an free/unused point cloud message from the caller.
// @param msg  The free/unused point cloud message.
//
std::shared_ptr<PointCloudMsg> driverGetPointCloudFromCallerCallback(void)
{
  // Note: This callback function runs in the packet-parsing/point-cloud-constructing thread of the driver, 
  //       so please DO NOT do time-consuming task here.
  std::shared_ptr<PointCloudMsg> msg = free_cloud_queue.pop();
  if (msg.get() != NULL)
  {
    return msg;
  }

  return std::make_shared<PointCloudMsg>();
}

//
// @brief point cloud callback function. The caller should register it to the lidar driver.
//        Via this function, the driver gets/returns a stuffed point cloud message to the caller. 
// @param msg  The stuffed point cloud message.
//
void driverReturnPointCloudToCallerCallback(std::shared_ptr<PointCloudMsg> msg)
{
  // Note: This callback function runs in the packet-parsing/point-cloud-constructing thread of the driver, 
  //       so please DO NOT do time-consuming task here. Instead, process it in caller's own thread. (see processCloud() below)
  stuffed_cloud_queue.push(msg);
}

//
// @brief imu data callback function. The caller should register it to the lidar driver.
//        Via this function, the driver gets/returns an imu data message to the caller. 
// @param msg  The imu data message.
std::shared_ptr<ImuData> driverGetIMUDataFromCallerCallback(void)
{
  // Note: This callback function runs in the packet-parsing/imu-data-constructing thread of the driver, 
  //       so please DO NOT do time-consuming task here.
  std::shared_ptr<ImuData> msg = free_imu_data_queue.pop();
  if (msg.get() != NULL)
  {
    return msg;
  }

  return std::make_shared<ImuData>();
}

// @brief imu data callback function. The caller should register it to the lidar driver.
      
void driverReturnImuDataToCallerCallback(const std::shared_ptr<ImuData>& msg)
{
  stuffed_imu_data_queue.push(msg);
}


bool to_exit_process = false;
void processImuData(void)
{
  uint32_t imu_cnt = 0;
  while (!to_exit_process)
  {
    std::shared_ptr<ImuData> msg = stuffed_imu_data_queue.popWait();
    if (msg.get() == NULL)
    {
      continue;
    }

    // Well, it is time to process the point cloud msg, even it is time-consuming.
    RS_MSG << "msg: " << imu_cnt << " imu data ts: " <<std::dec<<std::to_string(msg->timestamp) << RS_REND;

    imu_cnt++;
#if 0
    RS_DEBUG  <<"imu data: " << " , linear_a_x" << msg->linear_acceleration_x 
      << " , linear_a_y " << msg->linear_acceleration_y << "  , linear_a_z" << msg->linear_acceleration_z   
      << " , angular_v_x " << msg->angular_velocity_x << " , angular_v_y" << msg->angular_velocity_y 
      << " , angular_v_z" <<msg->angular_velocity_z << RS_REND;
#endif

    free_imu_data_queue.push(msg);


  }

}
//
// @brief exception callback function. The caller should register it to the lidar driver.
//        Via this function, the driver inform the caller that something happens.
// @param code The error code to represent the error/warning/information
//
void exceptionCallback(const Error& code)
{
  // Note: This callback function runs in the packet-receving and packet-parsing/point-cloud_constructing thread of the driver, 
  //       so please DO NOT do time-consuming task here.
  RS_WARNING << code.toString() << RS_REND;
}

void printLidarInfo()
{
  DeviceInfo device_info;
  driver.getDeviceInfo(device_info);
  DeviceStatus device_status;
  driver.getDeviceStatus(device_status);
  
  if (device_info.state)
  {
    std::string snString = " SN: ";
    for (int i = 0; i < sizeof(device_info.sn); i++)
    {
      char sn_str[10];
      sprintf(sn_str, "%02X", device_info.sn[i]);
      snString += std::string(sn_str);
    }

    std::string topVerString = " PL Ver: ";
    for (int i = 0; i < sizeof(device_info.top_ver); i++)
    {
      char top_ver_str[10];
      sprintf(top_ver_str, "%02X", device_info.top_ver[i]);
      topVerString += std::string(top_ver_str);
    }

    std::string appVerString = " PS Ver: ";
    for (int i = 0; i < sizeof(device_info.bottom_ver); i++)
    {
      char app_ver_str[10];
      sprintf(app_ver_str, "%02X", device_info.bottom_ver[i]);
      appVerString += std::string(app_ver_str);
    }

    std::string motVerString = " Motor Ver: ";
    for (int i = 0; i < sizeof(device_info.mot_ver); i++)
    {
      char mot_ver_str[10];
      sprintf(mot_ver_str, "%02X", device_info.mot_ver[i]);
      motVerString += std::string(mot_ver_str);
    }
    RS_MSG << snString << topVerString << appVerString << motVerString << RS_REND;
  }

  /*  vdc_top_vbus     -> 主板总输入电压         (V)    */ 
  /*  vdc_rx_vbd_p     -> 主板RX-459的VBD电压 P (V)    */
  /*  vdc_rx_vbd_n     -> 主板RX-459的VBD电压 N (V)    */
  /*  current_bot_vbus -> 底板无线供电输入电流    (A)    */
  /*  temp_top_rx_n    -> 主板RX-459温度N端     (℃)    */
  /*  temp_top_rx_p    -> 主板RX-459温度P端     (℃)    */
  /*  temp_bot_imu     -> 底板IMU温度           (℃)   */
  /*  pwm_top          -> 主板磁环PWM频率       (kHz)   */
  /*  volatge_bot_vbus -> 底板外部供电输入电压    (V)    */
  /*  current_board_a  -> 主板电控A相采样电流    (mA)    */
  /*  current_board_b  -> 主板电控B相采样电流    (mA)    */
  /*  current_board_c  -> 主板电控C相采样电流    (mA)    */
  /*  pps_lock_flag    -> GPS PPS锁定标志  */
  /*  gprmc_flag       -> GPRMC输入状态    */
  /*  pps_lock_flag    -> GPS PPS输入状态  */
  /*  power_top_state   -> 顶板上电状态     */
  /*  eye_safe_state    -> eyesafe状态指示     */
  /*  eye_safe_en_state  -> eyesafe开关     */

  if (device_status.state)
  {
    RS_DEBUG << "vdc_top_vbus      -> " << device_status.vdc_top_vbus     << " V"   << RS_REND;
    RS_DEBUG << "vdc_rx_vbd_p      -> " << device_status.vdc_rx_vbd_p     << " V"   << RS_REND;
    RS_DEBUG << "vdc_rx_vbd_n      -> " << device_status.vdc_rx_vbd_n     << " V"   << RS_REND;
    RS_DEBUG << "current_bot_vbus  -> " << device_status.current_bot_vbus << " A"   << RS_REND;
    RS_DEBUG << "temp_top_rx_n     -> " << device_status.temp_top_rx_n    << " ℃"   << RS_REND;
    RS_DEBUG << "temp_top_rx_p     -> " << device_status.temp_top_rx_p    << " ℃"   << RS_REND;
    RS_DEBUG << "temp_bot_imu      -> " << device_status.temp_bot_imu     << " ℃"   << RS_REND;
    RS_DEBUG << "pwm_top           -> " << device_status.pwm_top          << " kHz"  << RS_REND;
    RS_DEBUG << "volatge_bot_vbus  -> " << device_status.volatge_bot_vbus << " V"    << RS_REND;
    RS_DEBUG << "current_board_a   -> " << device_status.current_board_a  << " mA"   << RS_REND;
    RS_DEBUG << "current_board_b   -> " << device_status.current_board_b  << " mA"   << RS_REND;
    RS_DEBUG << "current_board_c   -> " << device_status.current_board_c  << " mA"   << RS_REND;
    RS_DEBUG << "power_top_state -> " << device_status.power_top_state << RS_REND;
    RS_DEBUG << "eye_safe_state  -> " << device_status.eye_safe_state  << RS_REND;
    RS_DEBUG << "eye_safe_en_state -> " << device_status.eye_safe_en_state << RS_REND;
    RS_DEBUG << "GPS pps_lock_flag  -> " << device_status.pps_lock_flag   << RS_REND;
    RS_DEBUG << "GPS gprmc_flag     -> " << device_status.gprmc_flag      << RS_REND;
    RS_DEBUG << "GPS pps_input_flag -> " << device_status.pps_input_flag  << RS_REND;
  }
}


void processCloud(void)
{
  while (!to_exit_process)
  {
    std::shared_ptr<PointCloudMsg> msg = stuffed_cloud_queue.popWait();
    if (msg.get() == NULL)
    {
      continue;
    }

    // Well, it is time to process the point cloud msg, even it is time-consuming.
    RS_MSG << "msg: " << msg->seq << " point cloud size: " << msg->points.size() << " ts : " << msg->timestamp << RS_REND;
    //printLidarInfo();
#if 0
    for (auto it = msg->points.begin(); it != msg->points.end(); it++)
    {
      std::cout << std::fixed << std::setprecision(3) 
                << "(" << it->x << ", " << it->y << ", " << it->z << ", " << (int)it->intensity << ")" 
                << std::endl;
    }
#endif

    free_cloud_queue.push(msg);


  }
}

int main(int argc, char* argv[])
{
  RS_TITLE << "------------------------------------------------------" << RS_REND;
  RS_TITLE << "            RS_Driver Core Version: v" << getDriverVersion() << RS_REND;
  RS_TITLE << "------------------------------------------------------" << RS_REND;

  RSDriverParam param;                  ///< Create a parameter object
  
  /* AIRYLIE UDP MODE PCAP */
  param.input_type = InputType::UDP_STREAM;
  param.input_param.group_address = "0.0.0.0";
  param.input_param.host_address = "192.168.1.102";
  param.input_param.msop_port = 6699;   ///< Set the lidar msop port number, the default is 6699
  param.input_param.difop_port = 7788;  ///< Set the lidar difop port number, the default is 7788
  
  param.lidar_type = LidarType::RSAIRYLITE;   ///< Set the lidar type. Make sure this type is correct
  
  /* AIRYLIE SERIAL PORT 4M (DUAL) */
  param.lidar_type = LidarType::RSAIRYLITE_ETH;
  param.input_type = InputType::ONLINE_LIDAR;
  // param.input_param.input_serial_param.BAUD_RATE = 4000000;
  // param.input_param.input_serial_param.PORT_NAME = "/dev/ttyCH343USB0";
  // param.input_param.input_serial_param.PORT_NAME2 = "/dev/ttyCH343USB3";
  // param.input_param.input_serial_param.RS485_PKT_LEN = 104;
  // param.input_param.input_serial_param.MSOP_ID_LEN = 4;
  // param.input_param.input_serial_param.MSOP_ID[0] = 0x5A;
  // param.input_param.input_serial_param.MSOP_ID[1] = 0xFF;
  // param.input_param.input_serial_param.MSOP_ID[2] = 0x55;
  // param.input_param.input_serial_param.MSOP_ID[3] = 0xAA;

  /* AIRYLIE SERIAL PORT 10M */
  //param.lidar_type = LidarType::RSAIRYLITE;
  //param.input_type = InputType::RS485_LIDAR;
  //param.input_param.input_serial_param.BAUD_RATE = 10000000;
  //param.input_param.input_serial_param.PORT_NAME = "/dev/ttyCH343USB0";
  //param.input_param.input_serial_param.PORT_NAME2 = "";
  //param.input_param.input_serial_param.RS485_PKT_LEN = 104;
  //param.input_param.input_serial_param.MSOP_ID_LEN = 4;
  //param.input_param.input_serial_param.MSOP_ID[0] = 0x5A;
  //param.input_param.input_serial_param.MSOP_ID[1] = 0xFF;
  //param.input_param.input_serial_param.MSOP_ID[2] = 0x55;
  //param.input_param.input_serial_param.MSOP_ID[3] = 0xAA;

  param.print();
   
  //LidarDriver<PointCloudMsg> driver;               ///< Declare the driver object
  driver.regPointCloudCallback(driverGetPointCloudFromCallerCallback, driverReturnPointCloudToCallerCallback); ///< Register the point cloud callback functions
  driver.regExceptionCallback(exceptionCallback);  ///< Register the exception callback function
#ifdef ENABLE_IMU_PARSE
  driver.regImuDataCallback(driverGetIMUDataFromCallerCallback, driverReturnImuDataToCallerCallback);
#endif

  if (!driver.init(param))                         ///< Call the init function
  {
    RS_ERROR << "Driver Initialize Error..." << RS_REND;
    return -1;
  }

  std::thread cloud_handle_thread = std::thread(processCloud);
#ifdef ENABLE_IMU_PARSE
  std::thread imuData_handle_thread = std::thread(processImuData);
#endif
  driver.start();  ///< The driver thread will start
  RS_DEBUG << "RoboSense Lidar-Driver Linux online demo start......" << RS_REND;

#ifdef ORDERLY_EXIT
  std::this_thread::sleep_for(std::chrono::seconds(10));

  driver.stop();

  to_exit_process = true;
  cloud_handle_thread.join();
#else
  //std::this_thread::sleep_for(std::chrono::seconds(2));
  //DeviceInfo deviceInfo;
  //if(driver.getDeviceInfo(deviceInfo))
  //{
  //  RS_DEBUG << "qx: " <<  std::fixed << std::setprecision(7)  << deviceInfo.qx  << ",qy:" << deviceInfo.qy << ",qz:" << deviceInfo.qz << ",qw:" << deviceInfo.qw  << ",x:" << deviceInfo.x << ",y:" << deviceInfo.y << ",z:" << deviceInfo.z << std::endl;
  //}else{
  //  RS_WARNING << "get device info failed" << RS_REND;
  //}
  while (true)
  {
    std::this_thread::sleep_for(std::chrono::seconds(1));
  }
#endif

  return 0;
}
