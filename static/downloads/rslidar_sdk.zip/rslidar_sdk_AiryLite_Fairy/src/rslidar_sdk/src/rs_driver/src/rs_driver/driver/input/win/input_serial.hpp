/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once
#include <rs_driver/driver/input/input.hpp>
#include <windows.h>
#include <iostream>
#include <fstream>
#include <io.h>
#include <process.h>
#include <cstring>
#include <string>
#include <sstream>
#include <iomanip>
#ifdef UNICODE
#define CreateFilePort CreateFileW
#else
#define CreateFilePort CreateFileA
#endif

namespace robosense
{
namespace lidar
{

class SerialPort {
  private:
      HANDLE hComm;
      DCB dcbSerialParams;
      COMMTIMEOUTS timeouts;
   
  public:
      SerialPort();
      ~SerialPort();
      bool open();
      bool close();
      bool read(uint8_t* buffer, int bufferSize, int& bytesRead);
      bool write(const char* buffer, int bufferSize, int& bytesWritten);
      std::string the_port_name_inner_;
	    int serial_baud_rate_inner_;
  };
   
inline SerialPort::SerialPort() {
    hComm = INVALID_HANDLE_VALUE;
    SecureZeroMemory(&dcbSerialParams, sizeof(DCB));
    SecureZeroMemory(&timeouts, sizeof(COMMTIMEOUTS));
}
 
inline SerialPort::~SerialPort() {
    close();
}

inline bool SerialPort::open() {  
  char szPort[15] = {0};

  std::string portName = the_port_name_inner_;
  int baudRate = serial_baud_rate_inner_;

  std::string str_format="\\\\.\\";
  str_format+=portName;
  const char* c_port = str_format.c_str();  // 根据实际串口修改
  printf("Actually Open: >>>>>> %s\n", c_port);
  //////////////////////////////////////////////////
  std::cout << "baud rate: " << baudRate << std::endl;
  hComm = CreateFile(c_port, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
  //hComm = CreateFileA(portName.c_str(), GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if (hComm == INVALID_HANDLE_VALUE) {
      std::cout << "Serial Port [CANNOT] Open!" << std::endl;
      return false;
  }
  dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
  
  if (!GetCommState(hComm, &dcbSerialParams)) {
      std::cout << "Serial Port [Status RECV FAIL] !" << std::endl;
      close();
      return false;
  }
  dcbSerialParams.BaudRate = baudRate;//设置的波特率、数据位、停止位和校验方式。dcbSerialParams
  dcbSerialParams.ByteSize = 8;
  dcbSerialParams.StopBits = ONESTOPBIT;
  dcbSerialParams.Parity = NOPARITY;
  if (!SetCommState(hComm, &dcbSerialParams)) {
      std::cout << "Serial Port [Status SET FAIL] !" << std::endl;
      DWORD err = GetLastError();
      // 输出或记录错误码
      printf("SetCommState failed, error code: %d\n", err);
      close();
      return false;
  }
  timeouts.ReadIntervalTimeout = 50;
  timeouts.ReadTotalTimeoutConstant = 50;
  timeouts.ReadTotalTimeoutMultiplier = 10;
  timeouts.WriteTotalTimeoutConstant = 50;
  timeouts.WriteTotalTimeoutMultiplier = 10;
  if (!SetCommTimeouts(hComm, &timeouts)) {
      std::cout << "Serial Port [COFIG TOMEOUT] !" << std::endl;
      close();
      return false;
  }
  return true;
}
 
inline bool SerialPort::close() {
    if (hComm != INVALID_HANDLE_VALUE) {
        CloseHandle(hComm);
        hComm = INVALID_HANDLE_VALUE;
    }
    return true;
}
 
inline bool SerialPort::read(uint8_t* buffer, int bufferSize, int& bytesRead) {
    return ReadFile(hComm, buffer, bufferSize, (LPDWORD)&bytesRead, NULL);
}
 
inline bool SerialPort::write(const char* buffer, int bufferSize, int& bytesWritten) {
    return WriteFile(hComm, buffer, bufferSize, (LPDWORD)&bytesWritten, NULL);
}

class InputSerial : public Input
{
public:
  InputSerial(const RSInputParam& input_param, int portNo)
    : Input(input_param), pkt_buf_len_(ETH_LEN), mode_flag_4m_(false)
  {
    RS_INFO << "init serial port: " << RS_REND;
    std::cout << "SERIAL DEV: " << input_param.input_serial_param.PORT_NAME << std::endl;
    if (input_param.rs0352_using_dual_port)
    {
      std::cout << "SERIAL DEV2: " << input_param.input_serial_param.PORT_NAME2 << std::endl;
    }
    std::cout << "BAUD RATE: " << input_param.input_serial_param.BAUD_RATE << std::endl;
    std::cout << "PACKET LEN: " << input_param.input_serial_param.RS485_PKT_LEN << std::endl;
    std::cout << "MSOP ID LEN: " << (uint16_t)input_param.input_serial_param.MSOP_ID_LEN << std::endl;
    std::cout << "MSOP ID: ";
    for (int i = 0; i < input_param.input_serial_param.MSOP_ID_LEN; i++)
    {
      std::cout << std::hex << (uint16_t)input_param.input_serial_param.MSOP_ID[i] << " ";
    }
    std::cout << std::dec << std::endl;
    
    the_port_name_ = input_param.input_serial_param.PORT_NAME;
    if (input_param.rs0352_using_dual_port)
    {
      the_port_name2_ = input_param.input_serial_param.PORT_NAME2;
      mode_flag_4m_ = true;
    }
	  serial_baud_rate_ = input_param.input_serial_param.BAUD_RATE;
    open_succ_ = false;

    port_no_ = portNo;
  }
  virtual bool init();
  virtual int recvPacket() override;
  virtual ~InputSerial();
  virtual bool closeInputPorts() override;

  RS0352HeaderType getHeaderType(int nowCnt);
  std::string HeaderTypeToStr(RS0352HeaderType type);
  void ejectForcely(int validCnt);

protected:
  
  bool isValidHeader(uint8_t hex1, uint8_t hex2, uint8_t hex3, uint8_t hex4, uint8_t data_type);
  size_t pkt_buf_len_;
  //int fds_[2];
  int fd;
  fd_set read_fds;
  unsigned char readBuffer[RS0352_READ_BUFFER_SIZE];
  unsigned char msopPktBuffer[RS0352_PKT_LEN];

  bool is_meet_cur_pack_;
  int valid_cnt_;
  SerialPort serial_port_;
  RSInputSerialParam input_serial_param_;
  //size_t sock_offset_;
  //size_t sock_tail_;
  long header_cnt_;
  long push_cnt_;
  long drop_cnt_;
  float last_angle_;
  std::string the_port_name_;
  std::string the_port_name2_;
  int serial_baud_rate_;

  bool cont_search_;
  int valid_header_idx_;
  bool has_get_one_header_;

  bool open_succ_;

  RS0352HeaderType cur_data_type_;
  //uint8_t tail_tmp_buffer_[ONCE_BUFFER_SIZE];
  std::vector<uint8_t> tail_tmp_buffer_;
  int tail_buffer_size_;

  int has_unknown_data_type_;

  int port_no_;

  int last_cnt_;
  std::vector<int> recv_len_con_;
  bool mode_flag_4m_;
};

inline bool InputSerial::init()
{
  if (port_no_ == 1)
    serial_port_.the_port_name_inner_ = the_port_name_;
  else if (port_no_ == 2)
    serial_port_.the_port_name_inner_ = the_port_name2_;
  else
    std::cout << "error 100" << std::endl;
  serial_port_.serial_baud_rate_inner_ = serial_baud_rate_;
  std::cout << "serial_port_.the_port_name >> " << serial_port_.the_port_name_inner_ 
  << " size: " << serial_port_.the_port_name_inner_.size() << std::endl;
  fd = serial_port_.open();
  if (!fd)
  {
      return false;
  }
  else
  {
    std::cout << "Serial Port is Open!" << std::endl;
    open_succ_ = true;
  }

  memset(readBuffer, 0, RS0352_READ_BUFFER_SIZE);
  //memset(tail_tmp_buffer_, 0 ,sizeof(tail_tmp_buffer_));

  is_meet_cur_pack_ = false;
  valid_cnt_ = 0;
  drop_cnt_ = 0;
  last_angle_ = -100.0;
  cont_search_ = false;
  has_get_one_header_ = false;

  push_cnt_ = 0;

  // state variables
  cur_data_type_ = RS0352HeaderType::INVALID;
  cont_search_ = false;
  valid_header_idx_ = -1;
  tail_buffer_size_ = 0;

  has_unknown_data_type_ = -1;
  last_cnt_ = -1;
  return true;
}

inline InputSerial::~InputSerial()
{}

inline bool InputSerial::isValidHeader(uint8_t hex1, uint8_t hex2, uint8_t hex3, uint8_t hex4, uint8_t data_type)
{
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    && (data_type == 0x1))
  {
    return true;
  }
  return false;
}

inline bool InputSerial::closeInputPorts()
{
  if (open_succ_)
  {
    try
    {
      bool ret = false;
      ret = serial_port_.close();
      if (ret)
      {
        RS_DEBUG << "Serial Port Closed." << RS_REND;
        return true;
      }
    }
    catch(const std::exception& e)
    {
      std::cerr << e.what() << '\n';
    }
    RS_ERROR << "Serial Port Failed to close ... !!" << RS_REND;
  } 
  else
  {
    RS_WARNING << "No Serial Connection ..." << RS_REND;
  }

  return false;
}

}  // namespace lidar
}  // namespace robosense




