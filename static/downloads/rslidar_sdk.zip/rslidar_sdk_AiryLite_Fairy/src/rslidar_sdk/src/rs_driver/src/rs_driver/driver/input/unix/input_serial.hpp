/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/


#pragma once
#include <rs_driver/common/rs_common.hpp>
#include <rs_driver/driver/input/input.hpp>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <iostream>
#include <fstream>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <asm-generic/ioctls.h>
#define termios asmtermios
#include <asm-generic/termbits.h>
#undef termios
#include <termios.h>
#include <linux/serial.h>

static int hardflow = 0;

namespace robosense
{
namespace lidar
{

class InputSerial : public Input
{
public:
  InputSerial(const RSInputParam& input_param, int portNo)
    : Input(input_param), pkt_buf_len_(ETH_LEN), mode_flag_4m_(false)
  {
    RS_INFO << "init serial port: " << RS_REND;
    std::cout << "SERIAL DEV: " << input_param.input_serial_param.PORT_NAME << std::endl;
    if ( !(input_param.input_serial_param.PORT_NAME2.empty()) && 
          (input_param.input_serial_param.BAUD_RATE == 4000000))
    {
      std::cout << "SERIAL DEV2: " << input_param.input_serial_param.PORT_NAME2 << std::endl;
    }
    std::cout << "BAUD RATE: " << input_param.input_serial_param.BAUD_RATE << std::endl;
    std::cout << "PACKET LEN: " << input_param.input_serial_param.RS485_PKT_LEN << std::endl;
    std::cout << "MSOP ID LEN: " << (uint16_t)input_param.input_serial_param.MSOP_ID_LEN << std::endl;
    std::cout << "MSOP ID: ";
    for (int i = 0; i < input_param.input_serial_param.MSOP_ID_LEN; i++)
    {
      std::cout << std::hex << (uint16_t)input_param.input_serial_param.MSOP_ID[i] << " ";
    }
    std::cout << std::dec << std::endl;
    

    the_port_name_ = input_param.input_serial_param.PORT_NAME;
    if ( !(input_param.input_serial_param.PORT_NAME2.empty()) && 
          (input_param.input_serial_param.BAUD_RATE == 4000000))
    {
      the_port_name2_ = input_param.input_serial_param.PORT_NAME2;
      mode_flag_4m_ = true;
    }
	  serial_baud_rate_ = input_param.input_serial_param.BAUD_RATE;
    open_succ_ = false;

    cur_data_type_ = RS0352HeaderType::INVALID;

    valid_header_idx_ = -1;
    tail_buffer_size_ = 0;
    has_unknown_data_type_ = -1;

	  fds_[0] = -1;
    fds_[1] = -1;

	  port_no_ = portNo;

    last_cnt_ = -1;

    this->vec_buffer_.resize(TMP_BUFFER_SIZE);
  }

  int libtty_open(const char *devname);
  //int libtty_setopt(int fd, int speed, int databits, int stopbits, char parity, char hardflow);
  int libtty_setopt(int fd, int speed, int databits, int stopbits, char parity);
  int libtty_setcustombaudrate(int fd, int baudrate);

  virtual bool init();
  virtual bool start();
  void recvPacket();
  int grabPacketData();

  bool closeInputPorts();
  virtual ~InputSerial();

  RS0352HeaderType getHeaderType(int nowCnt);
  std::string HeaderTypeToStr(RS0352HeaderType type);
  void ejectForcely(int validCnt);

protected:
  
  bool isValidHeader(uint8_t hex1, uint8_t hex2, uint8_t hex3, uint8_t hex4, uint8_t data_type);
  size_t pkt_buf_len_;
  fd_set read_fds;
  unsigned char readBuffer[RS0352_READ_BUFFER_SIZE];
  unsigned char msopPktBuffer[RS0352_PKT_LEN];
  std::vector<uint8_t> tmp_buffer_;
  bool is_meet_cur_pack_;
  int valid_cnt_;
  RSInputSerialParam input_serial_param_;
  //size_t sock_offset_;
  //size_t sock_tail_;
  long header_cnt_;
  long push_cnt_;
  long drop_cnt_;
  float last_angle_;
  std::string the_port_name_;
  std::string the_port_name2_;
  int serial_baud_rate_;

  bool cont_search_;
  int valid_header_idx_;
  bool has_get_one_header_;

  bool open_succ_;

  RS0352HeaderType cur_data_type_;
  //uint8_t tail_tmp_buffer_[ONCE_BUFFER_SIZE];
  std::vector<uint8_t> tail_tmp_buffer_;
  int tail_buffer_size_;

  int has_unknown_data_type_;

  int fds_[2];

  int port_no_;

  int last_cnt_;

  std::vector<uint8_t> vec_buffer_;

  std::vector<int> recv_len_con_;
  bool mode_flag_4m_;
};


inline int InputSerial::libtty_open(const char *devname)
{
	int fd = open(devname, O_RDWR | O_NOCTTY | O_NDELAY);
	int flags = 0;

	if (fd < 0) {
		perror("open device failed");
		return -1;
	}

	flags = fcntl(fd, F_GETFL, 0);
	flags &= ~O_NONBLOCK;
	if (fcntl(fd, F_SETFL, flags) < 0) {
		printf("fcntl failed.\n");
		return -1;
	}

	if (isatty(fd) == 0) {
		printf("not tty device.\n");
		return -1;
	} else
		printf("tty device test ok.\n");

	return fd;
}

/**
 * libtty_setcustombaudrate - set baud rate of tty device
 * @fd: device handle
 * @speed: baud rate to set
 *
 * The function return 0 if success, or -1 if fail.
 */
inline int InputSerial::libtty_setcustombaudrate(int fd, int baudrate)
{
	struct termios2 tio;

	if (ioctl(fd, TCGETS2, &tio)) {
		perror("TCGETS2");
		return -1;
	}

	tio.c_cflag &= ~CBAUD;
	tio.c_cflag |= BOTHER;
	tio.c_ispeed = baudrate;
	tio.c_ospeed = baudrate;

  // 设置超时和最小字符数
  tio.c_cc[VMIN] = 0;   // 非阻塞读取
  tio.c_cc[VTIME] = 10; // 1秒超时（以十分之一秒为单位）


	if (ioctl(fd, TCSETS2, &tio)) {
		perror("TCSETS2");
		return -1;
	}

	if (ioctl(fd, TCGETS2, &tio)) {
		perror("TCGETS2");
		return -1;
	}

  //struct serial_struct serial1;
  //ioctl(fd, TIOCGSERIAL, &serial1);  // 获取当前配置
  //serial1.xmit_fifo_size = 16384;    // 增大缓冲区（需驱动支持）
  //ioctl(fd, TIOCSSERIAL, &serial1);

	return 0;
}


/**
 * libtty_setopt - config tty device
 * @fd: device handle
 * @speed: baud rate to set
 * @databits: data bits to set
 * @stopbits: stop bits to set
 * @parity: parity to set
 * @hardflow: hardflow to set
 *
 * The function return 0 if success, or -1 if fail.
 */
//inline int InputSerial::libtty_setopt(int fd, int speed, int databits, int stopbits, char parity, char hardflow)
inline int InputSerial::libtty_setopt(int fd, int speed, int databits, int stopbits, char parity)
{
	struct termios newtio;
	struct termios oldtio;
	int i;

	bzero(&newtio, sizeof(newtio));
	bzero(&oldtio, sizeof(oldtio));

	if (tcgetattr(fd, &oldtio) != 0) {
		perror("tcgetattr");
		return -1;
	}
	newtio.c_cflag |= CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;

	/* set data bits */
	switch (databits) {
	case 5:
		newtio.c_cflag |= CS5;
		break;
	case 6:
		newtio.c_cflag |= CS6;
		break;
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 8:
		newtio.c_cflag |= CS8;
		break;
	default:
		fprintf(stderr, "unsupported data size\n");
		return -1;
	}

	/* set parity */
	switch (parity) {
	case 'n':
	case 'N':
		newtio.c_cflag &= ~PARENB; /* Clear parity enable */
		newtio.c_iflag &= ~INPCK;  /* Disable input parity check */
		break;
	case 'o':
	case 'O':
		newtio.c_cflag |= (PARODD | PARENB); /* Odd parity instead of even */
		newtio.c_iflag |= INPCK;	     /* Enable input parity check */
		break;
	case 'e':
	case 'E':
		newtio.c_cflag |= PARENB;  /* Enable parity */
		newtio.c_cflag &= ~PARODD; /* Even parity instead of odd */
		newtio.c_iflag |= INPCK;   /* Enable input parity check */
		break;
	case 'm':
	case 'M':
		newtio.c_cflag |= PARENB; /* Enable parity */
		newtio.c_cflag |= CMSPAR; /* Stick parity instead */
		newtio.c_cflag |= PARODD; /* Even parity instead of odd */
		newtio.c_iflag |= INPCK;  /* Enable input parity check */
		break;
	case 's':
	case 'S':
		newtio.c_cflag |= PARENB;  /* Enable parity */
		newtio.c_cflag |= CMSPAR;  /* Stick parity instead */
		newtio.c_cflag &= ~PARODD; /* Even parity instead of odd */
		newtio.c_iflag |= INPCK;   /* Enable input parity check */
		break;
	default:
		fprintf(stderr, "unsupported parity\n");
		return -1;
	}

	/* set stop bits */
	switch (stopbits) {
	case 1:
		newtio.c_cflag &= ~CSTOPB;
		break;
	case 2:
		newtio.c_cflag |= CSTOPB;
		break;
	default:
		perror("unsupported stop bits\n");
		return -1;
	}

	//if (hardflow)
		//newtio.c_cflag |= CRTSCTS;
	//else
	//	newtio.c_cflag &= ~CRTSCTS;

	newtio.c_cc[VTIME] = 10; /* Time-out value (tenths of a second) [!ICANON]. */
	newtio.c_cc[VMIN] = 0;	 /* Minimum number of bytes read at once [!ICANON]. */

	tcflush(fd, TCIOFLUSH);

	if (tcsetattr(fd, TCSANOW, &newtio) != 0) {
		perror("tcsetattr");
		return -1;
	}

	/* set tty speed */
	if (libtty_setcustombaudrate(fd, speed) != 0) {
		perror("setbaudrate");
		return -1;
	}

	return 0;
}


inline bool InputSerial::init()
{
  int speed = serial_baud_rate_;
  std::string cur_port_name;
  if (port_no_ == 1)
	  cur_port_name = the_port_name_;
  else if ((port_no_ == 2) && (!the_port_name2_.empty()))
	  cur_port_name = the_port_name2_;
  int fd = libtty_open(cur_port_name.c_str());
  if (fd < 0) {
  	printf("libtty_open: %s error.\n", cur_port_name.c_str());
  	return false;
  }
  int ret;
  //ret = libtty_setopt(fd, speed, 8, 1, 'n', hardflow);
  ret = libtty_setopt(fd, speed, 8, 1, 'n');
  if (ret != 0) {
	printf("libtty_setopt error.\n");
	close(fd);
    return false;
  }
  fds_[port_no_ - 1] = fd;
  RS_INFO << "Serial Port-" << port_no_ << " is Open!" << RS_REND;

  open_succ_ = true;

  memset(readBuffer, 0, RS0352_READ_BUFFER_SIZE);

  is_meet_cur_pack_ = false;
  valid_cnt_ = 0;
  drop_cnt_ = 0;
  last_angle_ = -100.0;
  cont_search_ = false;
  has_get_one_header_ = false;

  tmp_buffer_.clear();
  tmp_buffer_.resize(0);

  push_cnt_ = 0;

  // state variables
  cur_data_type_ = RS0352HeaderType::INVALID;
  cont_search_ = false;
  valid_header_idx_ = -1;
  tail_buffer_size_ = 0;

  //memset(tail_tmp_buffer_, 0 ,sizeof(tail_tmp_buffer_));

  has_unknown_data_type_ = -1;

  init_flag_ = true;
  return true;
}

inline bool InputSerial::start()
{
  if (start_flag_)
  {
    return true;
  }

  if (!init_flag_)
  {
    cb_excep_(Error(ERRCODE_STARTBEFOREINIT));
    return false;
  }

  to_exit_recv_ = false;
  recv_thread_ = std::thread(std::bind(&InputSerial::recvPacket, this));

  start_flag_ = true;
  return true;
}

inline InputSerial::~InputSerial()
{
  closeInputPorts();
}

inline bool InputSerial::isValidHeader(uint8_t hex1, uint8_t hex2, uint8_t hex3, uint8_t hex4, uint8_t data_type)
{
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    && (data_type == 0x1))
  {
    return true;
  }
  return false;
}

inline bool InputSerial::closeInputPorts()
{
  if (open_succ_)
  {
    try  //int fd;
    {
      close(fds_[port_no_ - 1]);
      RS_DEBUG << "Serial Port Closed." << RS_REND;
      return true;
    }
    catch(const std::exception& e)
    {
      std::cerr << e.what() << '\n';
    }
    RS_ERROR << "Serial Port Failed to close ... !!" << RS_REND;
  } 
  else
  {
    RS_WARNING << "No Serial Connection ..." << RS_REND;
  }

  return false;
}

/*
inline int InputSerial::recvPacket()
{
  memset(recvBuffer, 0, sizeof(recvBuffer));
  memset(readBuffer, 0, sizeof(readBuffer));

  int nwrite, nread;
	int retry = 0;
	int total = 0;
	
  nread = read(fd, recvBuffer, sizeof(recvBuffer));

  printf("read %d bytes \n", nread);
  size_t idx = 0;
  if (nread < 104)
  {
    std::cout << " nread < 104 END..." << std::endl;
    std::cout << "recv counts: " << header_cnt_ << std::endl; 
    close(fd);
    return -1;
  }

  while(idx < nread - 4)
  {
    int hexIdx_1 = idx;
    uint8_t hex1 = (uint8_t)(recvBuffer[hexIdx_1]);
    uint8_t hex2 = (uint8_t)(recvBuffer[hexIdx_1 + 1]);
    uint8_t hex3 = (uint8_t)(recvBuffer[hexIdx_1 + 2]);
    uint8_t hex4 = (uint8_t)(recvBuffer[hexIdx_1 + 3]);
    uint8_t data_type = (uint8_t)(recvBuffer[hexIdx_1 + 5]);
    //printf("%02X %02X %02X %02X\n", hex1, hex2, hex3, hex4);
    // THE MOMENT ENCOUNTER ONE HEADER.
    if ((hex1 == RS0352_HEADER_ID1)
      && (hex2 == RS0352_HEADER_ID2)
      && (hex3 == RS0352_HEADER_ID3) 
      && (hex4 == RS0352_HEADER_ID4) 
      && (data_type == 0x1))
    {
      header_cnt_++;
      printf("%02X %02X %02X %02X\n", hex1, hex2, hex3, hex4);
      if (header_cnt_ % 3000 == 0)
      {
        std::cout << "recv counts: " << header_cnt_ << std::endl; 
      }
    }
    idx++;
  }

}
*/


}  // namespace lidar
}  // namespace robosense









