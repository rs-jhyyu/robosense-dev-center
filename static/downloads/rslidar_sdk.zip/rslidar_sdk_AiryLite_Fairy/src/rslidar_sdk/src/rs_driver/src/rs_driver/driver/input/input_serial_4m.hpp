/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/


#pragma once
#include <rs_driver/common/rs_common.hpp>
#include <rs_driver/common/rs_log.hpp>

#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <iostream>
#include <fstream>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <asm-generic/ioctls.h>
#define termios asmtermios
#include <asm-generic/termbits.h>
#undef termios
#include <termios.h>
#include <linux/serial.h>

#include <vector>
#include <functional>

#define SERIAL_READ_ERROR_CODE 99999

namespace robosense
{
namespace lidar
{

typedef std::pair<uint16_t, std::vector<uint8_t>> Packet0352;
typedef std::vector<uint8_t> PacketDifopImu;

static int hardflow = 0;

using Callback = std::function<void(const Packet0352&)>;
using CallbackSeq = std::function<void(const int&, const int&)>;
using CallbackDifop = std::function<void(const PacketDifopImu&, size_t)>;

class InputSerial4M
{
public:
  InputSerial4M(int portNo, std::string device_name, int baud_rate, 
    Callback callback, CallbackSeq callback_seq, CallbackDifop callback_difop_imu)
  {
    RS_INFO << "init serial port: " << portNo << RS_REND;
    
    if (portNo == 1)
        the_port_name_ = device_name;//input_param.input_serial_param.PORT_NAME;
	  if (portNo == 2)
    {
      the_port_name2_ = device_name;
    }
	  serial_baud_rate_ = baud_rate;//input_param.input_serial_param.BAUD_RATE;
    open_succ_ = false;

    cur_data_type_ = RS0352HeaderType::INVALID;

    valid_header_idx_ = -1;
    tail_buffer_size_ = 0;
    has_unknown_data_type_ = -1;

	  fds_[0] = -1;
    fds_[1] = -1;

	  port_no_ = portNo;

    last_cnt_ = -1;

    this->vec_buffer_.resize(TMP_BUFFER_SIZE);
    callback_ = callback;
    callback_seq_ = callback_seq;
    callback_difop_imu_ = callback_difop_imu;
  }

  int libtty_open(const char *devname);
  //int libtty_setopt(int fd, int speed, int databits, int stopbits, char parity, char hardflow);
  int libtty_setopt(int fd, int speed, int databits, int stopbits, char parity);
  int libtty_setcustombaudrate(int fd, int baudrate);

  bool init();
  int recvPacket();
  bool closeInputPorts();
  ~InputSerial4M();

  std::string HeaderTypeToStr(RS0352HeaderType type);

protected:
  
  bool isValidHeader(uint8_t hex1, uint8_t hex2, uint8_t hex3, uint8_t hex4, uint8_t data_type);
  size_t pkt_buf_len_;
  fd_set read_fds;
  unsigned char readBuffer[RS0352_READ_BUFFER_SIZE];
  unsigned char msopPktBuffer[RS0352_PKT_LEN];
  std::vector<uint8_t> tmp_buffer_;
  bool is_meet_cur_pack_;
  int valid_cnt_;
  //RSInputSerial4MParam input_serial_param_;

  //size_t sock_offset_;
  //size_t sock_tail_;
  long header_cnt_;
  long push_cnt_;
  long drop_cnt_;
  float last_angle_;
  std::string the_port_name_;
  std::string the_port_name2_;
  int serial_baud_rate_;

  bool cont_search_;
  int valid_header_idx_;
  bool has_get_one_header_;

  bool open_succ_;

  RS0352HeaderType cur_data_type_;
  //uint8_t tail_tmp_buffer_[ONCE_BUFFER_SIZE];
  std::vector<uint8_t> tail_tmp_buffer_;
  int tail_buffer_size_;

  int has_unknown_data_type_;

  int fds_[2];

  int port_no_;

  int last_cnt_;

  std::vector<uint8_t> vec_buffer_;

  std::vector<int> recv_len_con_;
  bool mode_flag_4m_;
  Callback callback_;
  CallbackSeq callback_seq_;
  CallbackDifop callback_difop_imu_;
};


inline int InputSerial4M::libtty_open(const char *devname)
{
	int fd = open(devname, O_RDWR | O_NOCTTY | O_NDELAY);
	int flags = 0;

	if (fd < 0) {
		perror("open device failed");
		return -1;
	}

	flags = fcntl(fd, F_GETFL, 0);
	flags &= ~O_NONBLOCK;
	if (fcntl(fd, F_SETFL, flags) < 0) {
		printf("fcntl failed.\n");
		return -1;
	}

	if (isatty(fd) == 0) {
		printf("not tty device.\n");
		return -1;
	} else
		printf("tty device test ok.\n");

	return fd;
}

/**
 * libtty_setcustombaudrate - set baud rate of tty device
 * @fd: device handle
 * @speed: baud rate to set
 *
 * The function return 0 if success, or -1 if fail.
 */
inline int InputSerial4M::libtty_setcustombaudrate(int fd, int baudrate)
{
	struct termios2 tio;

	if (ioctl(fd, TCGETS2, &tio)) {
		perror("TCGETS2");
		return -1;
	}

	tio.c_cflag &= ~CBAUD;
	tio.c_cflag |= BOTHER;
	tio.c_ispeed = baudrate;
	tio.c_ospeed = baudrate;

  // 设置超时和最小字符数
  tio.c_cc[VMIN] = 0;   // 非阻塞读取
  tio.c_cc[VTIME] = 10; // 1秒超时（以十分之一秒为单位）


	if (ioctl(fd, TCSETS2, &tio)) {
		perror("TCSETS2");
		return -1;
	}

	if (ioctl(fd, TCGETS2, &tio)) {
		perror("TCGETS2");
		return -1;
	}

	return 0;
}


/**
 * libtty_setopt - config tty device
 * @fd: device handle
 * @speed: baud rate to set
 * @databits: data bits to set
 * @stopbits: stop bits to set
 * @parity: parity to set
 * @hardflow: hardflow to set
 *
 * The function return 0 if success, or -1 if fail.
 */
inline int InputSerial4M::libtty_setopt(int fd, int speed, int databits, int stopbits, char parity)
{
	struct termios newtio;
	struct termios oldtio;
	int i;

	bzero(&newtio, sizeof(newtio));
	bzero(&oldtio, sizeof(oldtio));

	if (tcgetattr(fd, &oldtio) != 0) {
		perror("tcgetattr");
		return -1;
	}
	newtio.c_cflag |= CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;

	/* set data bits */
	switch (databits) {
	case 5:
		newtio.c_cflag |= CS5;
		break;
	case 6:
		newtio.c_cflag |= CS6;
		break;
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 8:
		newtio.c_cflag |= CS8;
		break;
	default:
		fprintf(stderr, "unsupported data size\n");
		return -1;
	}

	/* set parity */
	switch (parity) {
	case 'n':
	case 'N':
		newtio.c_cflag &= ~PARENB; /* Clear parity enable */
		newtio.c_iflag &= ~INPCK;  /* Disable input parity check */
		break;
	case 'o':
	case 'O':
		newtio.c_cflag |= (PARODD | PARENB); /* Odd parity instead of even */
		newtio.c_iflag |= INPCK;	     /* Enable input parity check */
		break;
	case 'e':
	case 'E':
		newtio.c_cflag |= PARENB;  /* Enable parity */
		newtio.c_cflag &= ~PARODD; /* Even parity instead of odd */
		newtio.c_iflag |= INPCK;   /* Enable input parity check */
		break;
	case 'm':
	case 'M':
		newtio.c_cflag |= PARENB; /* Enable parity */
		newtio.c_cflag |= CMSPAR; /* Stick parity instead */
		newtio.c_cflag |= PARODD; /* Even parity instead of odd */
		newtio.c_iflag |= INPCK;  /* Enable input parity check */
		break;
	case 's':
	case 'S':
		newtio.c_cflag |= PARENB;  /* Enable parity */
		newtio.c_cflag |= CMSPAR;  /* Stick parity instead */
		newtio.c_cflag &= ~PARODD; /* Even parity instead of odd */
		newtio.c_iflag |= INPCK;   /* Enable input parity check */
		break;
	default:
		fprintf(stderr, "unsupported parity\n");
		return -1;
	}

	/* set stop bits */
	switch (stopbits) {
	case 1:
		newtio.c_cflag &= ~CSTOPB;
		break;
	case 2:
		newtio.c_cflag |= CSTOPB;
		break;
	default:
		perror("unsupported stop bits\n");
		return -1;
	}

	//if (hardflow)
		//newtio.c_cflag |= CRTSCTS;
	//else
	//	newtio.c_cflag &= ~CRTSCTS;
  
  // 设置为原始模式
  newtio.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
  newtio.c_oflag &= ~OPOST;
 
  newtio.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);

	newtio.c_cc[VTIME] = 10; /* Time-out value (tenths of a second) [!ICANON]. */
	newtio.c_cc[VMIN] = 0;	 /* Minimum number of bytes read at once [!ICANON]. */

	tcflush(fd, TCIOFLUSH);

	if (tcsetattr(fd, TCSANOW, &newtio) != 0) {
		perror("tcsetattr");
		return -1;
	}

	/* set tty speed */
	if (libtty_setcustombaudrate(fd, speed) != 0) {
		perror("setbaudrate");
		return -1;
	}

	return 0;
}


inline bool InputSerial4M::init()
{
  int speed = serial_baud_rate_;
  std::string cur_port_name;
  if (port_no_ == 1)
	  cur_port_name = the_port_name_;
  else if (port_no_ == 2)
	  cur_port_name = the_port_name2_;
  int fd = libtty_open(cur_port_name.c_str());
  if (fd < 0) {
  	printf("libtty_open: %s error.\n", cur_port_name.c_str());
  	return false;
  }
  int ret;
  //ret = libtty_setopt(fd, speed, 8, 1, 'n', hardflow);
  ret = libtty_setopt(fd, speed, 8, 1, 'n');
  if (ret != 0) {
	printf("libtty_setopt error.\n");
	close(fd);
    return false;
  }
  fds_[port_no_ - 1] = fd;
  RS_INFO << "Serial Port-" << port_no_ << " is Open!" << RS_REND;

  open_succ_ = true;
  callback_seq_((-1) * fd, port_no_);

  memset(readBuffer, 0, RS0352_READ_BUFFER_SIZE);

  is_meet_cur_pack_ = false;
  valid_cnt_ = 0;
  drop_cnt_ = 0;
  last_angle_ = -100.0;
  cont_search_ = false;
  has_get_one_header_ = false;

  tmp_buffer_.clear();
  tmp_buffer_.resize(0);

  push_cnt_ = 0;

  // state variables
  cur_data_type_ = RS0352HeaderType::INVALID;
  cont_search_ = false;
  valid_header_idx_ = -1;
  tail_buffer_size_ = 0;

  //memset(tail_tmp_buffer_, 0 ,sizeof(tail_tmp_buffer_));

  has_unknown_data_type_ = -1;

  return true;
}

inline InputSerial4M::~InputSerial4M()
{}

inline bool InputSerial4M::isValidHeader(uint8_t hex1, uint8_t hex2, uint8_t hex3, uint8_t hex4, uint8_t data_type)
{
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    && (data_type == 0x1))
  {
    return true;
  }
  return false;
}

inline bool InputSerial4M::closeInputPorts()
{
  if (open_succ_)
  {
    try  //int fd;
    {
      close(fds_[port_no_ - 1]);
      RS_DEBUG << "Serial Port " << port_no_ << " Closed." << RS_REND;
      return true;
    }
    catch(const std::exception& e)
    {
      std::cerr << e.what() << '\n';
    }
    RS_ERROR << "Serial Port Failed to close ... !!" << RS_REND;
  } 
  else
  {
    RS_WARNING << "No Serial Connection ..." << RS_REND;
  }

  return false;
}

inline std::string InputSerial4M::HeaderTypeToStr(RS0352HeaderType type)
{
  switch (type)
  {
  case RS0352HeaderType::INVALID:
    {return "INVALID";}
    break;
  case RS0352HeaderType::MSOP:
    {return "MSOP";}
    break;
  case RS0352HeaderType::IMU:
    {return "IMU";}
    break;
  case RS0352HeaderType::DIFOP:
    {return "DIFOP";}
    break;
  case RS0352HeaderType::Other:
    {return "Other";}
    break;
  default:
    {return "Unknown";}
    break;
  }
  return "UnKnown";
}

inline int InputSerial4M::recvPacket()
{
  int bytes_recv = 0;
  uint8_t recv_buffer[RS0352_RECV_BUFFER_SIZE];
#ifdef _WIN32
  serial_port_.read(recv_buffer, sizeof(recv_buffer), bytes_recv);
#else
  bytes_recv = read(fds_[port_no_ - 1], recv_buffer, sizeof(recv_buffer));
#endif
  memset(readBuffer, 0, sizeof(readBuffer));
  //RS_WARNING << " recv : " << bytes_recv << RS_REND;
#if 1
  if (bytes_recv > 0)
  {
    std::vector<PktInfo0352> infos;
    // Merge Data
    memcpy(readBuffer, tail_tmp_buffer_.data(), tail_tmp_buffer_.size());
    memcpy(readBuffer + tail_tmp_buffer_.size(), recv_buffer, bytes_recv);
    int mergedLen = bytes_recv + tail_tmp_buffer_.size();

    tail_tmp_buffer_.clear();
    tail_tmp_buffer_.resize(0);
    
    int idx = 0;
    while (idx < mergedLen)
    {
      if (idx > mergedLen - WINDOW_SIZE_0352_OFFSET){ 
        break; 
      }
      int hexIdx_1 = idx;
      int hexIdx_type = hexIdx_1 + 5;
      uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]); //-|
      uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]); //-|
      uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]); //-|
      uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]); //-|
      uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]); //-|
      if ((hex1 == RS0352_HEADER_ID1)
        && (hex2 == RS0352_HEADER_ID2)
        && (hex3 == RS0352_HEADER_ID3) 
        && (hex4 == RS0352_HEADER_ID4) 
        )
      {
        PktInfo0352 pi;
        if (data_type == 0x1) { pi.type = "MSOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x2) { pi.type = "IMU"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x3) { pi.type = "DIFOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
      }
      idx++;
    } // end of WHILE LOOP
#if 1
    if (infos.size() <= 1)
    {
      tail_tmp_buffer_.resize(mergedLen);
      memcpy(tail_tmp_buffer_.data(), readBuffer, mergedLen);
    }

    if (infos.size() >= 2)
    {
      bool notGood = false;
      //std::vector<int> rec1;
      bool loop_end = false;

      for (int k = 1; k < infos.size(); k++)
      {
        int offset = infos[k].dataIdx - infos[k - 1].dataIdx;
        int expectLen = 0;
        if (infos[k - 1].type == "MSOP") { expectLen = RS0352_PKT_LEN; }
        if (infos[k - 1].type == "IMU") { expectLen = RS0352_IMUPKT_LEN; }
        if (infos[k - 1].type == "DIFOP") { expectLen = RS0352_DIFOPPKT_LEN; }
        if (offset != expectLen)
        {
          notGood = true;
          std::cout << " @" << infos[k - 1].type << " : " <<  infos[k - 1].dataIdx
                    << " next:> " << infos[k].dataIdx << " offset: " << offset << std::endl;
          callback_seq_(SERIAL_READ_ERROR_CODE, port_no_);
        }
        else
        {
          if (expectLen == RS0352_PKT_LEN)
          {
            Packet0352 packet;
            packet.second.resize(expectLen);
            memcpy(packet.second.data(), readBuffer + infos[k - 1].dataIdx, expectLen);
            int pkt_cnt = (int)(packet.second[100]) * 256 + (int)(packet.second[101]);
            packet.first = pkt_cnt; // 从数据包中提取的序号
            //delete pkt_data;
            header_cnt_++;
            if (header_cnt_ == 1)
            {
              callback_seq_(pkt_cnt, port_no_);
            }
            callback_(packet);
            //if (header_cnt_ % 2000 == 0)
            //  RS_WARNING << " port: " << port_no_ << " " << header_cnt_ << " pkts get ... , now: " << pkt_cnt << RS_REND;
          }
          if (expectLen == RS0352_DIFOPPKT_LEN)
          {
            PacketDifopImu packet;
            packet.resize(expectLen);
            memcpy(packet.data(), readBuffer + infos[k - 1].dataIdx, expectLen);
            callback_difop_imu_(packet, expectLen);
          }
          if (expectLen == RS0352_IMUPKT_LEN)
          {
            PacketDifopImu packet;
            packet.resize(expectLen);
            memcpy(packet.data(), readBuffer + infos[k - 1].dataIdx, expectLen);
            callback_difop_imu_(packet, expectLen);
          }
        }
      }
      int copy_start_idx = infos[infos.size() - 1].dataIdx;
      tail_tmp_buffer_.resize(mergedLen - copy_start_idx);
      memcpy(tail_tmp_buffer_.data(), readBuffer + copy_start_idx, mergedLen - copy_start_idx);
    }
    return 1;
#endif
  }
#endif
  return 0;
}


}  // namespace lidar
}  // namespace robosense



