/*********************************************************************************************************************
Copyright (c) 2020 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once
#include <rs_driver/driver/decoder/decoder_mech.hpp>
#include <iomanip>

namespace robosense
{
namespace lidar
{

#pragma pack(push, 1)

typedef struct
{
  uint8_t id[4];
  uint8_t reserved_0[2];
  RSTimestampUTC timestamp;
  uint8_t lidar_type;
  uint8_t lidar_mode;
  uint16_t temp;
  RSTemperature topboard_temp;
} RSAIRYLITEETHHeader;

typedef struct
{
  uint16_t distance;
  uint8_t intensity;
} RSAIRYLITEETHChannel;

typedef struct
{
  uint16_t azimuth;
  RSAIRYLITEETHChannel channels[24];
} RSAIRYLITEETHMsopBlock;

typedef struct
{
  RSAIRYLITEETHHeader header;
  RSAIRYLITEETHMsopBlock blocks[16];
  uint8_t reserved_0[70];
  uint16_t pkt_count;
  uint16_t CRC16;
} RSAIRYLITEETHMsopPkt;

typedef struct
{
  int16_t  vdc_top_vbus;       //  2  
  int16_t  vdc_rx_vbd_p;       //  2
  int16_t  vdc_rx_vbd_n;       //  2
  int16_t  current_bot_vbus;   //  2
  int16_t  temp_top_rx_n;      //  2
  int16_t  temp_top_rx_p;      //  2
  int16_t  temp_top_fpga;      //  2
  int16_t  temp_bot_imu;       //  2
  uint16_t pwm_top;            //  2
  int16_t  volatge_bot_vbus;   //  2
  int16_t  current_board_a;    //  2
  int16_t  current_board_b;    //  2
  int16_t  current_board_c;    //  2
  int16_t  volatge_top_fpga;
} RS0352ETHDifopScrollData;

typedef struct
{
  uint8_t id[4];       // 4 bytes
  uint8_t reserved0[2];       // 4 bytes
  uint8_t pl_ver[4];                  // 5
  uint8_t app_ver[4];                 // 5
  uint8_t mot_ver[4];                 // 5
  uint8_t reserved1[31];                  // 1
  RSSN sn;
  uint8_t reserved2[17];                  // 1
  uint8_t install_mode;                  // 1
  uint32_t pitch;
  uint32_t yaw;
  uint32_t roll;
  uint8_t reserved3[6];
  uint8_t work_mode;            //  1
  uint8_t power_top_state;          // 1
  uint8_t return_mode;
  uint8_t reserved4[2];

  RSTimestampUTC timestamp;           //10
  uint8_t reserved5[205];
  RSFOV fov;
  uint8_t reserved6[25];             // 18
  uint16_t rpm_set;                   // 2
  uint16_t rpm;
  uint8_t reserved7[4];             // 18
  uint16_t vert_calib[24];           // 48
  uint8_t  vert_symb[3];             //  3
  uint16_t horiz_calib[24];          // 48 
  uint8_t  horiz_symb[3];            //  3

  uint8_t  reserved8[23];            // 14
  uint32_t qx;                        // 4    
  uint32_t qy;                        // 4  
  uint32_t qz;                        // 4  
  uint32_t qw;                        // 4  
  uint32_t x;                         // 4 
  uint32_t y;                         // 4 
  uint32_t z;                         // 4 
  uint8_t  reserved9[6];            // 14
  uint8_t eye_safe_state;            //  1
  RS0352ETHDifopScrollData scroll_data; 
  uint16_t pkt_cnt;                   // 2
  uint16_t crc;                       // 2
} RSAIRYLITEETHDifopPkt; //

typedef struct
{
  uint8_t id[4];
  uint8_t reserved;  // 1
  uint8_t data_type; //1
  RSTimestampUTC timestamp;
  uint32_t acceIx;
  uint32_t acceIy;
  uint32_t acceIz;
  uint32_t gyrox;
  uint32_t gyroy;
  uint32_t gyroz;
  int32_t temperature;
  uint8_t odr; // output data rate
  uint8_t acceIFsr; // accel full scale range 
                    // 0: +/- 2g
                    // 1: +/- 4g
                    // 2: +/- 8g
                    // 3: +/- 16g
    
    
  uint8_t gyroIFsr; // gyro full scale range
                    // 0: +/- 250 dps
                    // 1: +/- 500 dps
                    // 2: +/- 1000 dps
                    // 3: +/- 2000 dps
  uint16_t cnt;
  uint16_t tail;
} RSAIRYLITEETHImuPkt;//to
#pragma pack(pop)

enum RSAIRYLITEETHLidarModel
{
  RSAIRYLITEETH_CHANNEL_48 = 0,
  RSAIRYLITEETH_CHANNEL_96 = 1,
  RSAIRYLITEETH_CHANNEL_192 = 2,
  RSAIRYLITEETH_CHANNEL_24 = 3,
};
template <typename T_PointCloud>
class DecoderRSAIRYLITE_ETH : public DecoderMech<T_PointCloud>
{
public:

  virtual void decodeDifopPkt(const uint8_t* pkt, size_t size);
  virtual bool decodeMsopPkt(const uint8_t* pkt, size_t size);
  void decodeImuPkt(const uint8_t* pkt, size_t size) override;
  virtual ~DecoderRSAIRYLITE_ETH() = default;

  explicit DecoderRSAIRYLITE_ETH(const RSDecoderParam& param);
  virtual bool isNewFrame(const uint8_t* packet) override;
#ifndef UNIT_TEST
protected:
#endif
  DecoderRSAIRYLITE_ETH(const RSDecoderMechConstParam& const_param, const RSDecoderParam& param);
  static RSDecoderMechConstParam& getConstParam();
  static RSEchoMode getEchoMode(uint8_t mode);
  RSAIRYLITEETHLidarModel getLidarModel(uint8_t mode);
  template <typename T_BlockIterator>
  bool internDecodeMsopPkt(const uint8_t* pkt, size_t size);
  void decodeDifopAngles(const uint8_t* packet, size_t size);

  RSAIRYLITEETHLidarModel lidarModel_{RSAIRYLITEETH_CHANNEL_24};
  uint16_t u16ChannelNum_{24};
  bool bInit_{false};
  bool loaded_install_info_{false};
  uint16_t install_mode_{0xFF};

  double user_roll_{0.0};
  double user_pitch_{0.0};
  double user_yaw_{0.0};
  double user_x_{0.0};
  double user_y_{0.0};
  double user_z_{0.0};
  
  int ang_ret_{0};

};

template <typename T_PointCloud>
inline RSDecoderMechConstParam& DecoderRSAIRYLITE_ETH<T_PointCloud>::getConstParam()
{
  static RSDecoderMechConstParam param = 
  {
    1280 // msop len
      , 540 // difop len
      , 4 // msop id len
      , 4 // difop id len
      , {0x5A, 0xFF, 0x55, 0xAA} // msop id
    , {0x5A, 0xFF, 0x55, 0xAA} // difop id
    , {0xFF, 0xEE} // block id
    , 24 // laser number 
    , 16 // blocks per packet
      , 24 // channels per block
      , 0.1f //TODO: distance min
      , 100.0f //TODO: distance max
      , 0.005f //TODO: distance resolution
      , 0.0625f //TODO: temperature resolution
      // lens center
      , 0.0088f // RX
      , 0.0066f // RY
      , 0.0511f //TODO: RZ
  };

  INIT_ONLY_ONCE();

  float blk_ts = 166.667f;

  float firing_tss_AIRYLITEETH_m[] = 
  {
    0.000f,  0.000f,  0.000f,  0.000f, 0.000f, 0.000f,
    21.460f, 21.460f, 21.460f, 21.460f, 21.460f, 21.460f,
    64.380f, 64.380f, 64.380f, 64.380f, 64.380f, 64.380f,
    107.300f, 107.300f, 107.300f, 107.300f, 107.300f, 107.300f,
  };

  param.BLOCK_DURATION = blk_ts / 1000000;
  for (uint16_t i = 0; i < sizeof(firing_tss_AIRYLITEETH_m)/sizeof(firing_tss_AIRYLITEETH_m[0]); i++)
  {
    param.CHAN_TSS[i] = (double)firing_tss_AIRYLITEETH_m[i] / 1000000;
    param.CHAN_AZIS[i] = firing_tss_AIRYLITEETH_m[i] / blk_ts;
  }

  return param;
}

template <typename T_PointCloud>
inline RSEchoMode DecoderRSAIRYLITE_ETH<T_PointCloud>::getEchoMode(uint8_t mode)
{
  switch (mode)
  {
    case 0x03: // dual return
      return RSEchoMode::ECHO_DUAL;
    default:
      return RSEchoMode::ECHO_SINGLE;
  }
}

template <typename T_PointCloud>
inline RSAIRYLITEETHLidarModel DecoderRSAIRYLITE_ETH<T_PointCloud>::getLidarModel(uint8_t mode)
{
  switch (mode)
  {
    case 0x01: 
      this->u16ChannelNum_ = 48;
      return RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_48;
    case 0x02:
      this->u16ChannelNum_ = 96;
      return RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_96;
    case 0x03:
      this->u16ChannelNum_ = 192;
      return RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_192;
    case 0x04:
      this->u16ChannelNum_ = 24;
      return RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_24;
    default:
      this->u16ChannelNum_ = 24;
      return RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_24;
  }
}

template <typename T_PointCloud>
inline DecoderRSAIRYLITE_ETH<T_PointCloud>::DecoderRSAIRYLITE_ETH(const RSDecoderParam& param): DecoderRSAIRYLITE_ETH(getConstParam(), param) // C++11 委托构造
{
}

template <typename T_PointCloud>
inline DecoderRSAIRYLITE_ETH<T_PointCloud>::DecoderRSAIRYLITE_ETH(const RSDecoderMechConstParam& const_param, const RSDecoderParam& param)
          : DecoderMech<T_PointCloud>(const_param, param)
{
  this->IMU_LEN = 51;   //imu packet len
  this->IMU_ID_LEN = 4;  //imu id len 
  this->IMU_ID[0] = 0x5A;
  this->IMU_ID[1] = 0xFF;
  this->IMU_ID[2] = 0x55;
  this->IMU_ID[3] = 0xAA;

  user_roll_ = param.transform_param.roll;
  user_pitch_ = param.transform_param.pitch;
  user_yaw_ = param.transform_param.yaw;
  user_x_ = param.transform_param.x;
  user_y_ = param.transform_param.y;
  user_z_ = param.transform_param.z;
}

template <typename T_PointCloud>
inline void DecoderRSAIRYLITE_ETH<T_PointCloud>::decodeImuPkt(const uint8_t* packet, size_t size)
{

  const RSAIRYLITEETHImuPkt& pkt = *(const RSAIRYLITEETHImuPkt*)(packet);
  if (this->imuDataPtr_ && this->cb_imu_data_ && !this->imuDataPtr_->state)
  {
    if (this->param_.use_lidar_clock)
    {
      this->imuDataPtr_->timestamp = parseTimeUTCWithUs(&pkt.timestamp) * 1e-6;
      //this->imuDataPtr_->timestamp  = parseTime0352(packet) * 1e-6;
    }
    else
    {
      this->imuDataPtr_->timestamp = getTimeHost() * 1e-6;
    }
    uint8_t acclFsr = 1 << (pkt.acceIFsr + 1);
    constexpr static float FSR_BASE = 32768.0;
    float acceUnit = acclFsr / FSR_BASE;
    
    float lx = convertUint32ToFloat(ntohl(pkt.acceIx));
    float ly = convertUint32ToFloat(ntohl(pkt.acceIy));
    float lz = convertUint32ToFloat(ntohl(pkt.acceIz));

    this->imuDataPtr_->linear_acceleration_x = lx;
    this->imuDataPtr_->linear_acceleration_y = ly;
    this->imuDataPtr_->linear_acceleration_z = lz;

    uint16_t gyroFsr = 250 * (1 << pkt.gyroIFsr);
    float gyroUnit = gyroFsr / FSR_BASE * M_PI / 180;

    float avx = convertUint32ToFloat(ntohl(pkt.gyrox));
    float avy = convertUint32ToFloat(ntohl(pkt.gyroy));
    float avz = convertUint32ToFloat(ntohl(pkt.gyroz));

    this->imuDataPtr_->angular_velocity_x = avx;
    this->imuDataPtr_->angular_velocity_y = avy;
    this->imuDataPtr_->angular_velocity_z = avz;

    this->imuDataPtr_->state = true;

    this->cb_imu_data_();
  }
}

template <typename T_PointCloud>
inline void DecoderRSAIRYLITE_ETH<T_PointCloud>::decodeDifopAngles(const uint8_t* packet, size_t size)
{
  const static int32_t RS_ONE_ROUND = 36000;
  const RSAIRYLITEETHDifopPkt& pkt = *(const RSAIRYLITEETHDifopPkt*)(packet);
  this->rps_ = (uint16_t)static_cast<int>(ntohs(pkt.rpm_set) / 600);
  // blocks per frame
  this->blks_per_frame_ = (uint16_t)(1 / (this->rps_ * this->mech_const_param_.BLOCK_DURATION));

  // block diff of azimuth
  this->block_az_diff_ = 
    (uint16_t)static_cast<int>((RS_ONE_ROUND * this->rps_ * this->mech_const_param_.BLOCK_DURATION));


  // load angles
  //if (!this->param_.config_from_file && !this->angles_ready_)
  //{
  //  int ret = this->chan_angles_.loadFromDifopAIRYLITE(packet);
  //  
  //  this->angles_ready_ = (ret == 0);
  //}

  {
    static const int ANGLE_OFFSET = 348;
    int ret = this->chan_angles_.loadFromDifop0352(packet+ANGLE_OFFSET);
    if (ret > 0)
    {
      this->angles_ready_ = true;
      if (ret != ang_ret_)
      {
        ang_ret_ = ret;
        RS_DEBUG << " > Refresh Difop. " << ret << RS_REND;
      }
    }
  }
}

template <typename T_PointCloud>
inline void DecoderRSAIRYLITE_ETH<T_PointCloud>::decodeDifopPkt(const uint8_t* packet, size_t size)
{
  const RSAIRYLITEETHDifopPkt& pkt = *(const RSAIRYLITEETHDifopPkt*)(packet);
  const float scroll_data_res = 0.01;
  // this->template decodeDifopCommon<RSAIRYLITEETHDifopPkt>(pkt);
  this->is_get_temperature_ = true;
  this->temperature_ = ntohs(pkt.scroll_data.temp_top_rx_n) * this->const_param_.TEMPERATURE_RES;
  //std::cout << " >>> this->temperature_: " << this->temperature_ << std::endl;

  this->device_status_.vdc_top_vbus      =  RS_SWAP_INT16(pkt.scroll_data.vdc_top_vbus)     * scroll_data_res;
  this->device_status_.vdc_rx_vbd_p      =  RS_SWAP_INT16(pkt.scroll_data.vdc_rx_vbd_p)     * scroll_data_res;
  this->device_status_.vdc_rx_vbd_n      =  RS_SWAP_INT16(pkt.scroll_data.vdc_rx_vbd_n)     * scroll_data_res;
  this->device_status_.current_bot_vbus  =  RS_SWAP_INT16(pkt.scroll_data.current_bot_vbus) * scroll_data_res;
  this->device_status_.temp_top_rx_n     =  RS_SWAP_INT16(pkt.scroll_data.temp_top_rx_n)    * scroll_data_res;
  this->device_status_.temp_top_rx_p     =  RS_SWAP_INT16(pkt.scroll_data.temp_top_rx_p)    * scroll_data_res;
  this->device_status_.temp_bot_imu      =  RS_SWAP_INT16(pkt.scroll_data.temp_bot_imu)     * scroll_data_res;
  this->device_status_.pwm_top           =  RS_SWAP_INT16(pkt.scroll_data.pwm_top);
  this->device_status_.volatge_bot_vbus  =  RS_SWAP_INT16(pkt.scroll_data.volatge_bot_vbus) * scroll_data_res;
  this->device_status_.current_board_a   =  RS_SWAP_INT16(pkt.scroll_data.current_board_a)  * 0.1;
  this->device_status_.current_board_b   =  RS_SWAP_INT16(pkt.scroll_data.current_board_b)  * 0.1;
  this->device_status_.current_board_c   =  RS_SWAP_INT16(pkt.scroll_data.current_board_c)  * 0.1;

  this->device_status_.power_top_state = static_cast<bool>(pkt.power_top_state);
  this->device_status_.eye_safe_state = static_cast<bool>(pkt.eye_safe_state & 0x1);
  this->device_status_.eye_safe_en_state = static_cast<bool>(pkt.eye_safe_state >> 4 & 0x1); 

  this->device_status_.state = true;


  // this->device_status_.pps_lock_flag  = (int)(pkt.gps_state & 0x01);
  // this->device_status_.gprmc_flag     = (int)((pkt.gps_state >> 3) & (0x01));
  // this->device_status_.pps_input_flag = (int)((pkt.gps_state >> 4) & (0x01));

  this->device_info_.qx = convertUint32ToFloat(ntohl(pkt.qx));
  this->device_info_.qy = convertUint32ToFloat(ntohl(pkt.qy));
  this->device_info_.qz = convertUint32ToFloat(ntohl(pkt.qz));
  this->device_info_.qw = convertUint32ToFloat(ntohl(pkt.qw));

  this->device_info_.x = convertUint32ToFloat(ntohl(pkt.x));
  this->device_info_.y = convertUint32ToFloat(ntohl(pkt.y));
  this->device_info_.z = convertUint32ToFloat(ntohl(pkt.z));
  memcpy(this->device_info_.sn, pkt.sn.num, 6);
  memcpy(this->device_info_.top_ver, pkt.pl_ver, 4);
  memcpy(this->device_info_.bottom_ver, pkt.app_ver, 4);
  memcpy(this->device_info_.mot_ver, pkt.mot_ver, 4);
  this->device_info_.state = true;

#ifdef ENABLE_TRANSFORM
  double difop_roll = DEGREE_TO_RADIAN(convertUint32ToFloat(ntohl(pkt.roll)));
  double difop_pitch = DEGREE_TO_RADIAN(convertUint32ToFloat(ntohl(pkt.pitch)));
  double difop_yaw = DEGREE_TO_RADIAN(convertUint32ToFloat(ntohl(pkt.yaw)));
 
  Eigen::AngleAxisd current_rotation_x(difop_roll + user_roll_, Eigen::Vector3d::UnitX());
  Eigen::AngleAxisd current_rotation_y(difop_pitch + user_pitch_, Eigen::Vector3d::UnitY());
  Eigen::AngleAxisd current_rotation_z(difop_yaw + user_yaw_, Eigen::Vector3d::UnitZ());
  Eigen::Translation3d current_translation(user_x_, user_y_, user_z_);
  this->trans_ = (current_translation * current_rotation_z * current_rotation_y * current_rotation_x).matrix();
#endif
  if ((uint16_t)(pkt.install_mode) != 0xFF)
  {
    this->install_mode_ = (uint16_t)(pkt.install_mode);
    this->loaded_install_info_ = true;
  }
  decodeDifopAngles(packet,size);
}

template <typename T_PointCloud>
inline bool DecoderRSAIRYLITE_ETH<T_PointCloud>::decodeMsopPkt(const uint8_t* pkt, size_t size)
{
  const RSAIRYLITEETHMsopPkt& msopPkt = *(const RSAIRYLITEETHMsopPkt*)(pkt);
  if(!bInit_)
  {
    this->echo_mode_ = getEchoMode (0);// default single return
    this->split_blks_per_frame_ = (this->echo_mode_ == RSEchoMode::ECHO_DUAL) ? 
      (this->blks_per_frame_ << 1) : this->blks_per_frame_;
    
    lidarModel_ = getLidarModel(msopPkt.header.lidar_mode);
    
    float blk_ts = 111.080f;
    this->mech_const_param_.BLOCK_DURATION = blk_ts / 1000000;

    float firing_tss_48L[] = 
    {
      0.00f,  0.00f,  0.00f,  0.00f, 7.616f, 7.616f, 7.616f, 7.616f, 
      16.184f, 16.184f, 16.184f, 16.184f, 24.752f, 24.752f, 24.752f, 24.752f, 
      33.320f, 33.320f, 33.320f, 33.320f, 42.840f, 42.840f, 42.840f, 42.840f,
      52.360f, 52.360f, 52.360f, 52.360f, 61.880f, 61.880f, 61.880f, 61.880f,
      71.400f, 71.400f, 71.400f, 71.400f, 79.968f, 79.968f, 79.968f, 79.968f,
      88.536f, 88.536f, 88.536f, 88.536f, 97.104f, 97.104f, 97.104f, 97.104f,
    };

    float firing_tss_side[] = 
    {
      0.00f,   0.00f,   0.00f,   0.00f,   0.00f,   0.00f,   0.00f,   0.00f,   
      11.424f, 11.424f, 11.424f, 11.424f, 11.424f, 11.424f, 11.424f, 11.424f, 
      22.848f, 22.848f, 22.848f, 22.848f, 22.848f, 22.848f, 22.848f, 22.848f, 
      34.272f, 34.272f, 34.272f, 34.272f, 34.272f, 34.272f, 34.272f, 34.272f, 
      45.696f, 45.696f, 45.696f, 45.696f, 45.696f, 45.696f, 45.696f, 45.696f, 
      54.264f, 54.264f, 54.264f, 54.264f, 54.264f, 54.264f, 54.264f, 54.264f, 
      62.832f, 62.832f, 62.832f, 62.832f, 62.832f, 62.832f, 62.832f, 62.832f, 
      71.400f, 71.400f, 71.400f, 71.400f, 71.400f, 71.400f, 71.400f, 71.400f, 
      79.016f, 79.016f, 79.016f, 79.016f, 79.016f, 79.016f, 79.016f, 79.016f, 
      85.680f, 85.680f, 85.680f, 85.680f, 85.680f, 85.680f, 85.680f, 85.680f, 
      92.344f, 92.344f, 92.344f, 92.344f, 92.344f, 92.344f, 92.344f, 92.344f, 
      99.008f, 99.008f, 99.008f, 99.008f, 99.008f, 99.008f, 99.008f, 99.008f, 
    };

    float firing_tss_normal[] = 
    {
      0.00f,  0.00f,  0.00f,  0.00f, 0.00f, 0.00f, 0.00f, 0.00f, 
      5.712f, 5.712f, 5.712f, 5.712f, 5.712f, 5.712f, 5.712f, 5.712f, 
      12.376f, 12.376f, 12.376f, 12.376f, 12.376f, 12.376f, 12.376f, 12.376f,
      19.040f, 19.040f, 19.040f, 19.040f, 19.040f, 19.040f, 19.040f, 19.040f,
      25.704f, 25.704f, 25.704f, 25.704f, 25.704f, 25.704f, 25.704f, 25.704f,
      33.320f, 33.320f, 33.320f, 33.320f, 33.320f, 33.320f, 33.320f, 33.320f,
      41.888f, 41.888f, 41.888f, 41.888f, 41.888f, 41.888f, 41.888f, 41.888f,
      50.456f, 50.456f, 50.456f, 50.456f, 50.456f, 50.456f, 50.456f, 50.456f,
      59.024f, 59.024f, 59.024f, 59.024f, 59.024f, 59.024f, 59.024f, 59.024f,
      70.448f, 70.448f, 70.448f, 70.448f, 70.448f, 70.448f, 70.448f, 70.448f,
      81.872f, 81.872f, 81.872f, 81.872f, 81.872f, 81.872f, 81.872f, 81.872f,
      93.296f, 93.296f, 93.296f, 93.296f, 93.296f, 93.296f, 93.296f, 93.296f
    };

    if(lidarModel_ ==  RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_48)
    {
      for (uint16_t i = 0; i < sizeof(firing_tss_48L)/sizeof(firing_tss_48L[0]); i++)
      {
        this->mech_const_param_.CHAN_TSS[i] = (double)firing_tss_48L[i] / 1000000;
        this->mech_const_param_.CHAN_AZIS[i] = firing_tss_48L[i] / blk_ts;
      }
      bInit_ = true;
    }

    if(lidarModel_ ==  RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_96)
    {
      // side
      if ((loaded_install_info_) && (this->install_mode_ == 0x1))
      {
        for (uint16_t i = 0; i < sizeof(firing_tss_side)/sizeof(firing_tss_side[0]); i++)
        {
          this->mech_const_param_.CHAN_TSS[i] = (double)firing_tss_side[i] / 1000000;
          this->mech_const_param_.CHAN_AZIS[i] = firing_tss_side[i] / blk_ts;
        }
        bInit_ = true;
      }
      // normal
      else if((loaded_install_info_) && (this->install_mode_ == 0x0))
      {
        for (uint16_t i = 0; i < sizeof(firing_tss_normal)/sizeof(firing_tss_normal[0]); i++)
        {
          this->mech_const_param_.CHAN_TSS[i] = (double)firing_tss_normal[i] / 1000000;
          this->mech_const_param_.CHAN_AZIS[i] = firing_tss_normal[i] / blk_ts;
        }
        bInit_ = true;
      }
      // AIRYLITEETH M
      else if((loaded_install_info_) && (this->install_mode_ == 0x2))
      {
        bInit_ = true;
      }
    }
  }
  
  if(lidarModel_ ==  RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_48)
  {
      if (this->echo_mode_ == RSEchoMode::ECHO_SINGLE)
    {
      return internDecodeMsopPkt<SingleReturnBlockIterator<RSAIRYLITEETHMsopPkt>>(pkt, size);
    }
    else
    {
      return internDecodeMsopPkt<DualReturnBlockIterator<RSAIRYLITEETHMsopPkt>>(pkt, size);
    }
  }else if(lidarModel_ ==  RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_96)
  {
     if (this->echo_mode_ == RSEchoMode::ECHO_SINGLE)
    {
      return internDecodeMsopPkt<TwoInOneBlockIterator<RSAIRYLITEETHMsopPkt>>(pkt, size);
    }
    else
    {
      return internDecodeMsopPkt<FourInOneBlockIterator<RSAIRYLITEETHMsopPkt>>(pkt, size);
    }
  }
  else if (lidarModel_ ==  RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_24)
  {
    if (this->echo_mode_ == RSEchoMode::ECHO_SINGLE)
    {
      return internDecodeMsopPkt<SingleReturnBlockIterator<RSAIRYLITEETHMsopPkt>>(pkt, size);
    }
    else
    {
      return internDecodeMsopPkt<DualReturnBlockIterator<RSAIRYLITEETHMsopPkt>>(pkt, size);
    }
  }
  
  else{
    RS_ERROR << "Unsupported lidar model:" << lidarModel_ << RS_REND;
    return false;
  }

}

template <typename T_PointCloud>
template <typename T_BlockIterator>
inline bool DecoderRSAIRYLITE_ETH<T_PointCloud>::internDecodeMsopPkt(const uint8_t* packet, size_t size)
{

  const RSAIRYLITEETHMsopPkt& pkt = *(const RSAIRYLITEETHMsopPkt*)(packet);
  bool ret = false;

  // int Temp = pkt.header.temp;
  // if ((Temp >> 15) & 0x1 == 1)
  //   Temp  = (-1) * (0xFFFF - Temp + 0x1);
  // this->temperature_ = static_cast<float>(((double)Temp / 8) * this->const_param_.TEMPERATURE_RES);

  // this->is_get_temperature_ = true;

  double pkt_ts = 0;
  if (this->param_.use_lidar_clock)
  {
    pkt_ts = parseTimeUTCWithUs ((RSTimestampUTC*)&pkt.header.timestamp) * 1e-6;
  }
  else
  {
    uint64_t ts = getTimeHost();

    // roll back to first block to approach lidar ts as near as possible.
    pkt_ts = ts * 1e-6 - this->getPacketDuration();

    if (this->write_pkt_ts_)
    {
      createTimeUTCWithUs (ts, (RSTimestampUTC*)&pkt.header.timestamp);
    }
  }
  T_BlockIterator iter(pkt, this->const_param_.BLOCKS_PER_PKT, this->mech_const_param_.BLOCK_DURATION, 
      this->block_az_diff_, this->fov_blind_ts_diff_);
  for (uint16_t blk = 0; blk < this->const_param_.BLOCKS_PER_PKT; blk++)
  {
    const RSAIRYLITEETHMsopBlock& block = pkt.blocks[blk];

    // if (memcmp(this->const_param_.BLOCK_ID, block.id, 2) != 0)
    // {
    //   this->cb_excep_(Error(ERRCODE_WRONGMSOPBLKID));
    //   break;
    // } 
    
    int32_t block_az_diff;
    double block_ts_off;
    iter.get(blk, block_az_diff, block_ts_off);

    double block_ts = pkt_ts + block_ts_off;
    int32_t block_az = ntohs(block.azimuth);

    if (this->split_strategy_->newBlock(block_az))
    {
      this->cb_split_frame_(this->u16ChannelNum_, this->cloudTs());
      this->first_point_ts_ = block_ts;
      ret = true;
    }

    for (uint16_t chan = 0; chan < this->const_param_.CHANNELS_PER_BLOCK; chan++)
    {
      const RSAIRYLITEETHChannel& channel = block.channels[chan]; 
      uint16_t chan_id = chan;
      if(lidarModel_ == RSAIRYLITEETHLidarModel::RSAIRYLITEETH_CHANNEL_96 && (blk % 2) == 1)
      { 
          chan_id = chan +  48; 
      }
      double chan_ts = block_ts + this->mech_const_param_.CHAN_TSS[chan_id];
      int32_t angle_horiz = block_az + (int32_t)((float)block_az_diff * this->mech_const_param_.CHAN_AZIS[chan_id]);
   
      int32_t angle_vert = this->chan_angles_.vertAdjust(chan_id);
      int32_t angle_horiz_final = this->chan_angles_.horizAdjust(chan_id, angle_horiz);
      uint16_t u16RawDistance = ntohs(channel.distance);
      uint16_t u16Distance = u16RawDistance & 0x3FFF;
      uint8_t feature = (u16RawDistance >> 14) & 0x03;
      float distance = u16Distance * this->const_param_.DISTANCE_RES;
      
      if (this->distance_section_.in(distance) && this->scan_section_.in(angle_horiz_final))
      {
        float x = distance * COS(angle_vert) * COS(angle_horiz_final) + this->lidar_lens_center_Rxy_* COS(angle_horiz);
        float y = -distance * COS(angle_vert) * SIN(angle_horiz_final) - this->lidar_lens_center_Rxy_* SIN(angle_horiz);
        float z = distance * SIN(angle_vert) + this->mech_const_param_.RZ;
        this->transformPoint(x, y, z);
        typename T_PointCloud::PointT point;
        setX(point, x);
        setY(point, y);
        setZ(point, z);
        setIntensity(point, channel.intensity);
        setTimestamp(point, chan_ts);
        setRing(point, this->chan_angles_.toUserChan(chan_id));
        setFeature(point, feature);
        this->point_cloud_->points.emplace_back(point);
      }
      else if (!this->param_.dense_points)
      {
        typename T_PointCloud::PointT point;
        setX(point, NAN);
        setY(point, NAN);
        setZ(point, NAN);
        setIntensity(point, 0);
        setTimestamp(point, chan_ts);
        setFeature(point, feature);
        setRing(point, this->chan_angles_.toUserChan(chan_id));
        this->point_cloud_->points.emplace_back(point);
      }

      this->prev_point_ts_ = chan_ts;
    }
  }

  this->prev_pkt_ts_ = pkt_ts;
  return ret;
}

template <typename T_PointCloud>
inline bool DecoderRSAIRYLITE_ETH<T_PointCloud>::isNewFrame(const uint8_t* packet)
{
  const RSAIRYLITEETHMsopPkt& pkt = *(const RSAIRYLITEETHMsopPkt*)(packet);

  // int data_type_ = (int)(pkt.header.data_type[0]);
  // if(data_type_ > 0)
  // {
  //   return false;
  // }

  for (uint16_t blk = 0; blk < this->const_param_.BLOCKS_PER_PKT; blk++)
  {
    const RSAIRYLITEETHMsopBlock& block = pkt.blocks[blk];

    // if (memcmp(this->const_param_.BLOCK_ID, block.id, 1) != 0)
    // {
    //   break;
    // }

    int32_t block_az = ntohs(block.azimuth);
    if (this->pre_split_strategy_->newBlock(block_az))
    {
      return true;
    }
  }

  return false;
}

}  // namespace lidar
}  // namespace robosense
