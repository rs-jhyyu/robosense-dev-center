# KM-AK1驱动 Changelog

### Ver.25091703

1. 进一步优化点云缺口的处理
2. 通过RS0352_4M_ENABLE_PORT1和RS0352_4M_ENABLE_PORT2两个宏来控制是否开启该路串口解析，0为关，1为开

### Ver.25091103

1. 架构合并到rs_driver主线框架
2. LidarType变更为RSAIRYLITE (配置方式参考demo_online.cpp)
3. CMake命令改为:
```bash
cmake .. -DCOMPILE_DEMOS=ON -DDISABLE_PCAP_PARSE=ON
```

### Ver.25091001

1. 针对每10帧一次的点云缺口做优化

### Ver.25090902

1. 优化分帧时的时间戳解析
2. 增加人眼安全和顶板上电的DIFOP解析功能

### Ver.25090802

1. 优化初始接收部分的逻辑。
2. 增加IMU解析的相关能力(可不启用)

### Ver.25090205

1. 初始化传参格式恢复成原有框架：

```c++
  RSDriverParam param;  ///< Create a parameter object
  param.lidar_type = LidarType::RSAIRYLITE;
  param.input_type = InputType::RS485_LIDAR;
  param.input_param.port1 = "/dev/ttyCH343USB0";
  param.input_param.port2 = "/dev/ttyCH343USB3";
  param.input_param.baud_rate = 4000000;
  param.decoder_param.config_from_file = false;
  param.decoder_param.angle_path = "/home/sti/SDK_AIRYLITE_SERIAL_0805/ANGLES_0352_0528/angle.csv";
```

2. 误码太多时，报错并自动退出。("Serial Error: Too much error data. ")

### Ver.25083005

1. 优化了CPU占用
2. 增加了分帧时的保护机制
3. 优化了刚启动时的包处理逻辑
4. 使用PS版本25082611配套做验证

### Ver.25082701

1. 打开角度校正开关
2. 新增外挂角度的配置方法：

```c++
  param.config_from_file = true;
  param.angle_file_path = "/home/sti/SDK_AIRYLITE_SERIAL_0805/ANGLES_0352_0528/angle.csv";
  processor.setParam(port1, port2, 4000000, param);
```

### Ver.25082601

1. 修复ubuntu下的分帧异常
2. 增加了Difop温度电压等内部状态解析功能