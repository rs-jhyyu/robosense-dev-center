/*********************************************************************************************************************
Copyright (c) 2020 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once
#include <rs_driver/driver/decoder/decoder_RSAIRY.hpp>
#include <iomanip>

namespace robosense
{
namespace lidar
{

template <typename T_PointCloud>
class DecoderRSSafetyAIRY : public DecoderRSAIRY<T_PointCloud>
{
public:
  explicit DecoderRSSafetyAIRY(const RSDecoderParam& param);
#ifndef UNIT_TEST
protected:
  static RSDecoderMechConstParam& getConstParam();  
#endif
};

template <typename T_PointCloud>
inline RSDecoderMechConstParam& DecoderRSSafetyAIRY<T_PointCloud>::getConstParam()
{
  static RSDecoderMechConstParam param = 
  {
    1248 // msop len
      , 1248 // difop len
      , 4 // msop id len
      , 8 // difop id len
      , {0x55, 0xAA, 0x05, 0x5A} // msop id
    , {0xA5, 0xFF, 0x00, 0x5A, 0x11, 0x11, 0x55, 0x55} // difop id
    , {0xFF, 0xEE} // block id
    , 96 // laser number 
    , 8 // blocks per packet
      , 48 // channels per block
      , 0.1f // distance min
      , 60.0f // distance max
      , 0.005f // distance resolution
      , 0.0625f // temperature resolution
      // lens center
      , 0.00979f // RX
      , 0.00068f // RY
      , 0.04955f // RZ
  };

  INIT_ONLY_ONCE();

  float blk_ts = 111.080f;

  float firing_tss_airy_m[] = 
  {
    0.00f,  0.00f,  0.00f,  0.00f, 0.00f, 0.00f, 0.00f, 0.00f, 
    7.616f, 7.616f, 7.616f, 7.616f, 7.616f,7.616f,7.616f,7.616f,
    16.184f, 16.184f, 16.184f, 16.184f, 16.184f, 16.184f, 16.184f, 16.184f,
    24.752f, 24.752f, 24.752f, 24.752f, 24.752f, 24.752f, 24.752f, 24.752f,
    33.320f, 33.320f, 33.320f, 33.320f, 33.320f, 33.320f, 33.320f, 33.320f,
    42.840f, 42.840f, 42.840f, 42.840f, 42.840f, 42.840f, 42.840f, 42.840f,
    52.360f, 52.360f, 52.360f, 52.360f, 52.360f, 52.360f, 52.360f, 52.360f,
    61.880f, 61.880f, 61.880f, 61.880f, 61.880f, 61.880f, 61.880f, 61.880f,
    71.400f, 71.400f, 71.400f, 71.400f, 71.400f, 71.400f, 71.400f, 71.400f,
    79.968f, 79.968f, 79.968f, 79.968f, 79.968f, 79.968f, 79.968f, 79.968f,
    88.536f, 88.536f, 88.536f, 88.536f, 88.536f, 88.536f, 88.536f, 88.536f,
    97.104f, 97.104f, 97.104f, 97.104f, 97.104f, 97.104f, 97.104f, 97.104f,
  };

  param.BLOCK_DURATION = blk_ts / 1000000;
  for (uint16_t i = 0; i < sizeof(firing_tss_airy_m)/sizeof(firing_tss_airy_m[0]); i++)
  {
    param.CHAN_TSS[i] = (double)firing_tss_airy_m[i] / 1000000;
    param.CHAN_AZIS[i] = firing_tss_airy_m[i] / blk_ts;
  }

  return param;
}

template <typename T_PointCloud>
inline DecoderRSSafetyAIRY<T_PointCloud>::DecoderRSSafetyAIRY(const RSDecoderParam& param)
  : DecoderRSAIRY<T_PointCloud>(DecoderRSSafetyAIRY::getConstParam(), param)
{

  this->IMU_LEN = 51;   //imu packet len
  this->IMU_ID_LEN = 4;  //imu id len 
  this->IMU_ID[0] = 0xAA;
  this->IMU_ID[1] = 0x55;
  this->IMU_ID[2] = 0x5A;
  this->IMU_ID[3] = 0x05;

  this->user_roll_ = param.transform_param.roll;
  this->user_pitch_ = param.transform_param.pitch;
  this->user_yaw_ = param.transform_param.yaw;
  this->user_x_ = param.transform_param.x;
  this->user_y_ = param.transform_param.y;
  this->user_z_ = param.transform_param.z;
}

}  // namespace lidar
}  // namespace robosense
