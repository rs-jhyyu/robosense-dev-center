/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once
#include <iostream>

#define ERRLOG(msg)                                         \
    do                                                      \
    {                                                       \
        printf("%s:%s:%d\n", __FILE__, __func__, __LINE__); \
        perror(msg);                                        \
        exit(-1);                                           \
    } while (0);


#ifdef _WIN32

#include <rs_driver/driver/input/win/input_serial.hpp>

#else  //__linux__

#include <rs_driver/driver/input/unix/input_serial.hpp>

#endif

using namespace robosense::lidar;

namespace robosense
{
namespace lidar
{

inline void InputSerial::ejectForcely(int validCnt)
{
  int pkt_len = 0;
  if (cur_data_type_ == RS0352HeaderType::MSOP)
    pkt_len = RS0352_PKT_LEN;
  if (cur_data_type_ == RS0352HeaderType::DIFOP)
    pkt_len = RS0352_DIFOPPKT_LEN;
  if (cur_data_type_ == RS0352HeaderType::IMU)
    pkt_len = RS0352_IMUPKT_LEN;
  if (validCnt < pkt_len)
  {
    std::cout << "drop: pkt len: " << pkt_len << " but get: " << validCnt << std::endl;
  }
  else
  {
    //if (pkt_len == RS0352_PKT_LEN)
    {
      std::cout << " force push, last_header: " << valid_header_idx_ << " type: " << (int)cur_data_type_ << std::endl;
      std::shared_ptr<Buffer> pkt = cb_get_pkt_(pkt_buf_len_);
      memcpy(pkt->data(), readBuffer + valid_header_idx_, pkt_len);
      pkt->setData(0, pkt_len);
      pushPacket(pkt);
    }

    push_cnt_++;
  }
}

inline std::string InputSerial::HeaderTypeToStr(RS0352HeaderType type)
{
  switch (type)
  {
  case RS0352HeaderType::INVALID:
    {return "INVALID";}
    break;
  case RS0352HeaderType::MSOP:
    {return "MSOP";}
    break;
  case RS0352HeaderType::IMU:
    {return "IMU";}
    break;
  case RS0352HeaderType::DIFOP:
    {return "DIFOP";}
    break;
  case RS0352HeaderType::Other:
    {return "Other";}
    break;
  default:
    {return "Unknown";}
    break;
  }
  return "UnKnown";
}

inline RS0352HeaderType InputSerial::getHeaderType(int nowCnt)
{
  int hexIdx_1 = nowCnt;
  int hexIdx_type = hexIdx_1 + 5;
  uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]);
  uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]);
  uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]);
  uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]);
  uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]);
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    )
  {
    if (data_type == 0x1)
    {
      return RS0352HeaderType::MSOP;
    }
    if (data_type == 0x2)
    {
      return RS0352HeaderType::IMU;
    }
    if (data_type == 0x3)
    {
      return RS0352HeaderType::DIFOP;
    }

    return RS0352HeaderType::Other;
  }
  return RS0352HeaderType::INVALID;
}

inline void InputSerial::recvPacket()
{
  while (!to_exit_recv_)
  {
    grabPacketData();
  }
}

inline int InputSerial::grabPacketData()
{
  int bytes_recv = 0;
  uint8_t recv_buffer[RS0352_RECV_BUFFER_SIZE];
#ifdef _WIN32
  serial_port_.read(recv_buffer, sizeof(recv_buffer), bytes_recv);
#else
  bytes_recv = read(fds_[port_no_ - 1], recv_buffer, sizeof(recv_buffer));
#endif
  memset(readBuffer, 0, sizeof(readBuffer));
  //RS_WARNING << " recv : " << bytes_recv << RS_REND;
  if (bytes_recv > 0)
  {

#if 1
    if (recv_len_con_.size() > 100)
    {
      recv_len_con_.clear();
      recv_len_con_.resize(0);
    }
    recv_len_con_.emplace_back(bytes_recv);
    std::vector<PktInfo0352> infos;
    // Merge Data
    if (tail_tmp_buffer_.size() > 0)
    {
      for (int i = 0; i < tail_tmp_buffer_.size(); i++)
      {
        readBuffer[i] = tail_tmp_buffer_.at(i);
      }
    }

    memcpy(readBuffer + tail_tmp_buffer_.size(), recv_buffer, bytes_recv);
    int mergedLen = bytes_recv + tail_tmp_buffer_.size();

    tail_tmp_buffer_.clear();
    tail_tmp_buffer_.resize(0);
    
    int idx = 0;
    while (idx < mergedLen)
    {
      if (idx > mergedLen - WINDOW_SIZE_0352_OFFSET){ 
        break; 
      }
      int hexIdx_1 = idx;
      int hexIdx_type = hexIdx_1 + 5;
      uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]); //-|
      uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]); //-|
      uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]); //-|
      uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]); //-|
      uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]); //-|
      if ((hex1 == RS0352_HEADER_ID1)
        && (hex2 == RS0352_HEADER_ID2)
        && (hex3 == RS0352_HEADER_ID3) 
        && (hex4 == RS0352_HEADER_ID4) 
        )
      {
        PktInfo0352 pi;
        if (data_type == 0x1) { pi.type = "MSOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x2) { pi.type = "IMU"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x3) { pi.type = "DIFOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
      }
      idx++;
    } // end of WHILE LOOP
    //std::cout << std::endl;
    if (infos.size() <= 1)
    {
      for (int i = 0; i < mergedLen; i++)
      {
        tail_tmp_buffer_.emplace_back(readBuffer[i]);
      }
    }

    if (infos.size() >= 2)
    {
      bool notGood = false;
      //std::vector<int> rec1;
      bool loop_end = false;

      for (int k = 1; k < infos.size(); k++)
      {
        int offset = infos[k].dataIdx - infos[k - 1].dataIdx;
        int expectLen = 0;
        if (infos[k - 1].type == "MSOP") { expectLen = RS0352_PKT_LEN; }
        if (infos[k - 1].type == "IMU") { expectLen = RS0352_IMUPKT_LEN; }
        if (infos[k - 1].type == "DIFOP") { expectLen = RS0352_DIFOPPKT_LEN; }
        if (offset != expectLen)
        {
          notGood = true;
          std::cout << " @" << infos[k - 1].type << " : " <<  infos[k - 1].dataIdx
                    << " next:> " << infos[k].dataIdx << " offset: " << offset << std::endl;
        }
        else
        {
          std::shared_ptr<Buffer> pkt = cb_get_pkt_(ETH_LEN);
          memcpy(pkt->data(), readBuffer + infos[k - 1].dataIdx, expectLen); //-|
          pkt->setData(0, expectLen);
          
          int a = 100;
          int b = 101;
          //if (expectLen == RS0352_IMUPKT_LEN) { a = 47; b = 48; }
          //if (expectLen == RS0352_DIFOPPKT_LEN) { a = 333; b = 334; }

          if ((expectLen == RS0352_PKT_LEN) && (mode_flag_4m_ == false))
          {
            int pkt_cnt = (int)(*(pkt->data() + a)) * 256 + (int)(*(pkt->data() + b)); // TODO
            
            //rec1.emplace_back(pkt_cnt);
            if ((last_cnt_ != -1) && (last_cnt_ != 65535))
            {
              if (pkt_cnt - last_cnt_ > 1)
              {
                loop_end = true;
                RS_DEBUG << " > last: " << last_cnt_ << " now: " << pkt_cnt << RS_REND;
                if (recv_len_con_.size() >= 10)
                {
                  for (int i = 0; i < 10; i++)
                  {
                    RS_WARNING << " " << recv_len_con_.at(recv_len_con_.size() - 1 - 9 + i);
                  }
                  RS_WARNING << " " << RS_REND;
                }
                else
                {
                  for (int i = 0; i < recv_len_con_.size(); i++)
                  {
                    RS_WARNING << " " << recv_len_con_.at(i);
                  }
                  RS_WARNING << " " << RS_REND;
                }
                
              }
            }
            last_cnt_ = pkt_cnt;
          }
          pushPacket(pkt);
          //push_cnt_++;
          //if (push_cnt_ % 3000 == 1)
          //{
          //  RS_INFO << " port: " << port_no_ << " > cnt: " << push_cnt_ << RS_REND; 
          //}
        }
        
      }
      int copy_start_idx = infos[infos.size() - 1].dataIdx;
      for (int i = copy_start_idx; i < mergedLen; i++)
      {
        tail_tmp_buffer_.emplace_back(readBuffer[i]);
      }
      //if (notGood)
      //  std::cout << " || pktno: " << read_pkt_cnt_ << "\n" << std::endl;
    }
    memset(readBuffer, 0, sizeof(readBuffer));
#endif

    return 1;
  }
  return 0;
}

}  // namespace lidar
}  // namespace robosense