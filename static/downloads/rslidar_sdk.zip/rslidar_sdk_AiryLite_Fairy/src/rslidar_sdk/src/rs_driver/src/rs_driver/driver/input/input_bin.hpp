/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once
#include <rs_driver/common/rs_common.hpp>
#include <rs_driver/driver/input/input.hpp>

#include <sstream>
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>


namespace robosense
{
namespace lidar
{
class InputBin : public Input
{
public:
  InputBin(const RSInputParam& input_param)
    : Input(input_param)
  {
    RS_INFO << "init bin file reader: " << RS_REND;
    input_bin_param_ = input_param.input_bin_param;
    std::cout << "PACKET LEN: " << input_bin_param_.RS485_PKT_LEN << std::endl;
    std::cout << "MSOP ID LEN: " << (uint16_t)input_bin_param_.MSOP_ID_LEN << std::endl;
    std::cout << "MSOP ID: ";
    for (int i = 0; i < input_bin_param_.MSOP_ID_LEN; i++)
    {
      std::cout << std::hex << (uint16_t)input_bin_param_.MSOP_ID[i] << " ";
    }
    std::cout << std::dec << std::endl;
    
    this->vec_buffer_.resize(TMP_BUFFER_SIZE);
    //this->rest_tmp_buffer_.resize(TMP_BUFFER_SIZE);
  }

  virtual bool init();
  virtual bool start();
  
  void recvPacket();
  virtual ~InputBin();

  void getFilePos(fpos_t* pos);
  void setFilePos(fpos_t* pos);

  RS0352HeaderType getHeaderType(uint8_t* readBuffer, int nowCnt);
  int grabPacketData();

  long current_pkt_cnt_;
  long long curTurnByteCnt;
  std::vector<long> data_position_dbg_;

  std::vector<uint8_t> vec_buffer_;
  std::vector<uint8_t> tail_tmp_buffer_;
  //std::vector<uint8_t> rest_tmp_buffer_;
  long recv_cnt_; // recv handle action count
  long header_cnt_;
  long read_byte_cnt_;
  long rest_bytes_cnt_;
  bool is_meet_cur_pack_;
  RS0352HeaderType cur_pack_type_;
  RSInputBinParam input_bin_param_;

  int break_case_;
  int last_angle_;

protected:

  virtual void parsePacket(const uint8_t* data, size_t len);
  void parsePacketBin(std::vector<uint8_t> data, size_t len);
  
  FILE* bin_file_;
};

inline bool InputBin::init()
{
  if (init_flag_)
    return true;

  break_case_ = 0;
  recv_cnt_ = 0;
  header_cnt_ = 0;
  read_byte_cnt_ = 0;
  rest_bytes_cnt_ = 0;
  is_meet_cur_pack_ = false;
  cur_pack_type_ = RS0352HeaderType::INVALID;
  
  last_angle_ = -1;

  bin_file_ = fopen(input_param_.pcap_path.c_str(), "rb");
  //bin_file_ = fopen("/home/sti/output_1228_1.bin", "rb");
  if (bin_file_ == NULL) {
    // TODO
    RS_ERROR << "NULL INPUT:" << input_param_.pcap_path.c_str() << RS_REND;
    return false;
  }
  
  init_flag_ = true;
  return true;
}

inline bool InputBin::start()
{
  if (start_flag_)
    return true;

  if (!init_flag_)
  {
    cb_excep_(Error(ERRCODE_STARTBEFOREINIT));
    return false;
  }

  to_exit_recv_ = false;
  recv_thread_ = std::thread(std::bind(&InputBin::recvPacket, this));

  start_flag_ = true;
  return true;
}

inline InputBin::~InputBin()
{
  //if (pcap_ != NULL)
  //{
  //  pcap_close(pcap_);
  //  pcap_ = NULL;
  //}
}

inline void InputBin::getFilePos(fpos_t* pos)
{
  FILE* f = bin_file_;
  fgetpos(f, pos);
}

inline void InputBin::setFilePos(fpos_t* pos)
{
  FILE* f = bin_file_;
  fsetpos(f, pos);
}

inline RS0352HeaderType InputBin::getHeaderType(uint8_t* readBuffer, int nowCnt)
{
  int hexIdx_1 = nowCnt;
  int hexIdx_type = hexIdx_1 + 5;
  uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]);
  uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]);
  uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]);
  uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]);
  uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]);
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    )
  {
    if (data_type == 0x1)
    {
      return RS0352HeaderType::MSOP;
    }
    if (data_type == 0x2)
    {
      return RS0352HeaderType::IMU;
    }
    if (data_type == 0x3)
    {
      return RS0352HeaderType::DIFOP;
    }

    return RS0352HeaderType::Other;
  }
  return RS0352HeaderType::INVALID;
}

inline void InputBin::recvPacket()
{
  while (!to_exit_recv_)
  {
    int ret = grabPacketData();
    if (ret < 0)
    {
      cb_excep_(Error(ERRCODE_PCAPEXIT));
      break;
    }
  }
}

inline int InputBin::grabPacketData()
{
  recv_cnt_ += 1;
  //std::cout << "recv .. " << recv_cnt_ << std::endl;
  fpos_t position;
  fgetpos(bin_file_, &position);
  //std::cout << "pos: " << position.__pos << std::endl;
#ifdef _WIN32
  long start_pos = position;
#else
  long start_pos = position.__pos;
#endif

  uint8_t* raw_data = new uint8_t[TMP_BUFFER_SIZE];
  uint8_t* readBuffer = new uint8_t[TMP_BUFFER_SIZE + 4];
  int validCnt = 0;
  int alreadyReadCnt = 0;
  RS0352HeaderType finalPackType = RS0352HeaderType::INVALID;
  // forced end flag
  // if (position.__pos < 1000)
  {
    size_t bytesRead = fread(raw_data, 1, ONCE_BUFFER_SIZE, bin_file_);
    if (bytesRead > 0)
    {
      bool isMeetNextPack = false;
      // alreadyReadCnt: the pin of window
      alreadyReadCnt = 0;
      if (bytesRead < 5)
        RS_WARNING << "bytesRead < " << 5 << RS_REND;
      // normally, bytesRead == ONCE_BUFFER_SIZE
      
      int bytesReadMerge = tail_tmp_buffer_.size() + bytesRead;
      // Merge Data
      int t_offset = 0;
      if (tail_tmp_buffer_.size() > 0)
      {
        //uint8_t tmp1[4];
        for (int i = 0; i < tail_tmp_buffer_.size(); i++)
        {
          //tmp1[i] = tail_tmp_buffer_.at(i);
          readBuffer[i] = tail_tmp_buffer_.at(i);
        }
        //memcpy(readBuffer, tmp1, tail_tmp_buffer_.size());
        //delete tmp1;
        t_offset = 4;
      }
      memcpy(readBuffer + tail_tmp_buffer_.size(), raw_data, bytesRead);
      tail_tmp_buffer_.clear();
      tail_tmp_buffer_.resize(0);
      delete raw_data;
      
      while (alreadyReadCnt < bytesReadMerge)
      {
        if (alreadyReadCnt >= bytesReadMerge - WINDOW_SIZE_0352_OFFSET)
        {
          // continue to record
          if ((cur_pack_type_ != RS0352HeaderType::INVALID) && (cur_pack_type_ != RS0352HeaderType::Other))
          {
            for (int i = 0; i < 4; i++)
            {
              (this->vec_buffer_).at(validCnt) = readBuffer[alreadyReadCnt + i];
              validCnt++;
              alreadyReadCnt++;
              read_byte_cnt_++;
              int expectedLen = 999999;
              if (cur_pack_type_ == RS0352HeaderType::MSOP)
                expectedLen = RS0352_PKT_LEN;
              if (cur_pack_type_ == RS0352HeaderType::DIFOP)
                expectedLen = RS0352_DIFOPPKT_LEN;
              if (cur_pack_type_ == RS0352HeaderType::IMU)
                expectedLen = RS0352_IMUPKT_LEN;
              if (validCnt >= expectedLen)
              {
                // TODO
                // RS_DEBUG << "ERROR: Valid Cnt is Equal to ONE PKT LENGTH. " << RS_REND;
                // BREAK CASE [C]: Exceed ONE PKT LENGTH.
                finalPackType = cur_pack_type_;
                break; // go to the END of WHILE LOOP
              }
            }
          }
          // transfer to TMP buffer
          else
          {
            for (int i = 0; i < 4; i++)
            {
              tail_tmp_buffer_.push_back(readBuffer[alreadyReadCnt + i]);
              alreadyReadCnt++;
              read_byte_cnt_++;
            }
          }
          RS_DEBUG << "WARN: Reach end of tmp buffer." << RS_REND;
          // BREAK CASE [C-1]: Exceed ONE PKT LENGTH.
          break; // go to the END of WHILE LOOP
        }
        //int hexIdx_1 = alreadyReadCnt;

        //uint8_t hex1 = (uint8_t)(*(readBuffer + hexIdx_1));
        //uint8_t hex2 = (uint8_t)(*(readBuffer + hexIdx_1 + 1));
        //uint8_t hex3 = (uint8_t)(*(readBuffer + hexIdx_1 + 2));
        //uint8_t hex4 = (uint8_t)(*(readBuffer + hexIdx_1 + 3));
        //uint8_t data_type = (uint8_t)(*(readBuffer + hexIdx_1 + 5));
        //// 0352-debug
        //// to get cloud header
        //if ((hex1 == input_bin_param_.MSOP_ID[0]) 
        //  && (hex2 == input_bin_param_.MSOP_ID[1])
        //  && (hex3 == input_bin_param_.MSOP_ID[2])
        //  && (hex4 == input_bin_param_.MSOP_ID[3])
        //  && (data_type == 0x1))
        RS0352HeaderType res = getHeaderType(readBuffer, alreadyReadCnt);
        if ((res != RS0352HeaderType::INVALID) && (res != RS0352HeaderType::Other))
        {
          // CASE: Not meet valid data header yet
          if(((cur_pack_type_ == RS0352HeaderType::INVALID) || (cur_pack_type_ == RS0352HeaderType::Other))
            && (!isMeetNextPack))
          {
            cur_pack_type_ = res;
            // only debug
            // this->data_position_dbg_.push_back(hexIdx_1);
            if (validCnt != 0)
            {
              RS_DEBUG << "ERROR: Valid Cnt is NOT ZERO encountering packet header." << RS_REND;
            }
            header_cnt_ += 1;
            
            // HEADER GRAB PRINT
            //std::cout << "Get the header index: "  << start_pos + alreadyReadCnt - t_offset
            //<< " current header index: "  << alreadyReadCnt
            //<< " header cnt: " << header_cnt_
            //<< std::endl;
            uint8_t hex1 = (uint8_t)(*(readBuffer + alreadyReadCnt));
            (this->vec_buffer_).at(validCnt) = hex1;
            validCnt++;
          }
          // this moment, encounter another valid packet.
          else if (!isMeetNextPack) // CASE: meet another header
          {
            finalPackType = cur_pack_type_;
            // need to RESET the bool flag
            //is_meet_cur_pack_ = false;
            cur_pack_type_ = RS0352HeaderType::INVALID;
            
            // BREAK CASE [A]: Meet Another Header
            break_case_ = 1;
            break; // go to the END of WHILE LOOP
          }
          else // CASE: other cases
          {

          }
        } // Header Grabing Time -- End of IF
        // Already Get the Header // copy valid data
        else if (((cur_pack_type_ != RS0352HeaderType::INVALID) && (cur_pack_type_ != RS0352HeaderType::Other)) 
            && (!isMeetNextPack)) 
        {
          // 0352-debug
          // WARN CASE: DID NOT Get A NEW PACKET HEADER even if valid count is EQUAL to packet length.
          // ACTION: EJECT DATA FORCELY.
          int expectedLen = 999999;
          if (cur_pack_type_ == RS0352HeaderType::MSOP)
            expectedLen = RS0352_PKT_LEN;
          if (cur_pack_type_ == RS0352HeaderType::DIFOP)
            expectedLen = RS0352_DIFOPPKT_LEN;
          if (cur_pack_type_ == RS0352HeaderType::IMU)
            expectedLen = RS0352_IMUPKT_LEN;

          if (validCnt >= expectedLen)
          {
            // TODO
            RS_DEBUG << "ERROR: Valid Cnt Exceed ONE PKT LENGTH. validcnt: " << validCnt << " pkt len: " << expectedLen << RS_REND; 
            //<< "hex1: " << (int)hex1 << " hex2: " << (int)hex2 << RS_REND;
            // need to RESET the bool flag
            //is_meet_cur_pack_ = false;
            finalPackType = cur_pack_type_;
            cur_pack_type_ = RS0352HeaderType::INVALID;
            break_case_ = 2;
            // BREAK CASE [B]: Exceed ONE PKT LENGTH.
            break; // go to the END of WHILE LOOP
          }
          // Just set ONE byte value.
          uint8_t hex1 = (uint8_t)(*(readBuffer + alreadyReadCnt));
          (this->vec_buffer_).at(validCnt) = hex1;
          validCnt++;
        }
        // other cases: cannot encounter.
        else
        {
          //
        }
        // Always plus read cnt AFTER setting value.
        alreadyReadCnt += 1;
        read_byte_cnt_ += 1;
      }
      // END of WHILE LOOP
      
    }
    // Reach the END of FILE. (bytesRead < 0)
    else
    {
      //RS_DEBUG << "reach end of file: " << start_pos << RS_REND;
      //std::cout << "read_bytes: " << read_byte_cnt_ << std::endl;
      //std::cout << "header cnt: " << header_cnt_ << std::endl;

      if (input_param_.pcap_repeat)
      {
        cb_excep_(Error(ERRCODE_PCAPREPEAT));

        vec_buffer_.clear();
        vec_buffer_.resize(TMP_BUFFER_SIZE);
        tail_tmp_buffer_.clear();
        tail_tmp_buffer_.resize(0);
        is_meet_cur_pack_ = false;
        cur_pack_type_ = RS0352HeaderType::INVALID;


        fclose(bin_file_);
        bin_file_ = fopen(input_param_.pcap_path.c_str(), "rb");
        return 0;
      }
      else
      {
        cb_excep_(Error(ERRCODE_PCAPREPEAT));
        delete readBuffer;
        vec_buffer_.clear();
        vec_buffer_.resize(0);
        return -1;
      }
      
    } // bytesRead LEN judgement -- End of IF
  } // END of read bin's CODE BLOCK

#ifdef _WIN32
  position = start_pos + alreadyReadCnt;
#else
  position.__pos = start_pos + alreadyReadCnt;
#endif
  fsetpos(bin_file_, &position);
  // 0352-debug
  // 
  int expectedLen = 999999;
  if (finalPackType == RS0352HeaderType::MSOP)
    expectedLen = RS0352_PKT_LEN;
  if (finalPackType == RS0352HeaderType::DIFOP)
    expectedLen = RS0352_DIFOPPKT_LEN;
  if (finalPackType == RS0352HeaderType::IMU)
    expectedLen = RS0352_IMUPKT_LEN;

  if (validCnt == expectedLen)
  {
    //std::cout << "put this whole packet;" << std::endl;
    parsePacketBin(this->vec_buffer_, validCnt);
    vec_buffer_.clear();
    vec_buffer_.resize(TMP_BUFFER_SIZE);
  }
  
  delete readBuffer;
  return 1;
}

inline void InputBin::parsePacket(const uint8_t* data, size_t len)
{
  std::shared_ptr<Buffer> pkt = cb_get_pkt_(ETH_LEN);
  memcpy(pkt->data(), data, len);
  pkt->setData(0, len);
  pushPacket(pkt);
}

inline void InputBin::parsePacketBin(std::vector<uint8_t> data, size_t len)
{
  std::shared_ptr<Buffer> pkt = cb_get_pkt_(ETH_LEN);
  memcpy(pkt->data(), data.data(), len);
  pkt->setData(0, len);
  if (len == RS0352_PKT_LEN)
  {
    uint8_t* temp_buf = pkt->data();
    int temp_angle = (temp_buf[16] << 8) + temp_buf[17];
    int pkt_seq = (temp_buf[100] << 8) + temp_buf[101];
    if(last_angle_ != -1)
    {
      if((last_angle_ > temp_angle) && (last_angle_ - temp_angle > 35000)) //condition
      {
        //std::cout << "pkt:" << pkt_seq << "last angle: " << last_angle_ << " temp angle:" << temp_angle << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(70));
      }
    }
    last_angle_ = temp_angle;
  }
  pushPacket(pkt);
}

}  // namespace lidar
}  // namespace robosense
