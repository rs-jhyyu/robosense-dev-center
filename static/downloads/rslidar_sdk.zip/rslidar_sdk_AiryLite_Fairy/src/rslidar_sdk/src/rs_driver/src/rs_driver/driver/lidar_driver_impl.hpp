/*********************************************************************************************************************
Copyright (c) 2020 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once

#include <rs_driver/driver/driver_param.hpp>
#include <rs_driver/msg/packet.hpp>
#include <rs_driver/common/error_code.hpp>
#include <rs_driver/macro/version.hpp>
#include <rs_driver/utility/sync_queue.hpp>
#include <rs_driver/utility/buffer.hpp>
#include <rs_driver/driver/input/input_factory.hpp>
#include <rs_driver/driver/input/input_serial_4m.hpp>
#include <rs_driver/driver/decoder/decoder_factory.hpp>

#include <sstream>
#include <utility>
#include <algorithm>

#include <thread>
#include <atomic>
#include <functional>
#include <cstdint>
#include <condition_variable>
#include <map>
#include <chrono>
#include <csignal>

#define FIRST_SEQ_METHOD 1

namespace robosense
{
namespace lidar
{

typedef std::pair<int, std::shared_ptr<Buffer>> BufferPair;

inline std::string getDriverVersion()
{
  std::stringstream stream;
  stream << RSLIDAR_VERSION_MAJOR << "." << RSLIDAR_VERSION_MINOR << "." << RSLIDAR_VERSION_PATCH;

  return stream.str();
}

template <typename T_PointCloud>
class LidarDriverImpl
{
public:
  LidarDriverImpl();
  ~LidarDriverImpl();

  void regPointCloudCallback(const std::function<std::shared_ptr<T_PointCloud>(void)>& cb_get_cloud,
                             const std::function<void(std::shared_ptr<T_PointCloud>)>& cb_put_cloud);
  void regPacketCallback(const std::function<void(const Packet&)>& cb_put_pkt);
  void regImuDataCallback(const std::function<std::shared_ptr<ImuData>(void)>& cb_get_imu_data,
                          const std::function<void(const std::shared_ptr<ImuData>& msg)>& cb_put_imu_data);
  void regExceptionCallback(const std::function<void(const Error&)>& cb_excep);

  bool init(const RSDriverParam& param);
  bool start();
  void stop();

  void decodePacket(const Packet& pkt);
  bool getTemperature(float& temp);
  bool getDeviceInfo(DeviceInfo& info);
  bool getDeviceStatus(DeviceStatus& status);

private:
  void runPacketCallBack(uint8_t* data, size_t data_size, double timestamp, uint8_t is_difop, uint8_t is_frame_begin);
  void runExceptionCallback(const Error& error);

  std::shared_ptr<Buffer> packetGet(size_t size);
  void packetPut(std::shared_ptr<Buffer> pkt, bool stuffed);
  //void packetPutDualSerial(std::shared_ptr<Buffer> pkt, bool stuffed);

  void processPacket();
  void internalProcessPacket(std::shared_ptr<Buffer> pkt);

  std::shared_ptr<ImuData> getImuData();
  void putImuData();

  std::shared_ptr<T_PointCloud> getPointCloud();
  void splitFrame(uint16_t height, double ts);
  void setPointCloudHeader(std::shared_ptr<T_PointCloud> msg, uint16_t height, double chan_ts);

  bool isNewFrame(const uint8_t* packet);

  RSDriverParam driver_param_;
  std::function<std::shared_ptr<T_PointCloud>(void)> cb_get_cloud_;
  std::function<void(std::shared_ptr<T_PointCloud>)> cb_put_cloud_;
  std::function<void(const Packet&)> cb_put_pkt_;
  std::function<std::shared_ptr<ImuData>(void)> cb_get_imu_data_;
  std::function<void(const std::shared_ptr<ImuData>& msg)> cb_put_imu_data_;
  std::function<void(const Error&)> cb_excep_;
  std::function<void(const uint8_t*, size_t)> cb_feed_pkt_;

  std::shared_ptr<Input> input_ptr_;

// 4M code start
  std::shared_ptr<InputSerial4M> input_4m_ptr1_;
  std::shared_ptr<InputSerial4M> input_4m_ptr2_;

  void serialThreadFunc(int portId);
  void processingThreadFunc();
  void parsePackets(const uint8_t* pkt, size_t size);
  
  bool isSeqInRange(uint16_t seq);
  void processOrderedPackets();
  //void signalHandler(int signal);

  void push4MPacket(const Packet0352& packet);
  void parse4MDifopImuPackets(const PacketDifopImu& pkt, size_t len);
  void push4MExpSeq(const int& seq, const int& port_no);
  int getAbsentAngleDiff(int angle1, int angle2);

  std::string device1;
  std::string device2;
  int baud;
  
  static constexpr uint16_t HEADER[4] = {0x5A, 0xFF, 0x55, 0xAA};
  static constexpr uint16_t MAX_SEQ = 65535;
  static constexpr size_t MAX_QUEUE_SIZE = 2000;
  static constexpr int SKIP_THRESHOLD_MS = 2000; // 跳过缺失包的阈值（微秒）

  int fd_ports[2];

  std::atomic<bool> running_{false};
  std::thread mainThread;
  std::thread serialThread1;
  std::thread serialThread2;
  std::thread processingThread;

  // 使用单个队列存储所有数据包
  std::mutex data_mutex_;
  std::condition_variable data_cv_;
  std::array<std::pair<bool, Packet0352>, MAX_SEQ + 1> packet_map_; // 缓冲区
  
  int expected_seq_;

  // 时间跟踪
  std::chrono::steady_clock::time_point last_processed_time_;
  std::chrono::microseconds acc_cost_time_;
  std::atomic<uint32_t> acc_wait_cnt_{0}; 
  std::atomic<uint32_t> map_size_prev_{0};

  // 统计信息
  std::atomic<uint32_t> packets_processed_{0};
  std::atomic<uint32_t> packets_dropped_{0};
  std::atomic<uint32_t> packets_out_of_order_{0};
  std::atomic<uint32_t> serial_read_error_cnt_{0};

  std::vector<uint16_t> cont_;

  // method 01
  std::atomic<uint16_t> recv_offset_count_{0};
  std::atomic<int32_t> recv_offset_val_{-1};
  std::atomic<int32_t> recv_offset_val0_{-1};
  std::array<int32_t, 2> offset_judge_;

  // method 02

  std::atomic<bool> recv_offset_done_{false};
  std::atomic<int32_t> first_seq_port1_{-1};
  std::atomic<int32_t> first_seq_port2_{-1};

  // Decoder
  //std::shared_ptr<DecoderRS0352> decoder_ptr_;

  std::atomic<int32_t> last_packet_azi_{-1};
  int32_t last_azi_cache_[3]; 
  std::atomic<int32_t> last_azi_skip_cnt_{0};
  std::atomic<bool> azi_skip_{false};

  // running is necessary

// 4M code end

  std::shared_ptr<Decoder<T_PointCloud>> decoder_ptr_;
  SyncQueue<std::shared_ptr<Buffer>> free_pkt_queue_;
  SyncQueue<std::shared_ptr<Buffer>> pkt_queue_;

  SyncQueue<std::shared_ptr<BufferPair>> buffer_pair_queue_;
  std::vector<std::shared_ptr<BufferPair>> pair_tmp_vec_;
  int pair_tmp_vec_len_;
  std::vector<std::shared_ptr<BufferPair>> tail_split_vec_;
  int tail_vec_len_;

  std::vector<std::shared_ptr<BufferPair>>* vec1;
  bool rs0352_split_cnt_state_;

  std::thread handle_thread_;
  uint32_t pkt_seq_;
  uint32_t point_cloud_seq_;
  bool to_exit_handle_;
  bool init_flag_;
  bool start_flag_;
};

template <typename T_PointCloud>
inline LidarDriverImpl<T_PointCloud>::LidarDriverImpl()
  : pkt_seq_(0), point_cloud_seq_(0), init_flag_(false), start_flag_(false)
{
}

template <typename T_PointCloud>
inline LidarDriverImpl<T_PointCloud>::~LidarDriverImpl()
{
  stop();
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::processingThreadFunc() {
  std::cout << "Processing thread started\n";
  while (running_) {
      std::unique_lock<std::mutex> lock(data_mutex_);
      // 只有当有新数据包到达时才唤醒处理线程

      data_cv_.wait_for(lock, std::chrono::milliseconds(10),
          [this]()
          { return !running_ || packet_map_[expected_seq_].first; 
      });

      lock.unlock();

      if (!running_) break;
      // TODO: first-seq
      // method 02
#if(FIRST_SEQ_METHOD==2)
      if (recv_offset_done_ == false)
      {
        //std::cout << " init seq: " << expected_seq_ << std::endl;
        continue;
      }
#endif
      processOrderedPackets();
  }
  std::cout << "Processing thread exited\n";
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::serialThreadFunc(int portId) {
    std::cout << "Serial thread " << portId << " started\n";
    while (running_) {
#if(RS0352_4M_ENABLE_PORT1==1)
        if (portId == 1)
            input_4m_ptr1_->recvPacket();
#endif
#if(RS0352_4M_ENABLE_PORT2==1)
        if (portId == 2)
            input_4m_ptr2_->recvPacket();
#endif
    }
    if (portId == 1)
    {
      input_4m_ptr1_->closeInputPorts();
    }
    if (portId == 2)
    {
      input_4m_ptr2_->closeInputPorts();
    }
    std::cout << "Serial thread " << portId << " exited\n";
}

template <typename T_PointCloud>
inline int LidarDriverImpl<T_PointCloud>::getAbsentAngleDiff(int angle1, int angle2)
{
  if (angle1 > angle2)
  {
    int val = 36000 - angle1 + angle2;
    return val;
  }
  else
  {
    int val = abs((int)(angle2 - angle1));
    return val;
  }
  return 0;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::processOrderedPackets() {
    {
        // 查找期望的序号
        //RS_MSG << " ? " << expected_seq_ << " " << packet_map_[expected_seq_].first << RS_REND;
        if (packet_map_[expected_seq_].first)
        {
            // Clear Cont
            acc_wait_cnt_ = 0;
            cont_.clear();cont_.resize(0);
           
            Packet0352 packet;
            bool has_packet = false;
            {
              std::unique_lock<std::mutex> lock(data_mutex_);
              if (packet_map_[expected_seq_].first) {
                  packet = packet_map_[expected_seq_].second;
                  packet_map_[expected_seq_].first = false;
                  has_packet = true;
              }
            } 
            
            // 释放锁

            // 调用解析函数

            if (has_packet)
            {
                int d16 = (int)(packet.second.data()[16]);
                int d17 = (int)(packet.second.data()[17]);
                int azi = d16 * 256 + d17;
                bool angle_valid = true;

                if ((last_azi_cache_[0] > 0) && (last_azi_cache_[1] > 0) && (last_azi_cache_[2] > 0))
                {
                  int val = getAbsentAngleDiff(last_azi_cache_[2], azi);

                  if (val >= 3100)
                  {
                    std::cout << " last: " << last_azi_cache_[2] << " azi: " << azi << " seq: " << expected_seq_ << std::endl;
                    angle_valid = false;
                    //last_azi_skip_cnt_++;
                    azi_skip_ = true;
                  }

                  if ((angle_valid) && (azi_skip_))
                  {
                    int val1 = getAbsentAngleDiff(last_azi_cache_[0], last_azi_cache_[1]);
                    int val2 = getAbsentAngleDiff(last_azi_cache_[1], last_azi_cache_[2]);
                    if ((val1 < 121) && (val2 < 121))
                    {
                      RS_WARNING << " > Resume Pkt Scope. " << RS_REND;
                      azi_skip_ = false;
                    }
                  }

                  {
                    //std::unique_lock<std::mutex> lock(data_mutex_);
                    last_azi_cache_[0] = last_azi_cache_[1];
                    last_azi_cache_[1] = last_azi_cache_[2];
                    last_azi_cache_[2] = azi;
                  }
                }

                if ((angle_valid) && (!azi_skip_))
                {
                  //RS_DEBUG << " " << packet.first << RS_REND;
                  parsePackets(packet.second.data(), RS0352_PKT_LEN);
                }

            }

            {
                std::lock_guard<std::mutex> lock(data_mutex_);
#if((RS0352_4M_ENABLE_PORT1==1)&&(RS0352_4M_ENABLE_PORT2==1))
                expected_seq_ = (expected_seq_ == 65535) ? 0 : expected_seq_ + 1;
#else
#if(RS0352_4M_ENABLE_PORT1==1)
                expected_seq_ = (expected_seq_ == 65534) ? 0 : expected_seq_ + 2;
#endif
#if(RS0352_4M_ENABLE_PORT2==1)
                expected_seq_ = (expected_seq_ == 65535) ? 1 : expected_seq_ + 2;
#endif
#endif
                packets_processed_++;
            }
            
        }
        else
        {
            // 没有找到期望的包，跳过它
            // 但添加一个短暂的休眠，避免忙等待

            RS_WARNING << "wait for ..." << RS_REND;  // mydbg
            //lock.unlock();
            std::this_thread::sleep_for(std::chrono::microseconds(50));
            
            // 更新期望的序号

            {
              std::lock_guard<std::mutex> lock(data_mutex_);
#if((RS0352_4M_ENABLE_PORT1==1)&&(RS0352_4M_ENABLE_PORT2==1))
                expected_seq_ = (expected_seq_ == 65535) ? 0 : expected_seq_ + 1;
#else
#if(RS0352_4M_ENABLE_PORT1==1)
                expected_seq_ = (expected_seq_ == 65534) ? 0 : expected_seq_ + 2;
#endif
#if(RS0352_4M_ENABLE_PORT2==1)
                expected_seq_ = (expected_seq_ == 65535) ? 1 : expected_seq_ + 2;
#endif
#endif
              packets_dropped_++;
            }
        }
    }
}

template <typename T_PointCloud>
inline bool LidarDriverImpl<T_PointCloud>::isSeqInRange(uint16_t seq) {
    // 处理序号循环的情况

    if (seq > MAX_SEQ || seq < 0) {
        return false; // 循环后的序号
    }
    return true;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::parsePackets(const uint8_t* pkt, size_t size) {
    // 添加边界检查
    if (pkt == nullptr) return;
    
    // 确保有足够的数据访问 pkt[100] 和 pkt[101]
    // 这里假设 pkt 至少有 102 字节长
    int pkt_cnt = (int)(pkt[100]) * 256 + (int)(pkt[101]);
    //std::cout << "pkt: " << pkt_cnt << std::endl; // mydbg
    decoder_ptr_->decodeMsopPkt(pkt, size);
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::push4MPacket(const Packet0352& packet)
{
    std::lock_guard<std::mutex> lock(data_mutex_);
    
    uint16_t seq = packet.first;
    //RS_DEBUG << " > seq: " << seq << RS_REND;

    // method 01
#if(FIRST_SEQ_METHOD==1)
    if (recv_offset_count_ == 0)
    {
      int empty = 0;
      for (int i = 0; i < 2; i++)
      {
        if (this->offset_judge_[i] != -1)
        {
	        this->expected_seq_ = this->offset_judge_[i];
          packet_map_[seq].second = packet;
          packet_map_[seq].first = true;
          RS_WARNING << " > first expected seq : " << this->expected_seq_ << RS_REND;
	        recv_offset_count_++;
	        return;
        }
      }
    }
#endif
    // 检查是否是重复包
    if (packet_map_[seq].first) {
        RS_ERROR << " Error: Repeat Seq!! >> " << seq << RS_REND;
        packets_out_of_order_++;
        
        // [不] 忽略重复包!!!
        // 存储数据包
        if (UPDATE_REPEAT == 1)
        {
            packet_map_[seq].second = packet;
        }
        return; 
    }
    
    // 检查是否在合理范围内
    if (!isSeqInRange(seq)) {
        RS_ERROR << " Pkt Seq Error." << RS_REND;
        exit(1);
    }
    
    // 如果队列太大，清空整个map
    if (packet_map_.size() > 65536) {
        RS_WARNING << " CLEAR MAP" << RS_REND;
        //packets_dropped_+=(packet_map_.size());
        //packet_map_.clear();
    }
    
    // 存储数据包
    packet_map_[seq].second = packet;
    packet_map_[seq].first = true;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::parse4MDifopImuPackets(const PacketDifopImu& pkt, size_t len) {
    std::lock_guard<std::mutex> lock(data_mutex_);
    if (len == RS0352_DIFOPPKT_LEN)
        decoder_ptr_->decodeDifopPkt(pkt.data(), RS0352_DIFOPPKT_LEN);
    if (len == RS0352_IMUPKT_LEN)
        decoder_ptr_->decodeImuPkt(pkt.data(), RS0352_IMUPKT_LEN);
    //std::cout << "decoder_ptr_->decodeDifop Imu" << std::endl;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::push4MExpSeq(const int& seq, const int& port_no)
{
  std::lock_guard<std::mutex> lock(data_mutex_);
  //RS_DEBUG << " >> seq " << this->expected_seq_  << RS_REND;
  if (seq <= 0)
  {
      if (fd_ports[port_no - 1] == -1)
      {
          fd_ports[port_no - 1] = (-1) * seq;
          RS_MSG << " > Save port fd : " << fd_ports[port_no - 1] << RS_REND;
      }
      return;
  }
  if (seq == SERIAL_READ_ERROR_CODE)
  {
    serial_read_error_cnt_++;
    if (serial_read_error_cnt_ > 30)
    {
      RS_ERROR << "Serial Error: Too much error data. " << RS_REND;
      //exit(1);
      serial_read_error_cnt_ = 0;
    }
    return;
  }
  // TODO: first-seq
  // method 02
#if(FIRST_SEQ_METHOD==2)
  if ((port_no == 1) && (first_seq_port1_ == -1))
  {
      first_seq_port1_ = seq;
      RS_INFO << " >> EXP SEQ: " << first_seq_port1_ << " port: " << port_no << RS_REND;
  }
  if ((port_no == 2) && (first_seq_port2_ == -1))
  {
      first_seq_port2_ = seq;
      RS_INFO << " >> EXP SEQ: " << first_seq_port2_ << " port: " << port_no << RS_REND;
  }
  
  if ((first_seq_port1_ != -1) && (first_seq_port2_ != -1) && (recv_offset_done_ == false))
  {
      this->expected_seq_ = std::min(first_seq_port1_, first_seq_port2_);
      RS_WARNING << " > first expected seq : " << this->expected_seq_ << RS_REND;
      recv_offset_done_ = true;
  }
#endif  
  // method 01
#if(FIRST_SEQ_METHOD==1)
  for (int i = 0; i < 2; i++)
  {
      if (this->offset_judge_[i] == -1)
      {
          this->offset_judge_[i] = seq;
          break;
      }
  }
#endif
}

template <typename T_PointCloud>
std::shared_ptr<ImuData> LidarDriverImpl<T_PointCloud>::getImuData()
{
  while (1)
  {
    std::shared_ptr<ImuData> imuData = cb_get_imu_data_();
    if (imuData)
    {
      imuData->state = false;
      return imuData;
    }
    LIMIT_CALL(runExceptionCallback(Error(ERRCODE_IMUDATANULL)), 1);
  }
}

template <typename T_PointCloud>
std::shared_ptr<T_PointCloud> LidarDriverImpl<T_PointCloud>::getPointCloud()
{
  while (1)
  {
    std::shared_ptr<T_PointCloud> cloud = cb_get_cloud_();
    if (cloud)
    {
      cloud->points.resize(0);
      return cloud;
    }

    LIMIT_CALL(runExceptionCallback(Error(ERRCODE_POINTCLOUDNULL)), 1);
  }
}

template <typename T_PointCloud>
void LidarDriverImpl<T_PointCloud>::regPointCloudCallback(
    const std::function<std::shared_ptr<T_PointCloud>(void)>& cb_get_cloud,
    const std::function<void(std::shared_ptr<T_PointCloud>)>& cb_put_cloud)
{
  cb_get_cloud_ = cb_get_cloud;
  cb_put_cloud_ = cb_put_cloud;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::regPacketCallback(const std::function<void(const Packet&)>& cb_put_pkt)
{
  cb_put_pkt_ = cb_put_pkt;
}
template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::regImuDataCallback(
    const std::function<std::shared_ptr<ImuData>(void)>& cb_get_imu_data,
    const std::function<void(const std::shared_ptr<ImuData>& msg)>& cb_put_imu_data)
{
  cb_get_imu_data_ = cb_get_imu_data;
  cb_put_imu_data_ = cb_put_imu_data;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::regExceptionCallback(const std::function<void(const Error&)>& cb_excep)
{
  cb_excep_ = cb_excep;
}

template <typename T_PointCloud>
inline bool LidarDriverImpl<T_PointCloud>::init(const RSDriverParam& param)
{
  if (init_flag_)
  {
    return true;
  }

  //
  // decoder
  //
  decoder_ptr_ = DecoderFactory<T_PointCloud>::createDecoder(param.lidar_type, param.decoder_param);

  // judge type
  decoder_ptr_->is_mech_ = isMech(param.lidar_type);
  decoder_ptr_->airy_lite_udp_mode_ = isAiryLiteUdpMode(param.lidar_type, param.input_type);
  decoder_ptr_->airy_lite_4m_mode_ = (isAiryLite4MMode(param.lidar_type, param.input_type))
                                      && (param.input_param.input_serial_param.BAUD_RATE == 4000000);

  // rewrite pkt timestamp or not ?
  decoder_ptr_->enableWritePktTs((cb_put_pkt_ == nullptr) ? false : true);

  // point cloud related
  decoder_ptr_->point_cloud_ = getPointCloud();
  decoder_ptr_->regCallback(
      std::bind(&LidarDriverImpl<T_PointCloud>::runExceptionCallback, this, std::placeholders::_1),
      std::bind(&LidarDriverImpl<T_PointCloud>::splitFrame, this, std::placeholders::_1, std::placeholders::_2));

  if (cb_put_imu_data_)
  {
    decoder_ptr_->imuDataPtr_ = getImuData();
    decoder_ptr_->regImuCallback(std::bind(&LidarDriverImpl<T_PointCloud>::putImuData, this));
  }

  double packet_duration = decoder_ptr_->getPacketDuration();
  bool is_jumbo = isJumbo(param.lidar_type);

  //
  // input
  //
  if (decoder_ptr_->airy_lite_4m_mode_)
  {
    // 4m code start
    RS_DEBUG << " -> seq method 0" << FIRST_SEQ_METHOD << RS_REND;

    fd_ports[0] = -1;
    fd_ports[1] = -1;
    
    offset_judge_[0] = -1;
    offset_judge_[1] = -1;

    last_azi_cache_[0] = -1;
    last_azi_cache_[1] = -1;
    last_azi_cache_[2] = -1;
    
    this->baud = param.input_param.input_serial_param.BAUD_RATE;
    this->device1 = param.input_param.input_serial_param.PORT_NAME;
    this->device2 = param.input_param.input_serial_param.PORT_NAME2;
  
    // 设置回调函数
    
    auto callback = [this](const Packet0352& packet) {
      this->push4MPacket(packet); // merge TODO
    };
  
    auto callback_seq = [this](const int& seq, const int& port_no) {
      this->push4MExpSeq(seq, port_no); // merge TODO
    };
    auto callback_difop_imu = [this](const PacketDifopImu& pkt, size_t len) {
      this->parse4MDifopImuPackets(pkt, len); // merge TODO
    };
#if(RS0352_4M_ENABLE_PORT1==1)
    input_4m_ptr1_ = std::make_shared<InputSerial4M>(1, this->device1, this->baud, callback, callback_seq, callback_difop_imu);
    input_4m_ptr1_->init();
#endif
    // 1vs2
#if(RS0352_4M_ENABLE_PORT2==1)
    input_4m_ptr2_ = std::make_shared<InputSerial4M>(2, this->device2, this->baud, callback, callback_seq, callback_difop_imu);
    input_4m_ptr2_->init();
#endif
    // 4m code end
  }
  else
  {
    if (param.input_type == InputType::RS485_LIDAR)
      input_ptr_ = InputFactory::createInputDualSerialPort(param.input_param, 1);
    else
      input_ptr_ = InputFactory::createInput(param.input_type, param.input_param, is_jumbo, packet_duration, cb_feed_pkt_);

    input_ptr_->regCallback(
      std::bind(&LidarDriverImpl<T_PointCloud>::runExceptionCallback, this, std::placeholders::_1),
      std::bind(&LidarDriverImpl<T_PointCloud>::packetGet, this, std::placeholders::_1),
      std::bind(&LidarDriverImpl<T_PointCloud>::packetPut, this, std::placeholders::_1, std::placeholders::_2));
  }
  
  if (param.input_type == InputType::PCAP_FILE)
  {
    input_ptr_->regSplitFrameCallback(
        std::bind(&LidarDriverImpl<T_PointCloud>::isNewFrame, this, std::placeholders::_1));
  }

  if (!decoder_ptr_->airy_lite_4m_mode_)
  {
    if (!input_ptr_->init())
    {
      goto failInputInit;
    }
  }
  
  driver_param_ = param;
  init_flag_ = true;
  return true;

failInputInit:
  input_ptr_.reset();
  decoder_ptr_.reset();
  input_4m_ptr1_.reset();
  input_4m_ptr2_.reset();
  return false;
}

template <typename T_PointCloud>
inline bool LidarDriverImpl<T_PointCloud>::start()
{
  if (start_flag_)
  {
    return true;
  }

  if (!init_flag_)
  {
    return false;
  }

  to_exit_handle_ = false;
  
  if (decoder_ptr_->airy_lite_4m_mode_)
  {
    running_ = true; // merge TODO // start_flag_
    expected_seq_ = -1;
#if(RS0352_4M_ENABLE_PORT1==1)
    serialThread1 = std::thread(&LidarDriverImpl<T_PointCloud>::serialThreadFunc, this, 1);
#endif
#if(RS0352_4M_ENABLE_PORT2==1)
    serialThread2 = std::thread(&LidarDriverImpl<T_PointCloud>::serialThreadFunc, this, 2);
#endif
    processingThread = std::thread(&LidarDriverImpl<T_PointCloud>::processingThreadFunc, this);
  }
  else
  {
    handle_thread_ = std::thread(std::bind(&LidarDriverImpl<T_PointCloud>::processPacket, this));
    input_ptr_->start();
    start_flag_ = true;
  }
  //arrange_thread_ = std::thread(std::bind(&LidarDriverImpl<T_PointCloud>::sortPacket, this));

  
  //if (decoder_ptr_->airy_lite_4m_mode_)
  //  input_ptr2_->start();

  //start_flag_ = true;
  return true;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::stop()
{
  if (!start_flag_)
  {
    return;
  }

  if (!decoder_ptr_->airy_lite_4m_mode_)
    input_ptr_->stop();

  to_exit_handle_ = true;
  if (decoder_ptr_->airy_lite_4m_mode_)
  {
    serialThread1.join();
    serialThread2.join();
    processingThread.join();
  }
  else
    handle_thread_.join();

  // clear all points before next session
  if (decoder_ptr_->point_cloud_)
  {
    decoder_ptr_->point_cloud_->points.clear();
  }

  start_flag_ = false;
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::decodePacket(const Packet& pkt)
{
  cb_feed_pkt_(pkt.buf_.data(), pkt.buf_.size());
}

template <typename T_PointCloud>
inline bool LidarDriverImpl<T_PointCloud>::getTemperature(float& temp)
{
  if (decoder_ptr_ == nullptr)
  {
    return false;
  }
  return decoder_ptr_->getTemperature(temp);
}

template <typename T_PointCloud>
inline bool LidarDriverImpl<T_PointCloud>::getDeviceInfo(DeviceInfo& info)
{
  if (decoder_ptr_ == nullptr)
  {
    return false;
  }

  return decoder_ptr_->getDeviceInfo(info);
}

template <typename T_PointCloud>
inline bool LidarDriverImpl<T_PointCloud>::getDeviceStatus(DeviceStatus& status)
{
  if (decoder_ptr_ == nullptr)
  {
    return false;
  }

  return decoder_ptr_->getDeviceStatus(status);
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::runPacketCallBack(uint8_t* data, size_t data_size, double timestamp,
                                                             uint8_t is_difop, uint8_t is_frame_begin)
{
  if (cb_put_pkt_)
  {
    Packet pkt;
    pkt.timestamp = timestamp;
    pkt.is_difop = is_difop;
    pkt.is_frame_begin = is_frame_begin;
    pkt.seq = pkt_seq_++;
    pkt.frame_id = driver_param_.frame_id;

    pkt.buf_.resize(data_size);
    memcpy(pkt.buf_.data(), data, data_size);
    cb_put_pkt_(pkt);
  }
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::runExceptionCallback(const Error& error)
{
  if (cb_excep_)
  {
    cb_excep_(error);
  }
}

template <typename T_PointCloud>
inline std::shared_ptr<Buffer> LidarDriverImpl<T_PointCloud>::packetGet(size_t size)
{
  std::shared_ptr<Buffer> pkt = free_pkt_queue_.pop();
  if (pkt.get() != NULL)
  {
    return pkt;
  }

  return std::make_shared<Buffer>(size);
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::packetPut(std::shared_ptr<Buffer> pkt, bool stuffed)
{
  constexpr static int PACKET_POOL_MAX = 10240;

  if (!stuffed)
  {
    free_pkt_queue_.push(pkt);
    return;
  }

  size_t sz = pkt_queue_.push(pkt);
  if (sz > PACKET_POOL_MAX)
  {
    LIMIT_CALL(runExceptionCallback(Error(ERRCODE_PKTBUFOVERFLOW)), 1);
    pkt_queue_.clear();
  }
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::internalProcessPacket(std::shared_ptr<Buffer> pkt)
{
  static const uint8_t msop_id[] = { 0x55, 0xAA };
  static const uint8_t difop_id[] = { 0xA5, 0xFF };
  static const uint8_t imu_id[] = { 0xAA, 0x55 };
  static const uint8_t RS0352_DATA_HEADER_ID[4] = { 0x5A, 0xFF, 0x55, 0xAA };
  uint8_t* id = pkt->data();
  if (memcmp(id, RS0352_DATA_HEADER_ID, sizeof(RS0352_DATA_HEADER_ID)) == 0)
  {
    if (*(id + 5) == 0x1)
    {
      bool pkt_to_split = decoder_ptr_->processMsopPkt(pkt->data(), pkt->dataSize());
      runPacketCallBack(pkt->data(), pkt->dataSize(), decoder_ptr_->prevPktTs(), false, pkt_to_split);  // msop packet
    }
    if (*(id + 5) == 0x3)
    {
      decoder_ptr_->processDifopPkt(pkt->data(), pkt->dataSize());
      runPacketCallBack(pkt->data(), pkt->dataSize(), 0, true, false);  // difop packet
    }
    if (*(id + 5) == 0x2)
    {
      decoder_ptr_->processImuPkt(pkt->data(), pkt->dataSize());  // imu packet
    }
  }
  if (memcmp(id, msop_id, sizeof(msop_id)) == 0)
  {
    bool pkt_to_split = decoder_ptr_->processMsopPkt(pkt->data(), pkt->dataSize());
    runPacketCallBack(pkt->data(), pkt->dataSize(), decoder_ptr_->prevPktTs(), false, pkt_to_split);  // msop packet
  }
  else if (memcmp(id, difop_id, sizeof(difop_id)) == 0)
  {
    decoder_ptr_->processDifopPkt(pkt->data(), pkt->dataSize());
    runPacketCallBack(pkt->data(), pkt->dataSize(), 0, true, false);  // difop packet
  }
  else if (memcmp(id, imu_id, sizeof(imu_id)) == 0)
  {
    decoder_ptr_->processImuPkt(pkt->data(), pkt->dataSize());  // imu packet
  }

  free_pkt_queue_.push(pkt);
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::processPacket()
{
  while (!to_exit_handle_)
  {
    std::shared_ptr<Buffer> pkt = pkt_queue_.popWait(500000);
    if (pkt.get() == NULL)
    {
      continue;
    }

    internalProcessPacket(pkt);
  }
}

template <typename T_PointCloud>
inline void LidarDriverImpl<T_PointCloud>::putImuData()
{
  std::shared_ptr<ImuData> imuData = decoder_ptr_->imuDataPtr_;
  if (imuData->state && this->cb_put_imu_data_)
  {
    this->cb_put_imu_data_(imuData);
    decoder_ptr_->imuDataPtr_ = getImuData();
  }
}
template <typename T_PointCloud>
void LidarDriverImpl<T_PointCloud>::splitFrame(uint16_t height, double ts)
{
  std::shared_ptr<T_PointCloud> cloud = decoder_ptr_->point_cloud_;
  if (cloud->points.size() > 0)
  {
    if (decoder_ptr_->airy_lite_udp_mode_)
    {
      if (this->decoder_ptr_->angles_ready_)
        this->decoder_ptr_->angles_ready_cnt_++;
      if (this->decoder_ptr_->angles_ready_cnt_ > 1)
      {
        if (this->decoder_ptr_->angles_ready_cnt_ == 2)
        {
          RS_INFO << "Angles Ready." << RS_REND;
        }
        setPointCloudHeader(cloud, height, ts);
        cb_put_cloud_(cloud);
        decoder_ptr_->point_cloud_ = getPointCloud();
      }
      else
      {
        decoder_ptr_->point_cloud_ = getPointCloud();
      }
    }
    else
    {
      setPointCloudHeader(cloud, height, ts);
      cb_put_cloud_(cloud);
      decoder_ptr_->point_cloud_ = getPointCloud();
    }
  }
}

template <typename T_PointCloud>
void LidarDriverImpl<T_PointCloud>::setPointCloudHeader(std::shared_ptr<T_PointCloud> msg, uint16_t height, double ts)
{
  msg->seq = point_cloud_seq_++;
  msg->timestamp = ts;
  msg->is_dense = driver_param_.decoder_param.dense_points;
  if (msg->is_dense)
  {
    msg->height = 1;
    msg->width = (uint32_t)msg->points.size();
  }
  else
  {
    msg->height = height;
    msg->width = (uint32_t)msg->points.size() / msg->height;
  }

  msg->frame_id = driver_param_.frame_id;
}

template <typename T_PointCloud>
inline bool LidarDriverImpl<T_PointCloud>::isNewFrame(const uint8_t* packet)
{
  static const uint8_t msop_header_id[] = { 0x55, 0xAA };
  static const uint8_t msop_header_id2[] = { 0x5A, 0xFF };
  if (decoder_ptr_ != nullptr)
  {
    if (memcmp(packet, msop_header_id, sizeof(msop_header_id)) == 0||
        memcmp(packet, msop_header_id2, sizeof(msop_header_id2)) == 0)
    {
      return decoder_ptr_->isNewFrame(packet);
    }
  }
  return false;
}

}  // namespace lidar
}  // namespace robosense
