/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once
#include <rs_driver/driver/decoder/decoder_mech.hpp>
#include <iomanip>

namespace robosense
{
namespace lidar
{

#pragma pack(push, 1)

typedef struct 
{
  int16_t  vdc_top_vbus;       //  2  // 185
  int16_t  vdc_rx_vbd_p;       //  2
  int16_t  vdc_rx_vbd_n;       //  2
  int16_t  current_bot_vbus;   //  2
  int16_t  temp_top_rx_n;      //  2
  int16_t  temp_top_rx_p;      //  2
  int16_t  temp_top_fpga;      //  2
  int16_t  temp_bot_imu;       //  2
  uint16_t pwm_top;            //  2
  int16_t  volatge_bot_vbus;   //  2
  int16_t  current_board_a;    //  2
  int16_t  current_board_b;    //  2
  int16_t  current_board_c;    //  2
  uint8_t   reserved[60];       // 60
} RS0352DifopScrollData;


typedef struct
{
  uint8_t id[4];       // 4 bytes
  uint8_t reserved0;                  // 1
  uint8_t data_type;                  // 1
  RSTimestampUTC timestamp;           //10
  uint16_t rpm_set;                   // 2
  uint16_t rpm;                       // 2
  uint8_t reserved1[8];               // 8
  uint8_t pl_ver[5];                  // 5
  uint8_t app_ver[5];                 // 5
  uint8_t mot_ver[5];                 // 5
  uint8_t reserved2[8];             // 8
  uint8_t power_top_state;          // 1
  uint8_t reserved3[5];             // 5
  RSSN sn;                            // 6
  uint8_t reserved4[18];             // 18
  uint8_t gps_state;                  // 1
  uint16_t vert_calib[24];           // 48
  uint8_t  vert_symb[3];             //  3
  uint16_t horiz_calib[24];          // 48 
  uint8_t  horiz_symb[3];            //  3
  uint8_t  scroll_type;              //  1  // 184
  RS0352DifopScrollData scroll_data; // 86
  uint8_t  reserved5[14];            // 14
  uint32_t qx;                        // 4    
  uint32_t qy;                        // 4  
  uint32_t qz;                        // 4  
  uint32_t qw;                        // 4  
  uint32_t x;                         // 4 
  uint32_t y;                         // 4 
  uint32_t z;                         // 4 
  uint8_t  reserved6[14];            // 14
  uint8_t eye_safe_state;            //  1
  uint8_t  reserved7[5];             //  5
  uint16_t pkt_cnt;                   // 2
  uint16_t crc;                       // 2
} RS0352DifopPkt;


typedef struct
{
  uint8_t id[4]; // 4 bytes
  uint8_t reserved;  // 1
  uint8_t data_type; //1
  RSTimestampUTC timestamp; //10
} RS0352PktHeader;  // 16 bytes

typedef struct
{
  uint16_t distance; // 2 bytes
  uint8_t intensity; // 1 byte
} RS0352Channel; // 3 bytes

typedef struct
{
  uint16_t azimuth; // 2 bytes
  RS0352Channel channels[24];  // 72 bytes
  uint8_t window_conta_level[6]; // 6 bytes
  uint8_t lidar_state;  // 1 byte
  uint8_t reserved[3];  // 3 bytes
  uint16_t pkt_cnt;     // 2 bytes
} RS0352MsopBlock;  // 86 bytes

typedef struct
{
  RS0352PktHeader header; //16 bytes
  RS0352MsopBlock blocks[1];  // 86 bytes
  uint16_t crc;     // 2 bytes
} RS0352MsopPkt;  // 104 bytes

typedef struct
{
  uint8_t id[4];
  uint8_t reserved;  // 1
  uint8_t data_type; //1
  RSTimestampUTC timestamp;
  uint32_t acceIx;
  uint32_t acceIy;
  uint32_t acceIz;
  uint32_t gyrox;
  uint32_t gyroy;
  uint32_t gyroz;
  int32_t temperature;
  uint8_t odr;       // output data rate
  uint8_t acceIFsr;  // accel full scale range
                     // 0: +/- 2g
                     // 1: +/- 4g
                     // 2: +/- 8g
                     // 3: +/- 16g

  uint8_t gyroIFsr;  // gyro full scale range
                     // 0: +/- 250 dps
                     // 1: +/- 500 dps
                     // 2: +/- 1000 dps
                     // 3: +/- 2000 dps
  uint16_t cnt;   // 47 48
  uint16_t tail;  // 49 50
} RS0352ImuPkt;

#pragma pack(pop)

template <typename T_PointCloud>
class DecoderRS0352 : public DecoderMech<T_PointCloud>
{
public:

  virtual void decodeDifopPkt(const uint8_t* pkt, size_t size);
  virtual bool decodeMsopPkt(const uint8_t* pkt, size_t size);
  void decodeImuPkt(const uint8_t* pkt, size_t size) override;
  virtual ~DecoderRS0352() = default;

  explicit DecoderRS0352(const RSDecoderParam& param);
  virtual bool isNewFrame(const uint8_t* packet) override;
  void decodeDifopAngles(const uint8_t* packet);
  int last_azi_;
  std::vector<int> cur_angles_;
  std::vector<int> cur_seqs_;
  constexpr static float FSR_BASE = 32768.0;
#ifndef UNIT_TEST
protected:
#endif

  static RSDecoderMechConstParam& getConstParam();
  static RSEchoMode getEchoMode(uint8_t mode);

  template <typename T_BlockIterator>
  bool internDecodeMsopPkt(const uint8_t* pkt, size_t size);
  int point_id_;
  int ang_ret_;
  int frame_cnt_;
  int last_cnt_;
  bool config_from_file_;
};

template <typename T_PointCloud>
inline RSDecoderMechConstParam& DecoderRS0352<T_PointCloud>::getConstParam()
{
  static RSDecoderMechConstParam param = 
  {
    104 // msop len
      , 337 // difop len
      , 4 // msop id len
      , 4 // difop id len
      , {0x5A, 0xFF, 0x55, 0xAA} // msop id
    , {0x5A, 0xFF, 0x55, 0xAA} // difop id
    , {0xFF, 0xEE} // block id
    , 24 // laser number 
    , 1 // blocks per packet
      , 24 // channels per block
      , 0.1f // distance min
      , 100.0f // distance max
      , 0.005f // distance resolution
      , 0.01f // temperature resolution
      // lens center
      , 0.0088f // RX
      , 0.0066f // RY
      , 0.0483f // RZ
  };

  INIT_ONLY_ONCE();

  float blk_ts = 166.6f;
  float firing_tss[] = 
  {
    0.00f, 0.00f, 0.00f, 0.00f, 0.00f, 0.00f, 
    25.0f, 25.0f, 25.0f, 25.0f, 25.0f, 25.0f, 
    75.0f, 75.0f, 75.0f, 75.0f, 75.0f, 75.0f, 
    125.0f, 125.0f, 125.0f, 125.0f, 125.0f, 125.0f
  };

  param.BLOCK_DURATION = blk_ts / 1000000;
  for (uint16_t i = 0; i < sizeof(firing_tss)/sizeof(firing_tss[0]); i++)
  {
    param.CHAN_TSS[i] = (double)firing_tss[i] / 1000000;
    param.CHAN_AZIS[i] = firing_tss[i] / blk_ts;
  }

  return param;
}

template <typename T_PointCloud>
inline RSEchoMode DecoderRS0352<T_PointCloud>::getEchoMode(uint8_t mode)
{
  switch (mode)
  {
    case 0x00: // dual return
      return RSEchoMode::ECHO_DUAL;
    case 0x01: // strongest return
    case 0x02: // last return
    default:
      return RSEchoMode::ECHO_SINGLE;
  }
}

template <typename T_PointCloud>
inline DecoderRS0352<T_PointCloud>::DecoderRS0352(const RSDecoderParam& param)
  : DecoderMech<T_PointCloud>(getConstParam(), param)
{
  point_id_ = 0;
  this->IMU_LEN = 51;   //imu packet len
  this->IMU_ID_LEN = 4;  //imu id len 
  this->IMU_ID[0] = 0x5A;
  this->IMU_ID[1] = 0xFF;
  this->IMU_ID[2] = 0x55;
  this->IMU_ID[3] = 0xAA;
  this->ang_ret_ = 0;
  this->frame_cnt_ = 0;
  this->last_cnt_ = -1;
  this->last_azi_ = -1;
}

template <typename T_PointCloud>
inline void DecoderRS0352<T_PointCloud>::decodeDifopAngles(const uint8_t* packet)
{
  const static int32_t RS_ONE_ROUND = 36000;

  this->rps_ = 10;
  
  // blocks per frame
  this->blks_per_frame_ = (uint16_t)(1 / (this->rps_ * this->mech_const_param_.BLOCK_DURATION));

  // block diff of azimuth
  this->block_az_diff_ = 
    (uint16_t)static_cast<int>((RS_ONE_ROUND * this->rps_ * this->mech_const_param_.BLOCK_DURATION) + 0.5f);


  // load angles
  //if (!this->param_.config_from_file && !this->angles_ready_)
  //{
  //  int ret = this->chan_angles_.loadFromDifop0352(packet);
  //  
  //  this->angles_ready_ = (ret == 0);
  //}

  {
    static const int ANGLE_OFFSET = 82;
    int ret = this->chan_angles_.loadFromDifop0352(packet+ANGLE_OFFSET);
    if (ret > 0)
    {
      this->angles_ready_ = true;
      if (ret != ang_ret_)
      {
        ang_ret_ = ret;
        RS_DEBUG << " > Refresh Difop. " << ret << RS_REND;
      }
    }
  }
}

template <typename T_PointCloud>
inline void DecoderRS0352<T_PointCloud>::decodeDifopPkt(const uint8_t* packet, size_t size)
{
  const RS0352DifopPkt& pkt = *(const RS0352DifopPkt*)(packet);
  const float scroll_data_res = 0.01;
  int scroll_type = (int)(pkt.scroll_type);
  if (scroll_type == 1)
  {
    this->is_get_temperature_ = true;
    this->temperature_ = ntohs(pkt.scroll_data.temp_top_rx_n) * this->const_param_.TEMPERATURE_RES;
    //std::cout << " >>> this->temperature_: " << this->temperature_ << std::endl;
  
    this->device_status_.vdc_top_vbus      =  RS_SWAP_INT16(pkt.scroll_data.vdc_top_vbus)     * scroll_data_res;
    this->device_status_.vdc_rx_vbd_p      =  RS_SWAP_INT16(pkt.scroll_data.vdc_rx_vbd_p)     * scroll_data_res;
    this->device_status_.vdc_rx_vbd_n      =  RS_SWAP_INT16(pkt.scroll_data.vdc_rx_vbd_n)     * scroll_data_res;
    this->device_status_.current_bot_vbus  =  RS_SWAP_INT16(pkt.scroll_data.current_bot_vbus) * scroll_data_res;
    this->device_status_.temp_top_rx_n     =  RS_SWAP_INT16(pkt.scroll_data.temp_top_rx_n)    * scroll_data_res;
    this->device_status_.temp_top_rx_p     =  RS_SWAP_INT16(pkt.scroll_data.temp_top_rx_p)    * scroll_data_res;
    this->device_status_.temp_bot_imu      =  RS_SWAP_INT16(pkt.scroll_data.temp_bot_imu)     * scroll_data_res;
    this->device_status_.pwm_top           =  RS_SWAP_INT16(pkt.scroll_data.pwm_top);
    this->device_status_.volatge_bot_vbus  =  RS_SWAP_INT16(pkt.scroll_data.volatge_bot_vbus) * scroll_data_res;
    this->device_status_.current_board_a   =  RS_SWAP_INT16(pkt.scroll_data.current_board_a)  * 0.1;
    this->device_status_.current_board_b   =  RS_SWAP_INT16(pkt.scroll_data.current_board_b)  * 0.1;
    this->device_status_.current_board_c   =  RS_SWAP_INT16(pkt.scroll_data.current_board_c)  * 0.1;

    this->device_status_.power_top_state = static_cast<bool>(pkt.power_top_state);
    this->device_status_.eye_safe_state = static_cast<bool>(pkt.eye_safe_state & 0x1);
    this->device_status_.eye_safe_en_state = static_cast<bool>(pkt.eye_safe_state >> 4 & 0x1); 

    this->device_status_.state = true;
  }

  this->device_status_.pps_lock_flag  = (int)(pkt.gps_state & 0x01);
  this->device_status_.gprmc_flag     = (int)((pkt.gps_state >> 3) & (0x01));
  this->device_status_.pps_input_flag = (int)((pkt.gps_state >> 4) & (0x01));

  this->device_info_.qx = convertUint32ToFloat(ntohl(pkt.qx));
  this->device_info_.qy = convertUint32ToFloat(ntohl(pkt.qy));
  this->device_info_.qz = convertUint32ToFloat(ntohl(pkt.qz));
  this->device_info_.qw = convertUint32ToFloat(ntohl(pkt.qw));

  this->device_info_.x = convertUint32ToFloat(ntohl(pkt.x));
  this->device_info_.y = convertUint32ToFloat(ntohl(pkt.y));
  this->device_info_.z = convertUint32ToFloat(ntohl(pkt.z));
  
  memcpy(this->device_info_.sn, pkt.sn.num, 6);
  memcpy(this->device_info_.top_ver, pkt.pl_ver, 5);
  memcpy(this->device_info_.bottom_ver, pkt.app_ver, 5);
  memcpy(this->device_info_.mot_ver, pkt.mot_ver, 5);

  this->device_info_.state = true;
  decodeDifopAngles(packet);
}

template <typename T_PointCloud>
inline void DecoderRS0352<T_PointCloud>::decodeImuPkt(const uint8_t* packet, size_t size)
{
  const RS0352ImuPkt& pkt = *(const RS0352ImuPkt*)(packet);
  if (this->imuDataPtr_ && this->cb_imu_data_ && !this->imuDataPtr_->state)
  {
    if (this->param_.use_lidar_clock)
    {
      this->imuDataPtr_->timestamp = parseTimeUTCWithUs(&pkt.timestamp) * 1e-6;
      //this->imuDataPtr_->timestamp  = parseTime0352(packet) * 1e-6;
    }
    else
    {
      this->imuDataPtr_->timestamp = getTimeHost() * 1e-6;
    }
    uint8_t acclFsr = 1 << (pkt.acceIFsr + 1);
    
    float acceUnit = acclFsr / FSR_BASE;
    
    float lx = convertUint32ToFloat(ntohl(pkt.acceIx));
    float ly = convertUint32ToFloat(ntohl(pkt.acceIy));
    float lz = convertUint32ToFloat(ntohl(pkt.acceIz));

    this->imuDataPtr_->linear_acceleration_x = lx;
    this->imuDataPtr_->linear_acceleration_y = ly;
    this->imuDataPtr_->linear_acceleration_z = lz;

    uint16_t gyroFsr = 250 * (1 << pkt.gyroIFsr);
    float gyroUnit = gyroFsr / FSR_BASE * M_PI / 180;

    float avx = convertUint32ToFloat(ntohl(pkt.gyrox));
    float avy = convertUint32ToFloat(ntohl(pkt.gyroy));
    float avz = convertUint32ToFloat(ntohl(pkt.gyroz));

    this->imuDataPtr_->angular_velocity_x = avx;
    this->imuDataPtr_->angular_velocity_y = avy;
    this->imuDataPtr_->angular_velocity_z = avz;

    this->imuDataPtr_->state = true;

    this->cb_imu_data_();
  }
}

template <typename T_PointCloud>
inline bool DecoderRS0352<T_PointCloud>::decodeMsopPkt(const uint8_t* pkt, size_t size)
{
  const RS0352MsopPkt& pkt1 = *(const RS0352MsopPkt*)(pkt);
  bool ret = false;

  //std::cout << " pkt " << ntohs(pkt1.blocks[0].pkt_cnt) << std::endl;
  int now_cnt = ntohs(pkt1.blocks[0].pkt_cnt);

  double pkt_ts = 0;
  static double prev_pkt_ts = 0;
  //if (this->param_.use_lidar_clock)
  {
    pkt_ts = parseTimeUTCWithUs ((RSTimestampUTC*)&pkt1.header.timestamp) * 1e-6;
    //pkt_ts = parseTime0352(pkt) * 1e-6;
  }
  //else
  //{
  //  uint64_t ts = getTimeHost();
//
  //  // roll back to first block to approach lidar ts as near as possible.
  //  pkt_ts = ts * 1e-6 - this->getPacketDuration();
//
  //  if (this->write_pkt_ts_)
  //  {
  //    createTimeUTCWithUs (ts, (RSTimestampUTC*)&pkt1.header.timestamp);
  //  }
  //}
  
  const RS0352MsopBlock& block_0352 = pkt1.blocks[0];

  uint16_t block_az = ntohs(block_0352.azimuth);
  double block_ts = pkt_ts;

  if (this->split_strategy_->newBlock(block_az))
  {
    bool checkCntOk = false;
    if (last_cnt_ != -1)
    {
#if((RS0352_4M_ENABLE_PORT1==1)&&(RS0352_4M_ENABLE_PORT2==1))
      if ((last_cnt_ == 65535) && (now_cnt == 0))
      {
        checkCntOk = true;
      }
      if ((last_cnt_ != 65535) && (now_cnt == last_cnt_ + 1))
      {
        checkCntOk = true;
      }
#else
#if(RS0352_4M_ENABLE_PORT1==1)
      if ((last_cnt_ == 65534) && (now_cnt == 0))
      {
        checkCntOk = true;
      }
      if ((last_cnt_ != 65534) && (now_cnt == last_cnt_ + 2))
      {
        checkCntOk = true;
      }
#endif
#if(RS0352_4M_ENABLE_PORT2==1)
      if ((last_cnt_ == 65535) && (now_cnt == 1))
      {
        checkCntOk = true;
      }
      if ((last_cnt_ != 65535) && (now_cnt == last_cnt_ + 2))
      {
        checkCntOk = true;
      }
#endif
#endif
      
    }

    if (checkCntOk)
    {
      //if ((this->point_cloud_->points.size() < 13000) && (frame_cnt_ > 0))
      //{
      //  for (int x = 0; x < cur_angles_.size(); x++)
      //  {
      //    RS_DEBUG << " " << cur_seqs_.at(x) << ":" << cur_angles_.at(x);
      //  }
      //  RS_DEBUG << " " << RS_REND;

      //  RS_WARNING << "Split at -> " << now_cnt << ":" << block_az << RS_REND;
      //}
      point_id_ = 0;
      this->cb_split_frame_(24, this->prev_pkt_ts_ + \
        (pkt_ts - this->prev_pkt_ts_)*(36000 - last_azi_)/(36000 - last_azi_ + block_az));
      //this->cb_split_frame_(24, prev_pkt_ts + \
      //  (pkt_ts - prev_pkt_ts)*(36000 - last_azi_)/(36000 - last_azi_ + block_az));

      //this->first_point_ts_ = pkt_ts;
      ret = true;
      frame_cnt_++;
      cur_angles_.clear();
      cur_angles_.resize(0);
      cur_seqs_.clear();
      cur_seqs_.resize(0);
    }
    
  }
  
  last_azi_ = block_az;
  last_cnt_ = now_cnt;
  cur_angles_.emplace_back(block_az);
  cur_seqs_.emplace_back(now_cnt);

  for (uint16_t blk = 0; blk < this->const_param_.BLOCKS_PER_PKT; blk++)
  {
    const RS0352MsopBlock& block = pkt1.blocks[blk];
    
    uint16_t azimuth = ntohs(block.azimuth);
    int32_t block_az1 = azimuth;
    
    int32_t block_az_diff;
    
    block_az_diff = this->mech_const_param_.BLOCK_DURATION;
    

    for (uint16_t chan = 0; chan < this->const_param_.CHANNELS_PER_BLOCK; chan++)
    {
      const RS0352Channel& channel = block.channels[chan]; 

      double chan_ts = block_ts + this->mech_const_param_.CHAN_TSS[chan];
      
      int32_t angle_horiz = block_az + (int32_t)((float)block_az_diff * this->mech_const_param_.CHAN_AZIS[chan]);
      int32_t angle_vert = this->chan_angles_.vertAdjust(chan);
      int32_t angle_horiz_final = this->chan_angles_.horizAdjust(chan, angle_horiz);

      float distance = ntohs(channel.distance) * this->const_param_.DISTANCE_RES;
      if (this->distance_section_.in(distance)) {
		    float x = distance * COS(angle_vert) * COS(angle_horiz_final) + this->lidar_lens_center_Rxy_ * COS(angle_horiz);
        float y = -distance * COS(angle_vert) * SIN(angle_horiz_final) - this->lidar_lens_center_Rxy_ * SIN(angle_horiz);
        float z = distance * SIN(angle_vert) + this->mech_const_param_.RZ;
        this->transformPoint(x, y, z);


        typename T_PointCloud::PointT point;
        setX(point, x);
        setY(point, y);
        setZ(point, z);
        setIntensity(point, channel.intensity);

        setTimestamp(point, chan_ts);
        setRing(point, this->chan_angles_.toUserChan(chan));
        point_id_++;

        this->point_cloud_->points.emplace_back(point);
	    }
      else if (!this->param_.dense_points)
      {
        typename T_PointCloud::PointT point;
        setX(point, NAN);
        setY(point, NAN);
        setZ(point, NAN);
        setIntensity(point, 0);
        setTimestamp(point, chan_ts);
        setRing(point, this->chan_angles_.toUserChan(chan));

        this->point_cloud_->points.emplace_back(point);
      }
	    try
      {
	      this->prev_point_ts_ = chan_ts;
	    }
	    catch(const std::exception& e)
      {
        RS_WARNING << e.what() << " chan_ts " << chan_ts << RS_REND;
      }
    }
  }

  this->prev_pkt_ts_ = pkt_ts;

  return ret;
}


template <typename T_PointCloud>
template <typename T_BlockIterator>
inline bool DecoderRS0352<T_PointCloud>::internDecodeMsopPkt(const uint8_t* packet, size_t size)
{
  return true;
}


template <typename T_PointCloud>
inline bool DecoderRS0352<T_PointCloud>::isNewFrame(const uint8_t* packet)
{
  const RS0352MsopPkt& pkt = *(const RS0352MsopPkt*)(packet);
  for (uint16_t blk = 0; blk < this->const_param_.BLOCKS_PER_PKT; blk++)
  {
    const RS0352MsopBlock& block = pkt.blocks[blk];

    int32_t block_az = ntohs(block.azimuth);
    if (this->pre_split_strategy_->newBlock(block_az))
    {
      return true;
    }
  }
  return false;
}

}  // namespace lidar
}  // namespace robosense
