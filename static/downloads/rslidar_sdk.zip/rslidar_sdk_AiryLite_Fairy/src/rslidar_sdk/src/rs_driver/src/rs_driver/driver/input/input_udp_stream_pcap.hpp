/*********************************************************************************************************************
Copyright (c) 2025 RoboSense
All rights reserved

By downloading, copying, installing or using the software you agree to this license. If you do not agree to this
license, do not download, install, copy or use the software.

License Agreement
For RoboSense LiDAR SDK Library
(3-clause BSD License)

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following
disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following
disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the names of the RoboSense, nor Suteng Innovation Technology, nor the names of other contributors may be used
to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*********************************************************************************************************************/

#pragma once
#include <rs_driver/driver/input/input.hpp>
#include <rs_driver/common/rs_common.hpp>

#include <sstream>

#include <pcap.h>
#include <vector>

namespace robosense
{
namespace lidar
{

typedef struct 
{
  std::string type;
  int dataIdx;
} PktInfo0352;

class InputPcapUdpStream : public Input
{
public:
  InputPcapUdpStream(const RSInputParam& input_param)
    : Input(input_param), pcap_(NULL), pcap_offset_(ETH_HDR_LEN), pcap_tail_(0)
  {
    if (input_param.use_vlan)
    {
      pcap_offset_ += VLAN_HDR_LEN;
    }

    pcap_offset_ += input_param.user_layer_bytes;
    pcap_tail_   += input_param.tail_layer_bytes;

    std::stringstream msop_stream, difop_stream, imu_stream;
    if (input_param_.use_vlan)
    {
      msop_stream << "vlan && ";
      difop_stream << "vlan && ";
    }

    msop_stream << "udp dst port " << input_param_.msop_port;
    difop_stream << "udp dst port " << input_param_.difop_port;

    msop_filter_str_ = msop_stream.str();
    difop_filter_str_ = difop_stream.str();

    read_pkt_cnt_ = 0;
    is_meet_cur_pack_ = false;
    valid_cnt_ = 0;
    header_cnt_ = 0;
    push_cnt_ = 0;
    is_meet_valid_prev_msop_ = false;
    tmp_buffer_len_ = 0;

    scroll_buffer_size_ = 0;
    pcap_file_max_bytes_ = 0;
  }

  virtual bool init();
  virtual bool start();
  virtual ~InputPcapUdpStream();

  void getFilePos(fpos_t* pos);
  void setFilePos(fpos_t* pos);
  RS0352HeaderType getHeaderType(int nowCnt);

  uint8_t readBuffer[3000];
  uint8_t scrollBuffer[1000];
  uint8_t tmpBuffer[3000];
  int scroll_buffer_size_;
  std::vector<uint8_t> vec_buffer_;
  std::vector<uint8_t> tmp_buffer_;
  long read_pkt_cnt_;
  bool is_meet_cur_pack_;
  int valid_cnt_;
  long header_cnt_;
  long push_cnt_;
  std::vector<uint8_t> tail_tmp_buffer_;

  long read_byte_cnt_;
  RS0352HeaderType cur_pack_type_;

  int last_angle_;

protected:

  virtual void parsePacket(const uint8_t* data, size_t len);
  int procMsopPacket(const uint8_t* pkt_data, int dataLen);
  //int toParsePrevMsop(int dataLen);

  pcap_t* pcap_;
  size_t pcap_offset_;
  size_t pcap_tail_;
  std::string msop_filter_str_;
  std::string difop_filter_str_;

  bpf_program msop_filter_;
  bpf_program difop_filter_;

  bool difop_filter_valid_;
  bool is_meet_valid_prev_msop_;
  int tmp_buffer_len_;
  long long pcap_file_max_bytes_;
private:
  void recvPacket();
};

inline bool InputPcapUdpStream::init()
{
  char errbuf[PCAP_ERRBUF_SIZE];
  pcap_ = pcap_open_offline(input_param_.pcap_path.c_str(), errbuf);
  if (pcap_ == NULL)
  {
    cb_excep_(Error(ERRCODE_PCAPWRONGPATH));
    return false;
  }

  pcap_compile(pcap_, &msop_filter_, msop_filter_str_.c_str(), 1, 0xFFFFFFFF);

  if ((input_param_.difop_port != 0) && (input_param_.difop_port != input_param_.msop_port))
  {
    pcap_compile(pcap_, &difop_filter_, difop_filter_str_.c_str(), 1, 0xFFFFFFFF);
    difop_filter_valid_ = true;
  }
  
  memset(readBuffer, 0, sizeof(readBuffer));

  memset(scrollBuffer, 0, sizeof(scrollBuffer));
  scroll_buffer_size_ = 0;

  tail_tmp_buffer_.clear();
  tail_tmp_buffer_.resize(0);

  this->vec_buffer_.resize(TMP_BUFFER_SIZE);

#ifdef _WIN32
#else
  //struct stat fileInfo;
  //if (stat(input_param_.pcap_path.c_str(), &fileInfo) == 0) {
    //std::cout << "UDP Stream File size: " << fileInfo.st_size << " bytes" << std::endl;
  //  pcap_file_max_bytes_ = (long long)fileInfo.st_size;
  //} else {
  //  std::cerr << "Error getting file information" << std::endl;
  //  return false;
  //}
#endif

  read_byte_cnt_ = 0;
  is_meet_cur_pack_ = false;
  cur_pack_type_ = RS0352HeaderType::INVALID;

  init_flag_ = true;

  last_angle_ = -1;

  return true;
}

inline RS0352HeaderType InputPcapUdpStream::getHeaderType(int nowCnt)
{
  int hexIdx_1 = nowCnt;
  int hexIdx_type = hexIdx_1 + 5;
  uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]);
  uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]);
  uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]);
  uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]);
  uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]);
  if ((hex1 == RS0352_HEADER_ID1)
    && (hex2 == RS0352_HEADER_ID2)
#if(RS0352_MASK_HEADER==4) 
    && (hex3 == RS0352_HEADER_ID3) 
    && (hex4 == RS0352_HEADER_ID4) 
#endif
    )
  {
    if (data_type == 0x1)
    {
      return RS0352HeaderType::MSOP;
    }
    if (data_type == 0x2)
    {
      return RS0352HeaderType::IMU;
    }
    if (data_type == 0x3)
    {
      return RS0352HeaderType::DIFOP;
    }

    return RS0352HeaderType::Other;
  }
  return RS0352HeaderType::INVALID;
}

inline InputPcapUdpStream::~InputPcapUdpStream()
{
  if (pcap_ != NULL)
  {
    pcap_close(pcap_);
    pcap_ = NULL;
  }
}

inline bool InputPcapUdpStream::start()
{
  if (start_flag_)
    return true;

  if (!init_flag_)
  {
    cb_excep_(Error(ERRCODE_STARTBEFOREINIT));
    return false;
  }

  to_exit_recv_ = false;
  recv_thread_ = std::thread(std::bind(&InputPcapUdpStream::recvPacket, this));

  start_flag_ = true;
  return true;
}

inline void InputPcapUdpStream::getFilePos(fpos_t* pos)
{
#ifdef _WIN32
  pcap_fgetpos(pcap_, pos);
#else
  FILE* f = pcap_file(pcap_);
  fgetpos(f, pos);
#endif
}

inline void InputPcapUdpStream::setFilePos(fpos_t* pos)
{
#ifdef _WIN32
  pcap_fsetpos(pcap_, pos);
#else
  FILE* f = pcap_file(pcap_);
  fsetpos(f, pos);
#endif
}


inline int InputPcapUdpStream::procMsopPacket(const uint8_t* pkt_data, int dataLen)
{
  //if ((*(pkt_data + 34) == 0x1A) &&
  //    (*(pkt_data + 35) == 0x2B) &&
  //    (*(pkt_data + 36) == 0x1A) &&
  //    (*(pkt_data + 37) == 0x2B))
  {
    //udp_pkt_cnt_++;
    memset(readBuffer, 0, sizeof(readBuffer));
    std::vector<PktInfo0352> infos;

    // Merge Data
    if (tail_tmp_buffer_.size() > 0)
    {
      for (int i = 0; i < tail_tmp_buffer_.size(); i++)
      {
        readBuffer[i] = tail_tmp_buffer_.at(i);
      }
    }
  
    memcpy(readBuffer + tail_tmp_buffer_.size(), pkt_data, dataLen);
    int mergedLen = dataLen + tail_tmp_buffer_.size();
    //if (tail_tmp_buffer_.size() > 0)
    //  std::cout <<  " tail: " << tail_tmp_buffer_.size() << "  dlen: " << dataLen - pcap_offset_ << std::endl;

    tail_tmp_buffer_.clear();
    tail_tmp_buffer_.resize(0);
    
    //int idx = 42;
    int idx = 0;
    //while (idx < dataLen)
    while (idx < mergedLen)
    {
      //if (idx >= dataLen - WINDOW_SIZE_0352_OFFSET){ break; }
      if (idx > mergedLen - WINDOW_SIZE_0352_OFFSET){ break; }
      int hexIdx_1 = idx;
      int hexIdx_type = hexIdx_1 + 5;
      uint8_t hex1 = (uint8_t)(readBuffer[hexIdx_1]); //-|
      uint8_t hex2 = (uint8_t)(readBuffer[hexIdx_1 + 1]); //-|
      uint8_t hex3 = (uint8_t)(readBuffer[hexIdx_1 + 2]); //-|
      uint8_t hex4 = (uint8_t)(readBuffer[hexIdx_1 + 3]); //-|
      uint8_t data_type = (uint8_t)(readBuffer[hexIdx_type]); //-|
      if ((hex1 == RS0352_HEADER_ID1)
        && (hex2 == RS0352_HEADER_ID2)
        && (hex3 == RS0352_HEADER_ID3) 
        && (hex4 == RS0352_HEADER_ID4) 
        )
      {
        PktInfo0352 pi;
        if (data_type == 0x1) { pi.type = "MSOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x2) { pi.type = "IMU"; pi.dataIdx = idx; infos.emplace_back(pi); }
        if (data_type == 0x3) { pi.type = "DIFOP"; pi.dataIdx = idx; infos.emplace_back(pi); }
      }
      idx++;
    } // end of WHILE LOOP
    //std::cout << std::endl;
    if (infos.size() == 1)
    {
      int copy_start_idx = infos[0].dataIdx;
      for (int i = copy_start_idx; i < mergedLen; i++)
      {
        tail_tmp_buffer_.emplace_back(readBuffer[i]);
      }
    }
    if (infos.size() > 2)
    {
      bool notGood = false;
      for (int k = 1; k < infos.size(); k++)
      {
        int offset = infos[k].dataIdx - infos[k - 1].dataIdx;
        int expectLen = 0;
        if (infos[k - 1].type == "MSOP") { expectLen = RS0352_PKT_LEN; }
        if (infos[k - 1].type == "IMU") { expectLen = RS0352_IMUPKT_LEN; }
        if (infos[k - 1].type == "DIFOP") { expectLen = RS0352_DIFOPPKT_LEN; }
        if (offset != expectLen)
        {
          notGood = true;
          //std::cout << " @" << infos[k - 1].type << " : " <<  infos[k - 1].dataIdx
          //          << " next:> " << infos[k].dataIdx << " offset: " << offset << std::endl;
          
          //int start_line = infos[k - 1].dataIdx / 16;
          //int start_col = infos[k - 1].dataIdx % 16 + 1;
          //int correct_line = (infos[k - 1].dataIdx + expectLen) / 16;
          //int correct_col = (infos[k - 1].dataIdx + expectLen) % 16 + 1;
          //int actual_line = infos[k].dataIdx / 16;
          //int actual_col = infos[k].dataIdx % 16 + 1;
          //printf(" >> wireshark start       line: %03X0 | col: %d \n", start_line, start_col);
          //printf(" >> wireshark correct end line: %03X0 | col: %d \n", correct_line, correct_col);
          //printf(" >> wireshark actual  end line: %03X0 | col: %d \n", actual_line, actual_col);
          //std::cout << "wireshark start line: " << 1 << " wireshark correct end line: " << 1
          //          << "wireshark actual end line: " << 1 << std::endl;
        }
        else
        {
          uint8_t* dataToSend = new uint8_t[expectLen];
          memcpy(dataToSend, readBuffer + infos[k - 1].dataIdx, expectLen); //-|
          parsePacket(dataToSend, expectLen);
          delete dataToSend;
        }
      }
      int copy_start_idx = infos[infos.size() - 1].dataIdx;
      for (int i = copy_start_idx; i < mergedLen; i++)
      {
        tail_tmp_buffer_.emplace_back(readBuffer[i]);
      }
      //if (notGood)
      //  std::cout << " || pktno: " << read_pkt_cnt_ << "\n" << std::endl;
    }
    memset(readBuffer, 0, sizeof(readBuffer));

  }
  //else
  //{
    //std::cout << " || idx : " << read_pkt_cnt_ << std::endl;
    //std::cout <<  (uint16_t)(*(pkt_data + 36)) << " " << (uint16_t)(*(pkt_data + 37)) << std::endl;
  //}
  return 1;
}

inline void InputPcapUdpStream::recvPacket()
{
  while (!to_exit_recv_)
  {
    struct pcap_pkthdr* header;
    const uint8_t* pkt_data;
    int ret = pcap_next_ex(pcap_, &header, &pkt_data);
    
    //std::cout << "push cnt: " << push_cnt_ << std::endl;
  
    if (ret < 0)  // reach file end.
    {
      pcap_close(pcap_);
      pcap_ = NULL;
  
      if (input_param_.pcap_repeat)
      {
        cb_excep_(Error(ERRCODE_PCAPREPEAT));
  
        char errbuf[PCAP_ERRBUF_SIZE];
        pcap_ = pcap_open_offline(input_param_.pcap_path.c_str(), errbuf);
        continue;
      }
      else
      {
        cb_excep_(Error(ERRCODE_PCAPEXIT));
        break;
      }
    }
  
    if (pcap_offline_filter(&msop_filter_, header, pkt_data) != 0)
    {
      int dataLen = (int)(header->len - pcap_offset_ - pcap_tail_); // raw_length - eth_header (42)
      if (dataLen < 4) {
        cb_excep_(Error(ERRCODE_WRONGMSOPPCAPPARSE));
        continue;
      }
  
      if(static_cast<size_t>(dataLen) > ETH_LEN)
      {
        cb_excep_(Error(ERRCODE_WRONGMSOPPCAPPARSE));
        continue;
      }
      read_pkt_cnt_ += 1;
      //std::cout << " dataLen: " << dataLen << std::endl;
      procMsopPacket(pkt_data+pcap_offset_, dataLen);
      //std::cout << " pkt cnt: " << read_pkt_cnt_ << std::endl;
    }
  }
}

inline void InputPcapUdpStream::parsePacket(const uint8_t* data, size_t len)
{
  std::shared_ptr<Buffer> pkt = cb_get_pkt_(ETH_LEN);
  memcpy(pkt->data(), data, len - pcap_tail_);
  pkt->setData(0, len - pcap_tail_);

  if (len == RS0352_PKT_LEN)
  {
    uint8_t* temp_buf = pkt->data();
    int temp_angle = (temp_buf[16] << 8) + temp_buf[17];
    int pkt_seq = (temp_buf[100] << 8) + temp_buf[101];
    if(last_angle_ != -1)
    {
      if((last_angle_ > temp_angle) && (last_angle_ - temp_angle > 35000)) //condition
      {
        //std::cout << "pkt:" << pkt_seq << "last angle: " << last_angle_ << " temp angle:" << temp_angle << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(70));
      }
    }
    last_angle_ = temp_angle;
  }
  
  pushPacket(pkt);
}

}  // namespace lidar
}  // namespace robosense
